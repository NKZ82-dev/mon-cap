// Injecté dans la page (isolated world) par background.js : les collecteurs peuvent
// s'appeler entre eux et s'appuyer sur les aides menu ci-dessous.

// Menu Coba : textContent (les rubriques repliées restent lisibles, innerText non),
// ligatures Material Icons ignorées, pastille « Travaux 3 » acceptée.
function platMenu(el) {
  return (el?.textContent || '').replace(/\u00a0/g, ' ')
    .replace(/\b[a-z]+(?:_[a-z0-9]+)+\b/g, ' ')
    .replace(/\s+/g, ' ').trim();
}
function lienMenuCoba(nom) {
  const cible = nom.toLowerCase();
  const re = new RegExp('(?:^|\\s)' + nom.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:\\s|\\d|$)', 'i');
  const lib = el => platMenu(el);
  const exact = el => lib(el).toLowerCase() === cible;
  const approx = el => { const t = lib(el); return t.length > 0 && t.length < 60 && re.test(t); };
  const as = [...document.querySelectorAll('a')];
  const autres = [...document.querySelectorAll('[role=menuitem], [role=button]')];
  return as.find(exact) || as.find(approx) || autres.find(exact) || autres.find(approx) || null;
}
function liensMenuCoba() {
  return [...document.querySelectorAll('a')].map(platMenu).filter(t => t && t.length < 60).slice(0, 50);
}
async function deplierMenuCoba() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (const sec of ['Mon dossier', 'Mon école']) {
    const el = lienMenuCoba(sec)
      || [...document.querySelectorAll('button, [role=button], .titre, h2, h3, span')].find(x => platMenu(x) === sec);
    if (el) { el.click(); await sleep(400); }
  }
}
async function attendreLienMenu(nom, essais = 30) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < essais; i++) {
    if (document.querySelector('input[type=password]')) return { statut: 'connexion_requise', raison: 'formulaire' };
    if (/présentement non disponible|Retour à la page de connexion/i.test(document.body?.textContent || ''))
      return { statut: 'connexion_requise', raison: 'session expirée' };
    let link = lienMenuCoba(nom);
    if (!link && i === 6) { await deplierMenuCoba(); link = lienMenuCoba(nom); }
    if (link) return { statut: 'ok', link };
    await sleep(500);
  }
  return { statut: 'menu_introuvable', url: location.href, extrait: platMenu(document.body).slice(0, 400), liens: liensMenuCoba() };
}

// ---------- Coba : page Travaux ----------
async function cobaCollect(descriptionsConnues = {}, lireDescriptions = true) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Fiche (modale) repérée par son CONTENU, pas par sa classe : plus petit élément visible qui contient
  // tous les mots-clés et qui n'existait pas avant le clic.
  const visibleEl = el => el && el.getClientRects && el.getClientRects().length > 0;
  const contenant = mots => [...document.querySelectorAll('body *')].filter(el => mots.every(m => (el.textContent || '').includes(m)));
  const ficheOuverte = (mots, avant) => {
    const c = contenant(mots).filter(el => !avant.has(el) && visibleEl(el) && !el.closest('table'));
    c.sort((a, b) => (a.textContent || '').length - (b.textContent || '').length);
    return c[0] || null;
  };
  // Fermer la fiche : essayer les candidats un par un (bouton « FERMER » d'abord, puis la croix,
  // puis Échap), jusqu'à ce qu'elle ait réellement disparu.
  const fermerFiche = async fiche => {
    const ouverte = () => fiche.isConnected && visibleEl(fiche);
    let zone = fiche;
    for (let k = 0; k < 5 && zone.parentElement && zone.parentElement !== document.body; k++) {
      if ([...zone.querySelectorAll('button')].some(b => /^fermer$/i.test((b.textContent || '').trim()))) break;
      zone = zone.parentElement;
    }
    const lib = x => ((x.textContent || '').trim() + ' ' + (x.getAttribute?.('aria-label') || '')).trim();
    const tous = [...zone.querySelectorAll('button, a, [role=button], i, span')];
    const candidats = [
      ...tous.filter(x => /^(fermer|close)$/i.test((x.textContent || '').trim()) && /^(BUTTON|A)$/.test(x.tagName)),
      ...tous.filter(x => /fermer|close/i.test(x.getAttribute?.('aria-label') || '')),
      ...tous.filter(x => /^(close|×|✕)$/i.test((x.textContent || '').trim())).map(x => x.closest('button, a, [role=button]') || x)
    ].filter((x, i, a) => a.indexOf(x) === i);
    for (const b of candidats) {
      b.click();
      for (let i = 0; i < 6 && ouverte(); i++) await sleep(120);
      if (!ouverte()) return true;
    }
    for (const t of [document.activeElement, fiche, document.body]) t?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    for (let i = 0; i < 6 && ouverte(); i++) await sleep(120);
    return !ouverte();
  };
  // Élément à cliquer pour ouvrir une ligne : le lien d'abord, puis un bouton, puis l'icône, puis la cellule.
  const cible = row => row.querySelector('a[href], a') || row.querySelector('[role=button], button')
    || [...row.querySelectorAll('i, span, .material-icons')].find(x => /open_in_new/.test(x.textContent || '')) || row.querySelector('td');
  // Valeur d'un champ « Libellé | Valeur » dans une modale. On cherche le libellé exact (pas le titre de la
  // modale, qui peut porter le même texte) et on prend l'élément qui le suit.
  const valeurChamp = (dlg, libelle) => {
    const norm = s => (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
    const cibleL = norm(libelle);
    const lire = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ').split('\n').map(x => x.trim()).filter(Boolean).join('\n');
    const candidats = [...dlg.querySelectorAll('*')].filter(el => norm(el.textContent) === cibleL);
    let meilleur = '';
    for (const el of candidats) {
      // la valeur est l'élément suivant du libellé, ou celui de son parent (lignes en deux colonnes)
      let v = el.nextElementSibling, p = el;
      while (!v && p.parentElement && p.parentElement !== dlg) { p = p.parentElement; v = p.nextElementSibling; }
      const t = v ? lire(v) : '';
      if (t && !/^(fullscreen|close|×|✕|fermer)$/i.test(t) && t.length > meilleur.length) meilleur = t;
    }
    return meilleur;
  };
  const txt = el => ((el.innerText ?? el.textContent) || '').replace(/\s+/g, ' ').trim();

  // Attendre que le portail ait affiché son menu (ou le formulaire de connexion)
  const menu = await attendreLienMenu('Travaux');
  if (menu.statut === 'connexion_requise') return { ...menu, url: location.href };
  if (menu.statut !== 'ok') return menu;
  const link = menu.link;

  // Le menu est en javascript:void(0) : le contenu se charge en AJAX dans la même page
  link.click();
  let last = -1, stable = 0;
  for (let i = 0; i < 40; i++) {
    await sleep(500);
    const n = document.querySelectorAll('tr').length;
    if (n > 3 && n === last) { if (++stable >= 3) break; } else stable = 0;
    last = n;
  }

  const reCours = /^([A-Z]{3}\d{3})\s*-\s*(.+)$/;
  const reComp = /^Compétence\s*-\s*(.+?)\s*\((\d+)\s*%\)\s*Note finale provisoire\s*:\s*(.+)$/i;
  let cours = null, comp = null, categorie = '';
  const travaux = [], competences = [];

  for (const el of document.querySelectorAll('*')) {
    // En-tête de cours : texte propre à l'élément, hors tableau et hors liens
    if (el.tagName !== 'TR' && !el.closest('table') && el.tagName !== 'A' && !el.closest('nav')) {
      const own = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join(' ').trim();
      const m = own.match(reCours);
      if (m) { cours = { code: m[1], nom: m[2].trim() }; comp = null; categorie = ''; continue; }
    }
    if (el.tagName !== 'TR') continue;
    const c = [...el.children].map(txt);
    if (c.length === 1 && /^Compétence/i.test(c[0])) {
      const m = c[0].match(reComp);
      comp = m ? { nom: m[1], ponderation: +m[2], note_provisoire: m[3].trim() } : { nom: c[0], ponderation: null, note_provisoire: null };
      categorie = '';
      competences.push({ cours: cours?.code || null, ...comp, brut: c[0] });
      continue;
    }
    if (c[0] === 'open_in_new' && c.length >= 7) {
      if (c[1]) categorie = c[1];           // la catégorie n'est écrite que sur la 1re ligne du groupe
      travaux.push({
        cours: cours?.code || null,
        cours_nom: cours?.nom || null,
        competence: comp?.nom || null,
        categorie,
        travail: c[2],
        date_assignee: c[3] || null,
        date_due: c[4] || null,
        date_completee: c[5] || null,
        resultat_brut: c[6] || null,
        cle: [cours?.code, c[2], c[3]].join('|'),
        _ligne: el
      });
    }
  }

  // Ouvrir chaque travail pour lire sa « Description détaillée ». On ne rouvre pas ceux déjà connus
  // et inchangés (même date due). Un travail passé et déjà décrit n'est pas rouvert.
  let ouverts = 0;
  const aOuvrir = t => {
    if (!lireDescriptions) return false;
    const c = descriptionsConnues[t.cle];
    if (!c) return true;
    if (c.date_due !== (t.date_due || null)) return true;
    return false;
  };
  const champ = (dlg, etiq) => {
    for (const row of dlg.querySelectorAll('tr, .row, div')) {
      const t = txt(row);
      if (new RegExp('^' + etiq, 'i').test(t)) {
        const v = t.replace(new RegExp('^' + etiq + '\\s*:?\\s*', 'i'), '').trim();
        if (v) return v;
      }
    }
    return '';
  };
  let essaisRates = 0;
  for (const t of travaux) {
    if (!aOuvrir(t)) { if (descriptionsConnues[t.cle]) t.description = descriptionsConnues[t.cle].description; delete t._ligne; continue; }
    const icone = cible(t._ligne);
    delete t._ligne;
    if (!icone) continue;
    const MOTS = ['Description détaillée', 'Date due'];
    const avant = new Set(contenant(MOTS));
    icone.click();
    let dlg = null;
    for (let i = 0; i < 16 && !dlg; i++) { await sleep(250); dlg = ficheOuverte(MOTS, avant); }
    if (dlg) {
      t.description = valeurChamp(dlg, 'Description détaillée') || '';
      ouverts++;
      await fermerFiche(dlg);
    } else essaisRates++;
    if (essaisRates >= 3 && !ouverts) break;   // aucune fiche ne s'ouvre : inutile d'insister sur les 54 travaux
  }
  for (const t of travaux) delete t._ligne;
  return { statut: travaux.length ? 'ok' : 'tableau_vide', url: location.href, travaux, competences, descriptions_ouvertes: ouverts, descriptions_ratees: essaisRates, nb_lignes: document.querySelectorAll('tr').length };
}

// ---------- Coba : courriels ----------
// Boîte de réception : tableau grid3, 10 courriels par page. Chaque ligne tr.grid3__row contient une zone
// cliquable (div …ctnLigneCourriel) et des span.libelle : expéditeur, petite ligne (destinataire), objet,
// aperçu, date. On lit jusqu'à `pages` pages ; on ouvre les nouveaux courriels (Coba les marque alors lus).
async function cobaCourriels(connus = [], ouvrir = true, max = 30, pages = 3) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const TC = el => (el?.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ');
  const reDate = /\b\d{1,2}\s+(janv|févr|fevr|mars|avr|mai|juin|juil|août|aout|sept|oct|nov|déc|dec)\.?\s+\d{4}|\d{4}-\d{2}-\d{2}|\b\d{1,2}:\d{2}\b|hier|aujourd/i;
  const lienMenu = nom => lienMenuCoba(nom);
  const lignes = () => [...document.querySelectorAll('tr.grid3__row')].filter(tr => tr.querySelector('[id$="ctnLigneCourriel"], [data-action]') && tr.querySelector('span.libelle'));
  const attendreListe = async () => { let p = -1, st = 0; for (let i = 0; i < 40; i++) { await sleep(300); const n = lignes().length; if (n && n === p) { if (++st >= 2) return true; } else st = 0; p = n; } return lignes().length > 0; };
  // Date de la liste : « 16 oct » (sans année), « 10:12 » ou « hier »
  const reDateListe = /^(\d{1,2}\s+(janv|févr|fevr|mars|avr|mai|juin|juil|août|aout|sept|oct|nov|déc|dec)\.?(\s+\d{4})?|\d{1,2}:\d{2}|hier|aujourd.hui)$/i;
  const lire = tr => {
    const sp = [...tr.querySelectorAll('span.libelle')];
    const txt = sp.map(TC);
    const iDate = txt.findIndex((x, i) => i > 0 && reDateListe.test(x));
    // la petite ligne contient l'objet puis l'aperçu ; l'objet est son premier élément, sinon le texte
    // qui précède « Ceci est une copie du message »
    const petit = sp.find(s => /font-size:\s*12px/.test(s.getAttribute('style') || '')) || sp.find((s, i) => i > 0 && i !== iDate);
    let objet = '', apercu = '';
    if (petit) {
      const premier = [...petit.children].map(TC).find(Boolean);
      const tout = TC(petit);
      if (premier && premier.length < tout.length) { objet = premier; apercu = tout.slice(premier.length).trim(); }
      else { const k = tout.search(/Ceci est une copie du message/i); objet = (k > 0 ? tout.slice(0, k) : tout).trim(); apercu = k > 0 ? tout.slice(k).trim() : ''; }
    }
    const c = { expediteur: txt[0] || '', objet, apercu: apercu.replace(/^Ceci est une copie du message envoyé à\s+\S+(\s+\S+)?\s*/i, '').trim().slice(0, 300), date_libelle: iDate >= 0 ? txt[iDate] : '' };
    c.cle = [c.expediteur, c.objet, c.date_libelle].join('|');
    return c;
  };
  // pagination : bouton « page suivante » près du tableau (jamais dans le menu)
  const pageSuivante = () => {
    const tb = document.querySelector('table.grid3'); let zone = tb; for (let k = 0; k < 3 && zone?.parentElement; k++) zone = zone.parentElement;
    return [...(zone || document).querySelectorAll('a, button, [role=button]')].find(b => !b.closest('nav, aside') &&
      (/^(chevron_right|navigate_next|keyboard_arrow_right|arrow_forward|›|>)$/i.test(TC(b)) || /suivant|next/i.test((b.getAttribute('aria-label') || '') + (b.getAttribute('title') || ''))) && !b.disabled && !/disabled/.test(b.className));
  };
  const allerPage = async k => {
    for (let i = 1; i < k; i++) { const b = pageSuivante(); if (!b) return false; const avant = lignes().map(TC).join('|'); b.click();
      let ok = false; for (let j = 0; j < 30; j++) { await sleep(300); if (lignes().length && lignes().map(TC).join('|') !== avant) { ok = true; break; } } if (!ok) return false; }
    return true;
  };
  const retourBoite = async () => { (lienMenu('Courriels'))?.click(); await attendreListe(); };

  let l = lienMenu('Courriels');
  if (!l) { await deplierMenuCoba(); l = lienMenu('Courriels'); }
  if (!l) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  l.click();
  if (!(await attendreListe())) return { statut: 'liste_vide', courriels: [] };

  // 1. inventaire des pages
  const courriels = []; let pagesLues = 0;
  for (let p = 1; p <= pages && courriels.length < max; p++) {
    if (p > 1) { const b = pageSuivante(); if (!b) break; const avant = lignes().map(TC).join('|'); b.click();
      let ch = false; for (let j = 0; j < 30; j++) { await sleep(300); if (lignes().length && lignes().map(TC).join('|') !== avant) { ch = true; break; } } if (!ch) break; }
    pagesLues = p;
    for (const tr of lignes()) { const c = lire(tr); c.page = p; if (!courriels.some(x => x.cle === c.cle)) courriels.push(c); }
  }
  if (!ouvrir) return { statut: 'ok', courriels, pages_lues: pagesLues };

  // 2. ouvrir les nouveaux, page par page (retour à la boîte = page 1, puis on revient à la bonne page)
  await retourBoite();
  let ouverts = 0;
  for (const c of courriels) {
    if (connus.includes(c.cle)) { c.texte_en_cache = true; continue; }
    if (c.page > 1 && !(await allerPage(c.page))) { c.erreur = 'page introuvable'; await retourBoite(); continue; }
    const tr = lignes().find(r => lire(r).cle === c.cle);
    const zone = tr && (tr.querySelector('[id$="ctnLigneCourriel"]') || tr.querySelector('[data-action]'));
    if (!zone) { c.erreur = 'ligne introuvable'; await retourBoite(); continue; }
    zone.click();
    // attendre que la liste ait disparu et que la vue du message soit stable (elle n'affiche pas l'objet)
    let txt = '', prec = -1, st = 0;
    for (let i = 0; i < 40; i++) { await sleep(300); if (lignes().length) { st = 0; continue; }
      const t = T(document.body); if (t.length === prec && t.length > 0) { if (++st >= 2) { txt = t; break; } } else st = 0; prec = t.length; txt = t; }
    // le message commence à sa date complète (« 9 oct 2026, 17:26 »), après le menu de la page
    const mDate = txt.match(/\b\d{1,2}\s+[a-zéû]+\.?\s+\d{4},\s*\d{1,2}:\d{2}\b/i);
    const k = mDate ? txt.indexOf(mDate[0]) : (c.objet ? txt.indexOf(c.objet) : -1);
    c.texte = (k >= 0 ? txt.slice(k) : txt).replace(/\n{3,}/g, '\n\n').slice(0, 12000);
    // date complète du message ouvert : « 16 oct 2026, 17:00 »
    const dl = c.texte.match(/\b\d{1,2}\s+[a-zéû]+\.?\s+\d{4},\s*\d{1,2}:\d{2}\b/i); if (dl) c.date_complete = dl[0];
    if (c.texte) ouverts++;
    await retourBoite();
  }
  return { statut: 'ok', courriels, pages_lues: pagesLues, ouverts };
}

// ---------- Coba : connexion automatique ----------
// Remplit le formulaire de login.coba et le soumet. Ne renvoie jamais les valeurs saisies.
async function cobaLogin(identifiant, motDePasse) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let pw = null;
  for (let i = 0; i < 6 && !pw; i++) { pw = [...document.querySelectorAll('input[type=password]')].find(e => e.getClientRects().length) || document.querySelector('input[type=password]'); if (!pw) await sleep(200); }
  const decrire = () => ({
    champs: [...document.querySelectorAll('input,select')].map(e => ({ tag: e.tagName, type: e.type, name: e.name, id: e.id })),
    boutons: [...document.querySelectorAll('button,input[type=submit],input[type=button],a[role=button]')].map(b => ((b.innerText ?? b.value) || '').trim().slice(0, 40))
  });
  if (!pw) return { ok: false, raison: 'champ mot de passe introuvable', ...decrire() };
  const scope = pw.form || document;
  const textes = [...scope.querySelectorAll('input')].filter(e => /^(text|email|tel|)$/.test(e.type) && e.getClientRects().length);
  const avant = textes.filter(e => e.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING);
  const user = avant[avant.length - 1] || textes[0];
  if (!user) return { ok: false, raison: 'champ identifiant introuvable', ...decrire() };
  const setVal = (el, v) => {
    el.focus();
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v);
    for (const ev of ['input', 'change']) el.dispatchEvent(new Event(ev, { bubbles: true }));
    el.dispatchEvent(new Event('blur'));
  };
  setVal(user, identifiant); await sleep(80);
  setVal(pw, motDePasse); await sleep(120);
  const btn = scope.querySelector('button[type=submit],input[type=submit]')
    || [...document.querySelectorAll('button,input[type=button],input[type=submit],a')].find(b => /connexion|se connecter|connecter|ouvrir une session|login|entrer|valider/i.test(((b.innerText ?? b.value) || '')));
  if (btn) btn.click();
  else if (pw.form) (pw.form.requestSubmit ? pw.form.requestSubmit() : pw.form.submit());
  else pw.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
  await sleep(200);
  const erreur = [...document.querySelectorAll('.error,.erreur,.alert,[role=alert]')].map(e => ((e.innerText ?? e.textContent) || '').trim()).filter(Boolean).join(' | ').slice(0, 300);
  return { ok: true, bouton: btn ? ((btn.innerText ?? btn.value) || '').trim().slice(0, 40) : null, erreur, ...decrire() };
}

// ---------- Classroom : vue tuteur d'un cours ----------
// connus : { id: { date_libelle, vu } } des éléments dont on a déjà le contenu.
// toutRouvrir : true = ouvrir tous les éléments, sans exception.
async function classroomCollect(diag, maxMs = 15000, connus = {}, toutRouvrir = false, debutAnnee = null) {
  if (!debutAnnee) { const n = new Date(); debutAnnee = n.getMonth() >= 7 ? n.getFullYear() : n.getFullYear() - 1; }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ').trim();
  if (/accounts\.google\.com/.test(location.host)) return { statut: 'connexion_requise', url: location.href };
  const root = () => document.querySelector('[role=main]') || document.querySelector('main') || document.body;
  const enChargement = t => /aperçu de .* en cours|Chargement…|Loading…/i.test(t);
  // Textes « feuilles » d'un élément, dans l'ordre (ne dépend pas des sauts de ligne de innerText)
  const lignesDe = el => {
    const out = [];
    for (const e of el.querySelectorAll('*')) {
      if (e.children.length || /^(SCRIPT|STYLE)$/.test(e.tagName)) continue;
      const t = T(e); if (t && out[out.length - 1] !== t) out.push(t);
    }
    return out;
  };
  // Fenêtres modales Classroom (affichage compact) : les repérer et les fermer
  const visible = el => el && el.getClientRects().length > 0;
  const modales = () => [...document.querySelectorAll('[role=dialog], [aria-modal=true]')].filter(visible);
  const fermerModale = async m => {
    const b = [...m.querySelectorAll('button, [role=button]')].find(x => /^(Fermer|Close)$/i.test(x.getAttribute('aria-label') || '') || /^(close|×|✕)$/i.test((x.textContent || '').trim()));
    if (b) b.click();
    else for (const t of [m, document.activeElement, document.body]) t?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    for (let i = 0; i < 10 && m.isConnected && visible(m); i++) await sleep(150);
  };
  const fermerToutes = async () => { for (let k = 0; k < 6 && modales().length; k++) await fermerModale(modales().pop()); };

  // Lignes de texte « propres » d'un élément : chaque nœud texte, dans l'ordre, y compris ceux séparés
  // par des <br>. Le texte des liens (pièces jointes) et des icônes est exclu.
  const lignesTexte = (el, exclure = 'a[href], button, [role=button][aria-label], i, .material-icons, [aria-hidden=true]') => {
    const out = [];
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const p = n.parentElement;
      if (!p || /^(SCRIPT|STYLE)$/.test(p.tagName) || p.closest(exclure)) continue;
      const t = n.textContent.replace(/\u00a0/g, ' ').trim();
      if (t && out[out.length - 1] !== t) out.push(t);
    }
    return out;
  };

  // 1. Attendre que la liste soit affichée et stable
  let prec = -1, stable = 0;
  for (let i = 0; i < maxMs / 300; i++) {
    await sleep(300);
    const t = T(root());
    if (!enChargement(t) && t.length > 300 && t.length === prec) { if (++stable >= 2) break; } else stable = 0;
    prec = t.length;
  }
  const texteListe = T(root());
  if (enChargement(texteListe)) return { statut: 'chargement_incomplet', url: location.href, texte: texteListe };

  // 2. Déplier « Afficher plus » tant qu'il y en a
  for (let k = 0; k < 6; k++) {
    const plus = [...document.querySelectorAll('[aria-label="Afficher plus de publications"],[aria-label="Show more posts"]')].filter(b => b.offsetParent !== null || b.getClientRects().length);
    if (!plus.length) break;
    plus.forEach(b => b.click());
    await sleep(900);
  }

  // 3. Lire chaque élément (devoir, matériel, question)
  const cours = lignesDe(root().querySelector('h1,h2') || root()).find(l => !/^(Google )?Classroom$/i.test(l)) || document.title;
  const lis = [...root().querySelectorAll('li[data-stream-item-id]')];
  const elements = lis.map(li => {
    const region = li.closest('[aria-label^="Sujet "],[aria-label^="Topic "]');
    const lignes = lignesDe(li);
    const type = lignes[0] || '';
    const btn = li.querySelector('[role=button][aria-label]');
    const titre = btn?.getAttribute('aria-label') || lignes.find(l => !/^(Matériel|Devoir|Question|book|assignment|help|quiz)$/i.test(l)) || '';
    const date = lignes.find(l => /^(Publié|Modifié|Échéance|Aucune échéance|Posted|Edited|Due|No due)/i.test(l)) || '';
    return {
      id: li.getAttribute('data-stream-item-id'),
      type, titre, date_libelle: date,
      sujet: region ? region.getAttribute('aria-label').replace(/^(Sujet|Topic)\s+/, '') : null
    };
  });

  // 4. Décider quoi ouvrir. Un élément est rouvert s'il est nouveau, si son libellé a changé, s'il est
  //    encore d'actualité (échéance à venir ou récente, aucune échéance, matériel récent), ou s'il n'a pas
  //    été relu depuis 7 jours. Seuls les éléments anciens et inchangés gardent leur contenu en mémoire.
  const MOIS = { janv: 1, 'févr': 2, mars: 3, avr: 4, mai: 5, juin: 6, juil: 7, 'août': 8, sept: 9, oct: 10, nov: 11, 'déc': 12 };
  const auj = new Date(); auj.setHours(12, 0, 0, 0);
  const joursDepuis = lib => {               // âge en jours de la date du libellé (négatif = dans le futur)
    const m = (lib || '').match(/(\d{1,2})\s+(janv|févr|mars|avr|mai|juin|juil|août|sept|oct|nov|déc)/i);
    if (!m) return /Hier|Yesterday/i.test(lib) ? 1 : 0;        // « 09 h 20 » = aujourd'hui
    const mo = MOIS[m[2].toLowerCase()];
    const d = new Date(mo >= 8 ? debutAnnee : debutAnnee + 1, mo - 1, +m[1], 12);
    return Math.round((auj - d) / 864e5);
  };
  const actuel = e => /Aucune échéance|No due/i.test(e.date_libelle)
    || (/^(Échéance|Due)/i.test(e.date_libelle) && joursDepuis(e.date_libelle) <= 7)
    || joursDepuis(e.date_libelle) <= 21;
  const aRouvrir = e => {
    const c = connus[e.id];
    if (toutRouvrir || !c || c.vide || c.date_libelle !== e.date_libelle) return true;   // contenu vide en mémoire : relire
    if (Date.now() - (c.vu || 0) > 7 * 864e5) return true;
    return actuel(e);
  };

  // 5. Ouvrir les éléments retenus (un à la fois : Classroom n'en ouvre qu'un)
  let ouverts = 0;
  for (const [i, li] of lis.entries()) {
    const e = elements[i];
    if (!aRouvrir(e)) { e.detail_en_cache = true; continue; }
    const btn = li.querySelector('[role=button][aria-expanded]') || li.querySelector('[role=button]');
    if (!btn) continue;
    await fermerToutes();   // ne jamais empiler les modales
    // Mesure indépendante de l'affichage : textContent et nombre de nœuds (innerText dépend du rendu)
    const taille = () => (li.textContent || '').length + li.getElementsByTagName('*').length * 3;
    const avant = taille();
    const deplier = async (maxTours) => {
      let l = -1, st = 0;
      for (let j = 0; j < maxTours; j++) {
        await sleep(300);
        const n = taille();
        if (n > avant + 10 && n === l) { if (++st >= 2) return true; } else st = 0;
        l = n;
      }
      return taille() > avant + 10;
    };
    btn.scrollIntoView?.({ block: 'center' });
    btn.click(); ouverts++;
    // Deux affichages possibles : dépliage dans la liste, ou fenêtre modale par-dessus
    let modale = null, deplie = false;
    for (let j = 0; j < 14 && !modale && !deplie; j++) {
      await sleep(300);
      const m = modales().pop();
      if (m && (m.textContent || '').length > 20) modale = m;
      else if (taille() > avant + 10) deplie = true;
    }
    if (deplie) deplie = await deplier(8) || deplie;      // laisser finir le dépliage
    if (modale) {                                         // attendre que la modale ait chargé son contenu
      let l = -1, st = 0;
      for (let j = 0; j < 12; j++) { await sleep(300); const n = (modale.textContent || '').length; if (n === l) { if (++st >= 2) break; } else st = 0; l = n; }
    }
    const zone = modale || li;
    e._diag = { mode: modale ? 'modale' : deplie ? 'depliage' : 'rien', avant, apres: taille() };
    const entete = [e.type, e.titre, e.date_libelle];
    const bruit = /^(book|assignment|help|quiz|more_vert|visibility_off|•|Afficher les instructions|Afficher le devoir|Afficher le matériel|View instructions|View assignment|View material|Fichier Disque|Inconnu|Google Formulaires|Vous ne pouvez pas consulter l.aperçu des formulaires Google\.?)$/i;
    e.detail = lignesTexte(zone).filter(x => x && !entete.includes(x) && !bruit.test(x)).filter((x, k, a) => a.indexOf(x) === k).join('\n');
    // Étapes : lignes numérotées ou à puces, copiées telles quelles (aucune reformulation)
    let etapes = e.detail.split('\n').map(x => x.trim()).filter(x => /^(\d{1,2}[.)]|[-–•*])\s+\S/.test(x));
    if (etapes.length < 2) {
      // Liste écrite d'un bloc, ex. « …à droite)Compléter le document roseCorrigé… » : on coupe là où une
      // minuscule, un chiffre ou une parenthèse touche directement une majuscule. Chaque morceau reste mot pour mot.
      for (const ligne of e.detail.split('\n')) {
        const apres = ligne.includes('?') ? ligne.slice(ligne.indexOf('?') + 1) : ligne;   // après « … te préparer ? »
        const morceaux = apres.split(/(?<=[a-zàâçéèêëîïôûùüÿœ0-9)])(?=[A-ZÀÂÇÉÈÊËÎÏÔÛÙÜŸŒ][a-zàâçéèêëîïôûùüÿœ])/).map(x => x.trim()).filter(x => x.length > 3);
        if (morceaux.length >= 3) { etapes = morceaux; break; }
      }
    }
    if (etapes.length >= 2) e.etapes = etapes.map(x => ({ texte: x, source: 'consigne' }));
    e.pieces_jointes = [...zone.querySelectorAll('a[href]')].map(a => ({ texte: T(a).slice(0, 150), href: a.href }))
      .filter(a => !/classroom\.google\.com\/guar/.test(a.href));
    if (modale) await fermerModale(modale);               // refermer la modale avant l'élément suivant
    else if (btn.getAttribute('aria-expanded') === 'true') btn.click();   // ou replier
    await sleep(150);
  }

  const pasAcces = /n'avez pas accès|don't have access|Demander l'accès|Request access/i.test(texteListe);
  return {
    statut: pasAcces ? 'acces_refuse' : (elements.length || texteListe.length > 300 ? 'ok' : 'page_vide'),
    url: location.href, cours, titre_page: document.title,
    entetes: [cours], elements, details_ouverts: ouverts,
    deplies: elements.filter(x => x._diag && x._diag.mode !== 'rien').length, modales: elements.filter(x => x._diag?.mode === 'modale').length, visibilite: document.visibilityState,
    texte: T(root()).slice(0, 60000),
    html: diag ? root().outerHTML.slice(0, 600000) : undefined
  };
}


// ---------- Coba : Suivi (commentaires des profs) ----------
// Lit le tableau « Liste des commentaires » par ses colonnes nommées (Date, Commentaire, Type,
// Regroupement, Enseignant) et ouvre chaque ligne pour récupérer le « Détail du commentaire ».
async function cobaSuivi(connus = {}) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Fiche (modale) repérée par son CONTENU, pas par sa classe : plus petit élément visible qui contient
  // tous les mots-clés et qui n'existait pas avant le clic.
  const visibleEl = el => el && el.getClientRects && el.getClientRects().length > 0;
  const contenant = mots => [...document.querySelectorAll('body *')].filter(el => mots.every(m => (el.textContent || '').includes(m)));
  const ficheOuverte = (mots, avant) => {
    const c = contenant(mots).filter(el => !avant.has(el) && visibleEl(el) && !el.closest('table'));
    c.sort((a, b) => (a.textContent || '').length - (b.textContent || '').length);
    return c[0] || null;
  };
  // Fermer la fiche : essayer les candidats un par un (bouton « FERMER » d'abord, puis la croix,
  // puis Échap), jusqu'à ce qu'elle ait réellement disparu.
  const fermerFiche = async fiche => {
    const ouverte = () => fiche.isConnected && visibleEl(fiche);
    let zone = fiche;
    for (let k = 0; k < 5 && zone.parentElement && zone.parentElement !== document.body; k++) {
      if ([...zone.querySelectorAll('button')].some(b => /^fermer$/i.test((b.textContent || '').trim()))) break;
      zone = zone.parentElement;
    }
    const lib = x => ((x.textContent || '').trim() + ' ' + (x.getAttribute?.('aria-label') || '')).trim();
    const tous = [...zone.querySelectorAll('button, a, [role=button], i, span')];
    const candidats = [
      ...tous.filter(x => /^(fermer|close)$/i.test((x.textContent || '').trim()) && /^(BUTTON|A)$/.test(x.tagName)),
      ...tous.filter(x => /fermer|close/i.test(x.getAttribute?.('aria-label') || '')),
      ...tous.filter(x => /^(close|×|✕)$/i.test((x.textContent || '').trim())).map(x => x.closest('button, a, [role=button]') || x)
    ].filter((x, i, a) => a.indexOf(x) === i);
    for (const b of candidats) {
      b.click();
      for (let i = 0; i < 6 && ouverte(); i++) await sleep(120);
      if (!ouverte()) return true;
    }
    for (const t of [document.activeElement, fiche, document.body]) t?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    for (let i = 0; i < 6 && ouverte(); i++) await sleep(120);
    return !ouverte();
  };
  // Élément à cliquer pour ouvrir une ligne : le lien d'abord, puis un bouton, puis l'icône, puis la cellule.
  const cible = row => row.querySelector('a[href], a') || row.querySelector('[role=button], button')
    || [...row.querySelectorAll('i, span, .material-icons')].find(x => /open_in_new/.test(x.textContent || '')) || row.querySelector('td');
  // Valeur d'un champ « Libellé | Valeur » dans une modale. On cherche le libellé exact (pas le titre de la
  // modale, qui peut porter le même texte) et on prend l'élément qui le suit.
  const valeurChamp = (dlg, libelle) => {
    const norm = s => (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
    const cibleL = norm(libelle);
    const lire = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ').split('\n').map(x => x.trim()).filter(Boolean).join('\n');
    const candidats = [...dlg.querySelectorAll('*')].filter(el => norm(el.textContent) === cibleL);
    let meilleur = '';
    for (const el of candidats) {
      // la valeur est l'élément suivant du libellé, ou celui de son parent (lignes en deux colonnes)
      let v = el.nextElementSibling, p = el;
      while (!v && p.parentElement && p.parentElement !== dlg) { p = p.parentElement; v = p.nextElementSibling; }
      const t = v ? lire(v) : '';
      if (t && !/^(fullscreen|close|×|✕|fermer)$/i.test(t) && t.length > meilleur.length) meilleur = t;
    }
    return meilleur;
  };
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  let lien = lienMenuCoba('Suivi');
  if (!lien) { await deplierMenuCoba(); lien = lienMenuCoba('Suivi'); }
  if (!lien) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  lien.click();
  for (let i = 0; i < 40; i++) { await sleep(400); if (/Liste des commentaires|Regroupement|Enseignant/i.test(T(document.body))) break; }

  // Repérer la ligne d'en-tête et l'indice de chaque colonne
  let entete = null, cols = {};
  for (const tr of document.querySelectorAll('tr')) {
    const c = [...tr.children].map(T);
    const iDate = c.findIndex(x => /^Date/i.test(x)), iComm = c.indexOf('Commentaire'), iType = c.indexOf('Type'), iEns = c.indexOf('Enseignant');
    if (iDate >= 0 && iComm >= 0 && iType >= 0) { entete = tr; cols = { date: iDate, comm: iComm, type: iType, regr: c.indexOf('Regroupement'), ens: iEns }; break; }
  }
  if (!entete) return { statut: 'entete_introuvable' };

  const reDate = /\d{4}-\d{2}-\d{2}/;
  // Les lignes de commentaire ont la classe grid3__row ; elles arrivent après l'en-tête, donc on attend
  // que leur nombre se stabilise. Leurs valeurs sont dans des span.libelle (indépendant de l'ordre des colonnes).
  // 1re méthode : lignes de classe grid3__row ; 2e méthode : lignes de la table dont l'en-tête est
  // « Commentaire / Type / Enseignant », qui contiennent une date.
  const tableListe = entete.closest('table');
  const lignesListe = () => {
    const a = [...document.querySelectorAll('tr.grid3__row')].filter(tr => reDate.test(tr.textContent || ''));
    if (a.length) return a;
    return tableListe ? [...tableListe.querySelectorAll('tr')].filter(tr => tr !== entete && reDate.test(tr.textContent || '')) : [];
  };
  let n0 = -1, st = 0;
  for (let i = 0; i < 50; i++) { const n = lignesListe().length; if (n > 0 && n === n0) { if (++st >= 3) break; } else st = 0; n0 = n; await sleep(300); }
  const lignes = lignesListe();
  // Sommaire de Coba : « Type de commentaire » / « Nb points »
  const sommaire = {};
  for (const tb of document.querySelectorAll('table')) {
    const th = [...tb.querySelectorAll('th')].map(T);
    if (th.includes('Type de commentaire')) for (const tr of tb.querySelectorAll('tr')) {
      const c = [...tr.children].map(T); if (c[0] && /^\d+$/.test(c[1] || '')) sommaire[c[0]] = +c[1];
    }
  }
  const items = [], champ = (dlg, etiq) => {
    for (const row of dlg.querySelectorAll('tr, div')) { const t = T(row);
      if (new RegExp('^' + etiq, 'i').test(t)) { const v = t.replace(new RegExp('^' + etiq + '\\s*:?\\s*', 'i'), '').trim(); if (v) return v; } }
    return '';
  };
  let ouverts = 0, rates = 0;
  for (const tr of lignes) {
    // textContent plutôt que le texte affiché : une ligne hors de l'écran n'a pas de texte affiché
    const TC = el => (el?.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
    const libs = [...tr.querySelectorAll('span.libelle')].map(TC);
    const date = (TC(tr).match(/\d{4}-\d{2}-\d{2}(?:\s+\d{1,2}:\d{2})?/) || [''])[0];
    const sansDate = libs.filter(x => !reDate.test(x));   // commentaire, type, regroupement, enseignant
    const it = {
      date_libelle: date,
      commentaire: sansDate[0] || '',
      type: sansDate[1] || '',
      regroupement: sansDate[2] || '',
      enseignant: sansDate[3] || '',
      cle: [date, sansDate[0] || '', sansDate[3] || ''].join('|')
    };
    // Détail déjà connu et inchangé : ne pas rouvrir
    if (connus[it.cle]?.detail) { it.detail = connus[it.cle].detail; items.push(it); continue; }
    const icone = cible(tr);
    if (icone && rates < 3) {
      const MOTS = ['Détail du commentaire', 'Enseignant'];
      const avant = new Set(contenant(MOTS));
      icone.click();
      let dlg = null;
      for (let i = 0; i < 16 && !dlg; i++) { await sleep(250); dlg = ficheOuverte(MOTS, avant); }
      if (dlg) { it.detail = valeurChamp(dlg, 'Détail du commentaire') || ''; ouverts++; await fermerFiche(dlg); }
      else if (!ouverts) rates++;
    }
    items.push(it);
  }
  // Agrégats, tous tirés des colonnes de Coba (aucune interprétation)
  const parType = {}, parRegr = {};
  for (const it of items) { if (it.type) parType[it.type] = (parType[it.type] || 0) + 1; if (it.regroupement) parRegr[it.regroupement] = (parRegr[it.regroupement] || 0) + 1; }
  const diag = items.length ? undefined : {
    nb_tr: document.querySelectorAll('tr').length, nb_grid3: document.querySelectorAll('tr.grid3__row').length,
    nb_tr_table_liste: tableListe ? tableListe.querySelectorAll('tr').length : null,
    classes_tr: [...new Set([...(tableListe || document).querySelectorAll('tr')].map(tr => tr.className).filter(Boolean))].slice(0, 6),
    ex_ligne: ((tableListe || document).querySelectorAll('tr')[1]?.textContent || '').replace(/[A-Za-zÀ-ÿ]/g, 'x').replace(/\s+/g, ' ').slice(0, 120)
  };
  return { statut: items.length ? 'ok' : 'liste_vide', items, parType, parRegr, sommaire, details_ouverts: ouverts, nb_lignes_vues: lignes.length, diag };
}

// ---------- Coba : Agenda (grille des cours jour par jour + notes) ----------
// Lit la vue Mois : pour chaque jour, le quantième, le jour du cycle (petit chiffre) et les cours « HH:MM CODE ».
async function cobaAgenda(moisAvancer = 1) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ');
  const plat = el => T(el).replace(/\s+/g, ' ').trim();
  const MOIS = { janvier: 1, février: 2, fevrier: 2, mars: 3, avril: 4, mai: 5, juin: 6, juillet: 7, août: 8, aout: 8, septembre: 9, octobre: 10, novembre: 11, décembre: 12, decembre: 12 };
  const reTitre = /^(janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre)\s+(20\d{2})$/i;

  let lien = lienMenuCoba('Agenda');
  if (!lien) { await deplierMenuCoba(); lien = lienMenuCoba('Agenda'); }
  if (!lien) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  lien.click();
  // Le titre du mois est un élément dont le texte est EXACTEMENT « OCTOBRE 2026 » (pas « Année scolaire 2026-2027 »)
  const titreMois = () => [...document.querySelectorAll('body *')].find(el => !el.children.length && reTitre.test(plat(el)));
  // Attendre la grille (cases td[data-day]) ; le titre du mois est facultatif
  const casesJour = () => document.querySelectorAll('td[data-day]');
  for (let i = 0; i < 40 && !casesJour().length; i++) await sleep(400);
  if (!casesJour().length) return { statut: 'grille_introuvable' };

  // Vue Mois si elle n'est pas active (bouton dont le texte commence par « MOIS »)
  const bMois = [...document.querySelectorAll('button, a, [role=button]')].find(b => /^MOIS\b/i.test(plat(b)));
  if (bMois) { bMois.click(); await sleep(1000); }

  // Barre de navigation = ancêtre proche du titre ; les flèches sont cherchées UNIQUEMENT là (pas dans le menu latéral)
  const barre = () => { let p = titreMois(); for (let k = 0; k < 4 && p?.parentElement; k++) { p = p.parentElement; if (p.querySelectorAll('button, [role=button], a').length >= 2) return p; } return p; };
  const flecheSuivante = () => {
    let b = titreMois() ? barre() : null;
    if (!b) { b = document.querySelector('table.calmens'); for (let k = 0; k < 4 && b?.parentElement; k++) b = b.parentElement; }
    if (!b) return null;
    const btns = [...b.querySelectorAll('button, [role=button], a, i, span')].filter(x => !x.closest('nav, aside') && !x.closest('table.calmens') && !/Mon dossier/.test(x.parentElement?.textContent || ''));
    const f = btns.find(x => /^(chevron_right|navigate_next|arrow_forward|arrow_forward_ios|keyboard_arrow_right|arrow_right|›|>|»)$/i.test(plat(x)) || /suivant|next/i.test((x.getAttribute('aria-label') || '') + (x.getAttribute('title') || '')));
    return f ? (f.closest('a, button, [role=button]') || f) : null;
  };

  const lireMois = () => {
    const mt = plat(titreMois()).match(reTitre);
    const auj = new Date(), debutAS = auj.getMonth() >= 7 ? auj.getFullYear() : auj.getFullYear() - 1;
    const anneePour = mo => mt && MOIS[mt[1].toLowerCase()] === mo ? +mt[2] : (mo >= 8 ? debutAS : debutAS + 1);
    const jours = [];
    // Structure Coba : <td data-day="1" data-lbljour="4" data-fullname="Jeudi, 1 octobre">
    //   <div class="calmens__item"><span class="calmens__item__heure">08:05</span>
    //   <span class="calmens__item__desc">DRA104-00106</span></div>…</td>
    for (const cell of document.querySelectorAll('td[data-day]')) {
      const q = +cell.getAttribute('data-day');
      if (!q || q > 31) continue;
      const nomMois = ((cell.getAttribute('data-fullname') || '').match(/\d{1,2}\s+([a-zàâçéèêëîïôûùü]+)/i) || [])[1];
      const mois = MOIS[(nomMois || '').toLowerCase()] || (mt ? MOIS[mt[1].toLowerCase()] : null);
      if (!mois) continue;
      const cyc = +cell.getAttribute('data-lbljour') || null;   // jour du cycle
      const cours = [];
      for (const it of cell.querySelectorAll('.calmens__item')) {
        const heure = plat(it.querySelector('.calmens__item__heure'));
        const desc = plat(it.querySelector('.calmens__item__desc'));
        const mc = desc.match(/([A-Z]{3}\d{3})(?:-(\d+))?/);
        // Pastille rouge = travaux dus à cette période. Nombre dans data-compteur ; titres dans l'attribut
        // data-action (menu encodé deux fois). Lu sans aucun clic.
        const pastille = it.querySelector('[data-compteur]');
        let travaux_lies = [];
        if (pastille) {
          let brut = pastille.getAttribute('data-action') || '';
          for (let k = 0; k < 3; k++) { try { const d = decodeURIComponent(brut); if (d === brut) break; brut = d; } catch { break; } }
          travaux_lies = [...brut.matchAll(/"l"\s*:\s*"([^"]+)"/g)].map(m => m[1]).filter((x, i, a) => a.indexOf(x) === i);
        }
        if (/^\d{2}:\d{2}$/.test(heure) && mc) cours.push({ heure, cours: mc[1], groupe: mc[2] || null,
          nb_travaux: pastille ? (+pastille.getAttribute('data-compteur') || travaux_lies.length || 1) : 0,
          ...(travaux_lies.length ? { travaux_lies } : {}) });
      }
      jours.push({ date: `${anneePour(mois)}-${String(mois).padStart(2, '0')}-${String(q).padStart(2, '0')}`, jour_cycle: cyc, cours });
    }
    return jours;
  };


  const vus = new Map();
  let diagNav = null;
  for (let pas = 0; pas <= moisAvancer; pas++) {
    for (const j of lireMois()) if (!vus.has(j.date) || (!vus.get(j.date).cours.length && j.cours.length)) vus.set(j.date, j);
    if (pas === moisAvancer) break;
    const f = flecheSuivante();
    if (!f) { diagNav = { fleche: 'introuvable', titre: plat(titreMois()) || null,
      cliquables: [...(barre() || document.body).querySelectorAll('a, button, i')].map(x => plat(x)).filter(t => t && t.length < 30).slice(0, 15) }; break; }
    const signature = () => [...casesJour()].map(td => td.getAttribute('data-fullname')).join('|') + '#' + plat(titreMois());
    const avant = signature();
    // Coba répond parfois lentement, ou ignore un clic trop simple : jusqu'à trois essais, de plus en plus appuyés
    let change = false;
    for (let essai = 0; essai < 3 && !change; essai++) {
      const cible = flecheSuivante() || f;
      if (essai === 0) cible.click();
      else for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'])
        cible.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
      for (let i = 0; i < 40; i++) { await sleep(300); if (signature() !== avant && casesJour().length) { change = true; break; } }
    }
    if (!change) { diagNav = { fleche: 'cliquée sans effet', texte: plat(f).slice(0, 30), titre: plat(titreMois()) || null }; break; }
    await sleep(400);
  }
  const jours = [...vus.values()].filter(j => j.cours.length || j.jour_cycle).sort((a, b) => a.date.localeCompare(b.date));
  const moisLus = new Set(jours.map(j => j.date.slice(0, 7))).size;
  return { statut: jours.length ? 'ok' : 'vide', jours, mois_lus: moisLus, diag_navigation: diagNav };
}


// Diagnostic : ouvre une page du menu Coba et renvoie un extrait de sa structure (sans données sensibles,
// tronqué) pour ajuster les lecteurs. N'est utilisé qu'à la demande.
async function cobaDiagPage(nomMenu) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\s+/g, ' ').trim();
  let lien = lienMenuCoba(nomMenu);
  if (!lien) { await deplierMenuCoba(); lien = lienMenuCoba(nomMenu); }
  if (!lien) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  lien.click();
  await sleep(3500);
  const main = document.querySelector('[role=main], main') || document.body;
  // squelette : balises + classes, sans le texte (pour ne pas exposer de données)
  const squelette = el => {
    const tag = el.tagName.toLowerCase();
    const cls = (el.className && typeof el.className === 'string') ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : '';
    return tag + cls;
  };
  const tables = [...main.querySelectorAll('table')].map(tb => ({
    entetes: [...tb.querySelectorAll('th')].map(T).filter(Boolean),
    premiere_ligne: [...(tb.querySelector('tbody tr, tr:nth-child(2), tr') || {}).children || []].map(c => ({ tag: squelette(c), texte: T(c).slice(0, 30) })),
    nb_lignes: tb.querySelectorAll('tr').length
  }));
  const grilles = [...main.querySelectorAll('[class*="day"], [class*="jour"], [role=gridcell], td')].slice(0, 3).map(el => ({ tag: squelette(el), texte: T(el).slice(0, 60) }));

  // HTML anonymisé : lettres -> x, chiffres gardés (dates, heures), pour voir la STRUCTURE sans les données.
  const anon = s => s.replace(/>[^<]+</g, m => '>' + m.slice(1, -1).replace(/[A-Za-zÀ-ÿ]/g, 'x') + '<');
  const court = (el, n = 1500) => el ? anon(el.outerHTML).replace(/\s+/g, ' ').slice(0, n) : null;
  let echantillon = null;
  if (nomMenu === 'Suivi') {
    // la ligne qui contient une date AAAA-MM-JJ, sinon la 2e ligne de la 2e table
    const tr = [...main.querySelectorAll('tr')].find(r => /\d{4}-\d{2}-\d{2}/.test(T(r))) || (main.querySelectorAll('table')[1]?.querySelectorAll('tr')[1]);
    echantillon = { type: 'ligne_suivi', html: court(tr), trouve_par_date: !!(tr && /\d{4}-\d{2}-\d{2}/.test(T(tr))) };
  } else if (nomMenu === 'Agenda') {
    const grille = [...main.querySelectorAll('table')].find(tb => [...tb.querySelectorAll('th')].some(th => /^lundi$/i.test(T(th).trim())));
    const casePleine = grille && [...grille.querySelectorAll('td')].find(td => /\d{2}:\d{2}/.test(T(td)));
    echantillon = { type: 'case_agenda', html_case_pleine: court(casePleine, 2000), html_grille_debut: court(grille, 800) };
  }
  return { statut: 'ok', titre: document.title, tables, grilles, nb_tables: main.querySelectorAll('table').length,
    echantillon, apercu_texte: T(main).slice(0, 300) };
}


// Diagnostic en deux temps, pour les pages qui changent de module (ex. Activités : pednet -> capnet) :
// 1) cliquer l'entrée de menu ; 2) analyser la page courante une fois chargée.
async function cobaCliquerMenu(nomMenu) {
  let lien = lienMenuCoba(nomMenu);
  if (!lien) { await deplierMenuCoba(); lien = lienMenuCoba(nomMenu); }
  if (!lien) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  lien.removeAttribute?.('target');
  setTimeout(() => lien.click(), 50);   // laisser le temps de répondre avant une éventuelle redirection
  return { statut: 'clic', href: lien.getAttribute('href') || '' };
}
async function cobaAnalyserPage(nomMenu) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  await sleep(1500);
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\s+/g, ' ').trim();
  const anon = s => s.replace(/>[^<]+</g, m => '>' + m.slice(1, -1).replace(/[A-Za-zÀ-ÿ]/g, 'x') + '<');
  const main = document.querySelector('[role=main], main, #contenu, .contenu') || document.body;
  const tables = [...main.querySelectorAll('table')].slice(0, 6).map(tb => {
    const lignes = [...tb.querySelectorAll('tr')];
    const ex = lignes.find(tr => tr.querySelector('td')) || lignes[1];
    return { entetes: [...tb.querySelectorAll('th')].map(T).filter(Boolean), nb_lignes: lignes.length,
      classe: tb.className || '', ligne_exemple: ex ? anon(ex.outerHTML).replace(/\s+/g, ' ').slice(0, 1200) : null };
  });
  const titres = [...main.querySelectorAll('h1,h2,h3,h4,.titre,.title,legend')].map(T).filter(Boolean).slice(0, 15);
  // pages sans tableau (cartes, listes) : quelques blocs répétés
  const blocs = tables.length ? [] : [...main.querySelectorAll('li, .card, .carte, [class*="item"], [class*="activ"]')].slice(0, 3)
    .map(el => anon(el.outerHTML).replace(/\s+/g, ' ').slice(0, 1000));
  return { statut: 'ok', page: nomMenu, url_chemin: location.pathname, titre: document.title, nb_tables: main.querySelectorAll('table').length,
    tables, titres, blocs, apercu: T(main).replace(/[A-Za-zÀ-ÿ]/g, 'x').slice(0, 400) };
}

// ---------- Coba : Horaire (profs, locaux, foyer) ----------
// Chaque case : « FRA108-00106 / Simon, N. / D106 ». Lecture par le texte, indépendante de la mise en page.
// Ne lit PAS le courriel, le casier ni le numéro d'élève affichés en haut de la page.
async function cobaHoraire() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const T = el => ((el?.innerText ?? el?.textContent) || '').replace(/\u00a0/g, ' ');
  let lien = lienMenuCoba('Horaire');
  if (!lien) { await deplierMenuCoba(); lien = lienMenuCoba('Horaire'); }
  if (!lien) return { statut: 'menu_introuvable', liens: liensMenuCoba() };
  lien.click();
  const reCase = /([A-Z]{3}\d{3})-(\d+)\s*\n\s*([^\n]+?)\s*\n\s*([A-Z]\d{3}[A-Z]?)\b/g;
  let texte = '', n = 0, prec = -1, st = 0;
  for (let i = 0; i < 50; i++) {
    await sleep(300);
    texte = T(document.body); n = (texte.match(reCase) || []).length;
    if (n >= 10 && n === prec) { if (++st >= 2) break; } else st = 0;
    prec = n;
  }
  if (!n) return { statut: 'grille_introuvable' };
  const cases = [...texte.matchAll(reCase)].map(m => ({ cours: m[1], groupe: m[2], prof: m[3].trim(), local: m[4] }));
  const foyer = (texte.match(/Foyer\s*\n?\s*(\d{2,4})/) || [])[1] || null;
  const titulaire = (texte.match(/Titulaire\s*\n?\s*([^\n]+)/) || [])[1]?.trim() || null;
  return { statut: 'ok', cases, foyer, titulaire };
}

// ---------- CapNet : activités ----------
// CapNet s'ouvre sur son Accueil : on clique « Mes activités », puis on lit le tableau
// « Description / Date début / Date fin ». On ne déplie pas le détail : il ne contient pas d'horaire,
// seulement des remarques, les frais et les modalités de paiement.
async function capnetActivites() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const TC = el => (el?.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const lignesAct = () => [...document.querySelectorAll('tr')].filter(tr => /\d{4}-\d{2}-\d{2}.*\d{4}-\d{2}-\d{2}/.test(TC(tr)) && tr.querySelectorAll('td').length >= 3);
  // aller sur « Mes activités » si la liste n'est pas déjà là
  for (let i = 0; i < 20 && !lignesAct().length; i++) {
    const lien = lienMenuCoba('Mes activités') || [...document.querySelectorAll('a')].find(a => /Mes activités/i.test(TC(a)));
    if (lien) { lien.click(); break; }
    await sleep(300);
  }
  let lignes = [];
  for (let i = 0; i < 60; i++) { await sleep(300); lignes = lignesAct(); if (lignes.length) break; }
  if (!lignes.length) return { statut: 'liste_vide', diag: { url_chemin: location.pathname, titre: document.title, nb_tr: document.querySelectorAll('tr').length,
    a_inscrit: /INSCRIT/i.test(document.body.textContent), lien_mes_activites: [...document.querySelectorAll('a')].some(a => TC(a).endsWith('Mes activités')) } };
  // section de chaque ligne (Inscrit, En attente, Terminé, Annulé) : le titre de section qui précède
  const out = lignes.map(tr => {
    const cel = [...tr.children].map(TC);
    const dates = TC(tr).match(/\d{4}-\d{2}-\d{2}/g) || [];
    const titre = cel.find(x => x && !/^\d{4}-\d{2}-\d{2}$/.test(x) && !/^\d+$/.test(x) && !/^(keyboard_arrow_\w+|expand_\w+|chevron_\w+)$/i.test(x)) || '';
    let sec = '', p = tr.closest('table'); for (let k = 0; k < 6 && p && !sec; k++) { const pr = p.previousElementSibling; const m = TC(pr).match(/^(INSCRIT|EN ATTENTE|TERMINÉ|ANNULÉ)/i); if (m) sec = m[1].toLowerCase(); p = p.parentElement; }
    return { titre, debut: dates[0] || null, fin: dates[1] || null, statut: sec || 'inscrit' };
  });
  return { statut: 'ok', activites: out };
}

Object.assign(globalThis, {
  platMenu, lienMenuCoba, liensMenuCoba, deplierMenuCoba, attendreLienMenu,
  cobaCollect, cobaCourriels, cobaLogin, classroomCollect, cobaSuivi, cobaAgenda,
  cobaDiagPage, cobaCliquerMenu, cobaAnalyserPage, cobaHoraire, capnetActivites
});
