importScripts('defaults.js', 'collectors.js', 'normalize.js', 'secret.js', 'ia.js', 'relais.js', 'annonces.js', 'convertir.js');

const sleep = ms => new Promise(r => setTimeout(r, ms));
let running = false;      // une collecte est en cours
let testEnCours = false;  // un test de connexion est en cours
let annulerDemande = false; // l'utilisateur a demandé d'arrêter

// Au (re)démarrage du service : si un état « en cours » est resté (service arrêté par Chrome
// en pleine collecte), le remettre à zéro pour ne pas bloquer les boutons.
chrome.storage.local.get('etat').then(({ etat }) => {
  if (etat?.enCours) chrome.storage.local.set({ etat: { enCours: false, erreur: 'collecte interrompue (relancez-la)' } });
});

async function settings() {
  const { reglages } = await chrome.storage.local.get('reglages');
  const s = { ...DEFAULTS, ...(reglages || {}) };
  // …/pednet/index.coba (page d'accueil, souvent copiée depuis la barre d'adresse) -> page de connexion
  s.cobaUrl = adresseConnexionCoba(s.cobaUrl);
  if (reglages && reglages.ollama === true && !reglages.moteurIA) s.moteurIA = 'ollama';
  // Les versions de test 0.8.1 à 0.9.12 avaient enregistré suivi/agenda/descriptions à false. On retire
  // ces valeurs du STOCKAGE (une seule fois), pour qu'un futur « Enregistrer » ne les réécrive pas.
  if (reglages && !reglages.reglagesV2) {
    const propres = { ...reglages, reglagesV2: true };
    for (const k of ['suivi', 'agenda', 'descriptions', 'diag']) delete propres[k];
    await chrome.storage.local.set({ reglages: propres });
    Object.assign(s, { suivi: DEFAULTS.suivi, agenda: DEFAULTS.agenda, descriptions: DEFAULTS.descriptions });
  }
  return s;
}

async function log(msg, niveau = 'info') {
  const { journal = [] } = await chrome.storage.local.get('journal');
  journal.unshift({ t: new Date().toISOString(), niveau, msg });
  await chrome.storage.local.set({ journal: journal.slice(0, 80) });
}

async function setStatus(etat) { await chrome.storage.local.set({ etat }); }

// ---------- Onglets de travail (dans la fenêtre active, en arrière-plan) ----------
// On ouvre les pages dans un onglet NON actif de la fenêtre courante : il se rend correctement
// (contrairement à une fenêtre d'arrière-plan qui reste « noire »), sans voler le focus. Il peut
// apparaître brièvement dans la barre d'onglets, puis se ferme.
async function fenetreActive() {
  try { const w = await chrome.windows.getLastFocused({ windowTypes: ['normal'] }); if (w) return w.id; } catch {}
  try { const ws = await chrome.windows.getAll({ windowTypes: ['normal'] }); if (ws[0]) return ws[0].id; } catch {}
  const w = await chrome.windows.create({ url: 'about:blank', focused: false });   // aucune fenêtre : en créer une
  return w.id;
}
// Mémorise l'onglet actif pour pouvoir y revenir après une ouverture furtive.
async function ongletActifCourant(windowId) {
  try { const [t] = await chrome.tabs.query({ active: true, windowId }); return t?.id; } catch { return undefined; }
}
let winCachee = null;
async function fenetreCachee() {
  if (winCachee != null) { try { await chrome.windows.get(winCachee); return winCachee; } catch { winCachee = null; } }
  let w;
  try { w = await chrome.windows.create({ url: 'about:blank', focused: false, left: -32000, top: 0, width: 480, height: 400 }); }   // petite : Chrome la garde hors écran
  catch { w = await chrome.windows.create({ url: 'about:blank', focused: false }); }
  winCachee = w.id;
  try { await chrome.windows.update(w.id, { state: 'minimized' }); } catch {}
  return w.id;
}

// Ouvre `url` et garantit que la page a RENDU. Essaie d'abord caché (invisible), bascule furtif si besoin.
// estRendu(tabId) : fonction qui renvoie true dès que la page a affiché quelque chose d'exploitable.
async function ouvrirEtRendre(url, estRendu, { timeoutRendu = 3500 } = {}) {
  // --- Tentative 1 : fenêtre cachée, totalement invisible ---
  let mode = 'cache';
  const winId = await fenetreCachee();
  let tab = await chrome.tabs.create({ windowId: winId, url, active: true });   // actif DANS la fenêtre cachée
  ongletsCollecte.add(tab.id);
  const t0 = Date.now();
  let rendu = false;
  while (Date.now() - t0 < timeoutRendu) {
    await sleep(300);
    try { if (await estRendu(tab.id)) { rendu = true; break; } } catch {}
  }
  if (rendu) return { tab, mode };

  // --- Tentative 2 : la page cachée n'a pas rendu -> basculer en furtif dans la fenêtre active ---
  mode = 'furtif';
  const windowId = await fenetreActive();
  const retour = await ongletActifCourant(windowId);
  try { await chrome.tabs.move(tab.id, { windowId, index: -1 }); await chrome.tabs.update(tab.id, { active: true }); }
  catch {
    // si le déplacement échoue, recréer l'onglet dans la fenêtre active
    await fermerOnglet(tab.id);
    tab = await chrome.tabs.create({ windowId, url, active: true });
    ongletsCollecte.add(tab.id);
  }
  tab.__retour = retour;
  const t1 = Date.now();
  while (Date.now() - t1 < timeoutRendu) {
    await sleep(300);
    try { if (await estRendu(tab.id)) break; } catch {}
  }
  return { tab, mode };
}

// Ancienne API conservée pour la collecte (onglet furtif simple).
async function ongletCache(url, { furtif = false } = {}) {
  const windowId = await fenetreActive();
  const retour = furtif ? await ongletActifCourant(windowId) : undefined;
  const tab = await chrome.tabs.create({ windowId, url, active: furtif });
  ongletsCollecte.add(tab.id);
  if (furtif && retour != null) tab.__retour = retour;
  return tab;
}
// Rend le focus à l'onglet d'origine (après qu'un onglet furtif a chargé).
async function rendreFocus(tab) {
  if (tab?.__retour != null) { try { await chrome.tabs.update(tab.__retour, { active: true }); } catch {} }
}

// Ouvre un onglet en arrière-plan et attend qu'il ait fini de charger (redirections comprises)
async function openAndWait(url, { timeout = 30000, until, furtif = false } = {}) {
  const tab = await ongletCache(url, { furtif });
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    await sleep(250);
    let t;
    try { t = await chrome.tabs.get(tab.id); } catch { throw new Error('onglet fermé'); }
    if (t.status === 'complete' && t.url && !/^https:\/\/c\.gle\//.test(t.url) && (!until || until(t.url))) return t;
  }
  return chrome.tabs.get(tab.id);
}

// Attend l'état final de la page : le portail (index.coba) dès qu'il apparaît, sinon le formulaire
// (login.coba) une fois stable. Évite de conclure « formulaire » pendant une redirection vers le portail.
async function attendreUrlStable(tabId, timeout = 20000) {
  const t0 = Date.now();
  let urlPrec = null, stable = 0, dernier = null;
  while (Date.now() - t0 < timeout) {
    let t; try { t = await chrome.tabs.get(tabId); } catch { return null; }
    dernier = t;
    if (t.url && COBA_CONNECTE.test(t.url)) return t;   // portail atteint : état final, on sort tout de suite
    if (t.status === 'complete' && t.url && /login\.coba/.test(t.url)) {
      if (t.url === urlPrec) { if (++stable >= 6) return t; } else { stable = 0; urlPrec = t.url; }   // login stable ~1,8 s
    } else stable = 0;
    await sleep(300);
  }
  return dernier;
}

// Délai par opération : les lectures qui ouvrent beaucoup d'éléments un par un (descriptions des
// travaux, détails du suivi, courriels, contenus Classroom) ont besoin de plus que 45 s la première fois.
const DELAIS = { cobaCourriels: 300000, cobaHoraire: 30000, capnetActivites: 60000, cobaCollect: 240000, cobaSuivi: 180000, classroomCollect: 240000, cobaAgenda: 60000 };
async function run(func, tabId, args = [], world = 'ISOLATED') {
  const name = func.name;
  if (!name) throw new Error('collecteur sans nom');
  await chrome.scripting.executeScript({ target: { tabId }, files: ['collectors.js'], world });
  const exec = chrome.scripting.executeScript({
    target: { tabId }, world,
    func: async (name, args) => {
      const fn = globalThis[name];
      if (typeof fn !== 'function') throw new Error('collecteur absent : ' + name);
      return await fn(...args);
    },
    args: [name, args]
  });
  const ms = DELAIS[name] || 45000;
  const limite = new Promise((_, rej) => setTimeout(() => rej(new Error(`page sans réponse après ${Math.round(ms / 1000)} s`)), ms));
  const [res] = await Promise.race([exec, limite]);
  return res?.result;
}

// Sonde sérialisée dans la page : Travaux même replié (textContent), ou formulaire de connexion.
function sondeCobaDansPage() {
  const plat = el => (el?.textContent || '').replace(/\s+/g, ' ');
  const travaux = [...document.querySelectorAll('a')].some(a => /(^|\s)Travaux(\s|$)/i.test(plat(a)));
  const login = [...document.querySelectorAll('input[type=password]')].some(e => e.getClientRects().length);
  return {
    travaux, login,
    portail: travaux || /Mon dossier|Portail parent|Responsable de/.test(document.body?.textContent || ''),
    responsable: ((document.body?.textContent || '').match(/Responsable de ([^\n]+)/) || [])[1]?.trim() || '',
    url: location.href, titre: document.title, nbLiens: document.querySelectorAll('a').length
  };
}

// Injecte le script "page visible" directement dans un onglet déjà chargé (en plus de l'enregistrement
// global, qui ne vaut que pour les prochains chargements).
async function injecterVisibilite(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['visible.js'], world: 'MAIN' }); } catch {}
}

function notify(titre, message) {
  chrome.notifications.create({ type: 'basic', iconUrl: 'icons/128.png', title: titre, message });
}

// ---------- Coba ----------
const COBA_CONNECTE = /\/(index|accueil)\.coba/i;   // page du portail après connexion

async function attendreConnexionCoba(tabId, timeout = 5 * 60000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    await sleep(400);
    let t;
    try { t = await chrome.tabs.get(tabId); } catch { return false; }   // onglet fermé
    if (COBA_CONNECTE.test(t.url || '')) {
      // URL du portail atteinte : confirmer l'affichage du menu, sans trop attendre
      for (let i = 0; i < 8; i++) {
        try {
          const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: sondeCobaDansPage });
          if (r?.result?.portail) return true;
        } catch {}
        await sleep(400);
      }
      return true;
    }
  }
  return false;
}

// ---------- Connexion Coba robuste ----------
// Décrit la page (tous les cadres) pour le diagnostic, sans jamais lire les valeurs saisies.
function decrirePage() {
  return {
    url: location.href, titre: document.title, cadre: window !== window.top,
    iframes: [...document.querySelectorAll('iframe,frame')].map(f => f.src || '(sans adresse)').slice(0, 5),
    champs: [...document.querySelectorAll('input,select')].filter(e => e.type !== 'hidden').map(e => `${e.type || e.tagName.toLowerCase()}${e.name ? ':' + e.name : ''}${e.id ? '#' + e.id : ''}`).slice(0, 15),
    boutons: [...document.querySelectorAll('button,input[type=submit],input[type=button],a')].map(b => ((b.innerText || b.value || '')).trim()).filter(Boolean).slice(0, 12),
    extrait: (document.body?.innerText || '').trim().slice(0, 300)
  };
}

// Essaie de remplir et soumettre le formulaire, dans la page ou dans un de ses cadres,
// en réessayant si la page se recharge pendant l'opération.
// Remplit et soumet le formulaire, dans la page et ses cadres, UNE seule fois.
// Le formulaire a déjà été confirmé présent par la sonde ; inutile de réattendre ou de boucler.
async function soumettreConnexion(tabId, id) {
  let resultats = [];
  try {
    resultats = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: cobaLogin, args: [id.u, id.p] });
  } catch (e) { return { ok: false, raison: 'injection impossible : ' + e.message }; }
  const r = resultats.map(x => x?.result).filter(Boolean);
  return r.find(x => x.ok) || r[0] || { ok: false, raison: 'formulaire de connexion introuvable' };
}

async function diagnosticPage(tabId) {
  try {
    const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: decrirePage });
    return res.map(x => x.result).filter(Boolean);
  } catch (e) { return [{ erreur: e.message }]; }
}

// ---------- Test de connexion Coba (invisible) ----------
async function testerConnexionCoba(u, p) {
  const s = await settings();
  const id = (u && p) ? { u, p } : await lireIdentifiants();
  if (!id) return { ok: false, raison: 'Aucun identifiant saisi ni enregistré.' };
  // Réglages incomplets (nouvel ordinateur) : le dire clairement plutôt que d'ouvrir une page vide
  const org = origineCoba(s);
  if (!org) return { ok: false, raison: 'L’adresse du portail Coba n’est pas renseignée : saisissez-la plus haut dans les Réglages, puis Enregistrer.' };
  if (!(await chrome.permissions.contains({ origins: [org + '/*'] })))
    return { ok: false, raison: 'L’extension n’a pas encore l’autorisation d’ouvrir ' + org + ' : cliquez sur Enregistrer dans les Réglages et acceptez la demande de Chrome.' };
  const VER = chrome.runtime.getManifest().version;
  const t0 = Date.now();
  const jalons = {};
  const jalon = n => { jalons[n] = Math.round((Date.now() - t0) / 100) / 10; };
  let tabId, tabInfo;
  testEnCours = true; testDepuis = Date.now();
  try {
    await activerVisibilite(true, ['coba']);
    // Sonde : que voit-on sur la page ? portail (menu Travaux) ou login (champ mot de passe visible).
    const sonderTab = async tid => {
      try {
        const [r] = await chrome.scripting.executeScript({ target: { tabId: tid }, func: sondeCobaDansPage });
        const v = r?.result || {};
        return { ...v, login: v.login && !v.portail };
      } catch (e) { return { err: String(e) }; }
    };

    // Ouvrir Coba : caché si possible, furtif en secours. "Rendu" = on voit déjà portail ou login.
    const { tab, mode } = await ouvrirEtRendre(s.cobaUrl, async tid => {
      await injecterVisibilite(tid);
      const v = await sonderTab(tid); return v.portail || v.login;
    });
    tabInfo = tab; tabId = tab.id;
    jalons.mode = mode;   // 'cache' (invisible) ou 'furtif' (onglet bref)
    const sonder = () => sonderTab(tabId);

    // Laisser la page arriver dans un état décidable (portail ou formulaire), max ~15 s.
    let vu = {};
    for (let i = 0; i < 30; i++) {
      await injecterVisibilite(tabId);
      vu = await sonder();
      if (vu.portail || vu.login) break;
      await sleep(500);
    }
    jalon('etat_vu');
    jalons.etat = vu.portail ? 'portail' : vu.login ? 'login' : 'indetermine';

    // 2. Déjà sur le portail : succès immédiat, aucune connexion tentée.
    // 3. Sinon, si un champ mot de passe est visible : se connecter, puis attendre le portail.
    if (!vu.portail && vu.login) {
      const res = await soumettreConnexion(tabId, id);
      jalon('formulaire_soumis');
      for (let i = 0; i < 50; i++) {   // attendre que le portail apparaisse après connexion, max ~25 s
        await injecterVisibilite(tabId);
        vu = await sonder();
        if (vu.portail) break;
        await sleep(500);
      }
      jalon('apres_connexion');
      if (!vu.portail) {
        let msg = res?.erreur;
        if (!msg) { try { const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () =>
          [...document.querySelectorAll('.error,.erreur,.alert,[role=alert],.message,.msg')].map(e => (e.innerText || '').trim()).filter(Boolean).join(' | ').slice(0, 200) }); msg = r?.result; } catch {} }
        const r0 = (typeof msg === 'string' && msg) || res?.raison || 'Identifiant ou mot de passe refusé (le portail ne s’est pas ouvert)';
        return { ok: false, raison: String(r0).replace(/^./, c => c.toUpperCase()) + '.', version: VER, jalons, vu };
      }
    }

    if (!vu.portail) {   // ni portail, ni formulaire : page bloquée
      const diag = await diagnosticPage(tabId);
      return { ok: false, raison: 'Le portail Coba ne s’est pas affiché (page restée en chargement).', version: VER, jalons, vu, diag };
    }

    // 4. Succès : enregistrer les identifiants si saisis.
    let enregistre = false;
    if (u && p) { try { await enregistrerIdentifiants(u, p); enregistre = true; } catch {} }
    else await chrome.storage.local.remove('echecConnexion');
    jalon('fin');
    return { ok: true, responsable: vu.responsable, enregistre, duree: jalons.fin, version: VER, jalons };
    } finally {
    testEnCours = false;
    await rendreFocus(tabInfo);           // si mode furtif : rendre le focus à l'onglet d'origine
    await fermerOnglet(tabId);
    await fermerFenetreCacheeSiVide();    // si mode caché : refermer la fenêtre cachée
    await activerVisibilite(false);
  }
}

// Ferme un onglet de collecte précis.
async function fermerOnglet(tabId) {
  if (tabId == null) return;
  ongletsCollecte.delete(tabId);
  await chrome.tabs.remove(tabId).catch(() => {});
}
// Ferme la fenêtre cachée si plus aucun onglet de collecte n'y reste.
async function fermerFenetreCacheeSiVide() {
  if (winCachee == null) return;
  try {
    const w = await chrome.windows.get(winCachee, { populate: true });
    const utiles = (w.tabs || []).filter(t => ongletsCollecte.has(t.id));
    const vides = (w.tabs || []).filter(t => /^about:blank$/.test(t.url || '') || t.url === '');
    if (!utiles.length) { await chrome.windows.remove(winCachee).catch(() => {}); winCachee = null; }
  } catch { winCachee = null; }
}
// Rend le focus à un onglet mémorisé (après fermeture d'un onglet furtif).
async function rendreFocusVers(retour) {
  if (retour != null) { try { await chrome.tabs.update(retour, { active: true }); } catch {} }
}

async function connexionAuto(tab, s, auto) {
  const id = await lireIdentifiants();
  if (!id) { await log('Coba : aucun identifiant enregistré (Réglages)'); return false; }
  // Après un échec, on ne réessaie pas tout seul pendant 6 h (pour ne pas bloquer le compte)
  const { echecConnexion } = await chrome.storage.local.get('echecConnexion');
  if (auto && echecConnexion && Date.now() - echecConnexion.t < 6 * 3600e3) {
    await log('Coba : connexion automatique suspendue après un échec récent', 'alerte'); return false;
  }
  await setStatus({ enCours: true, etape: 'Connexion automatique à Coba' });
  if (!/login\.coba/.test(tab.url || '')) {
    await chrome.tabs.update(tab.id, { url: s.cobaUrl });
    await attendreOnglet(tab.id, u => /login\.coba|index\.coba/.test(u), 20000);
  }
  const res = await soumettreConnexion(tab.id, id);
  const reussi = res?.ok && await attendreConnexionCoba(tab.id, 30000);
  if (reussi) { await chrome.storage.local.remove('echecConnexion'); await log('Coba : connexion automatique réussie'); return true; }
  const detail = { t: Date.now(), raison: res?.raison || res?.erreur || 'pas de redirection vers le portail', pages: await diagnosticPage(tab.id) };
  await chrome.storage.local.set({ echecConnexion: detail });
  await log(`Coba : connexion automatique échouée — ${detail.raison}`, 'alerte');
  return false;
}

async function collectCoba(s, auto = false) {
  const fin = (statut, extra = {}) => ({ statut, collecte_le: new Date().toISOString(), ...extra });
  const org = origineCoba(s);
  if (!org) { await log('Coba : adresse du portail non configurée (Réglages)', 'alerte'); return fin('non_configure'); }
  if (!(await chrome.permissions.contains({ origins: [org + '/*'] }))) {
    await log('Coba : autorisation d’accès au portail manquante (Réglages → Enregistrer)', 'alerte'); return fin('permission_manquante');
  }
  await activerVisibilite(true, ['coba']);
  const { cacheDescriptions = {} } = await chrome.storage.local.get('cacheDescriptions');
  let r = null, tab = null, ouvert = false;

  // On ne réutilise JAMAIS un onglet Coba de l'utilisateur : la collecte y cliquerait partout sous ses yeux.
  // Elle ouvre toujours son propre onglet caché (la session du navigateur évite souvent de se reconnecter).
  if (r?.statut !== 'ok') {
    await log('Coba : ouverture de la page de connexion');
    const res = await ouvrirEtRendre(s.cobaUrl, async tid => {
      await injecterVisibilite(tid);
      try { const [v] = await chrome.scripting.executeScript({ target: { tabId: tid }, func: sondeCobaDansPage }); return !!(v?.result?.travaux || v?.result?.login); } catch { return false; }
    });
    tab = res.tab; ouvert = true;
    try { r = await run(cobaCollect, tab.id, [cacheDescriptions, !!s.descriptions]); } catch (e) { r = { statut: 'erreur', message: String(e) }; }

    // 3. Connexion nécessaire : d'abord automatiquement avec les identifiants chiffrés
    if (r?.statut === 'connexion_requise') {
      const ok = await connexionAuto(tab, s, auto);
      if (ok) {
        await setStatus({ enCours: true, etape: 'Coba' });
        try { r = await run(cobaCollect, tab.id, [cacheDescriptions, !!s.descriptions]); } catch (e) { r = { statut: 'erreur', message: String(e) }; }
      }
    }
    // 4. Sinon, connexion à la main (seulement si la collecte a été lancée à la main)
    if (r?.statut === 'connexion_requise') {
      if (auto) {
        await fermerOnglet(tab.id);
        notify('Coba : connexion impossible', 'La collecte automatique n’a pas pu se connecter. Vérifiez les identifiants dans les Réglages.');
        return fin('connexion_requise');
      }
      try {
        const [vis] = await chrome.windows.getAll({ windowTypes: ['normal'] });
        if (vis && vis.id !== tab.windowId) await chrome.tabs.move(tab.id, { windowId: vis.id, index: -1 });
        await chrome.tabs.update(tab.id, { active: true });
        await chrome.windows.update((vis || tab).id, { focused: true, state: 'normal' }).catch(() => {});
      } catch {}
      notify('Coba : connexion requise', 'Connectez-vous dans l’onglet Coba. La collecte reprendra toute seule.');
      await log('Coba : en attente de votre connexion (5 min max)', 'alerte');
      await setStatus({ enCours: true, etape: 'En attente de votre connexion à Coba' });
      if (!(await attendreConnexionCoba(tab.id))) {
        await log('Coba : connexion non faite à temps', 'alerte');
        return fin('connexion_requise');
      }
      await log('Coba : connecté, lecture des travaux');
      await setStatus({ enCours: true, etape: 'Coba' });
      try { r = await run(cobaCollect, tab.id, [cacheDescriptions, !!s.descriptions]); } catch (e) { r = { statut: 'erreur', message: String(e) }; }
    }
  }

  let courriels;
  if (r?.statut === 'ok' && s.courriels) {
    await setStatus({ enCours: true, etape: 'Coba : courriels' });
    const { cacheCourriels = {} } = await chrome.storage.local.get('cacheCourriels');
    try {
      const c = await run(cobaCourriels, tab.id, [Object.keys(cacheCourriels).filter(k => cacheCourriels[k].texte), !!s.ouvrirCourriels, 30, 3]);
      courriels = (c?.courriels || []).map(m => {
        if (m.texte_en_cache && cacheCourriels[m.cle]) return { ...m, texte: cacheCourriels[m.cle].texte };
        if (m.texte) cacheCourriels[m.cle] = { texte: m.texte, vu: Date.now() };
        return m;
      });
      await chrome.storage.local.set({ cacheCourriels });
      await log(`Coba : ${courriels.length} courriels sur ${c?.pages_lues || 1} page(s) (${courriels.filter(m => m.texte && !m.texte_en_cache).length} nouveaux ouverts)`);
    } catch (e) { await log('Coba : courriels — ' + e, 'alerte'); }
  }
  if (r?.statut !== 'ok') {
    if (ouvert) { await fermerOnglet(tab.id); await fermerFenetreCacheeSiVide(); }
    await activerVisibilite(false);
    const apercuMenu = (r?.liens || []).filter(t => t && t.length < 40).slice(0, 12).join(', ');
    await log(`Coba : ${r?.statut || 'échec'} ${r?.raison || r?.message || ''}${apercuMenu ? ' — menu : ' + apercuMenu : (r?.extrait ? ' — ' + String(r.extrait).slice(0, 120) : '')}`.replace(/\s+/g, ' ').trim(), 'alerte');
    return fin(r?.statut || 'erreur', { detail: r });
  }
  // Mémoriser les descriptions pour ne pas rouvrir les travaux inchangés la prochaine fois
  // « Aucune description » est le texte de Coba quand le prof n'a rien écrit : ce n'est pas une description
  for (const t of r.travaux) if (/^aucune\s+description\.?$/i.test((t.description || '').trim())) t.description = '';
  for (const t of r.travaux) {
    if (t.description !== undefined) cacheDescriptions[t.cle] = { description: t.description, date_due: t.date_due || null, vu: Date.now() };
    else if (cacheDescriptions[t.cle]) t.description = cacheDescriptions[t.cle].description;
  }
  await chrome.storage.local.set({ cacheDescriptions });
  const travaux = r.travaux.map(normTravail);
  await log(`Coba : ${travaux.length} travaux, ${r.competences.length} compétences, ${r.descriptions_ouvertes || 0} descriptions lues${r.descriptions_ratees ? ' (' + r.descriptions_ratees + ' fiches non ouvertes)' : ''}`);

  // Suivi (commentaires des profs)
  let suivi;
  if (s.suivi !== false) {
    await setStatus({ enCours: true, etape: 'Coba : suivi' });
    const { cacheSuivi = {} } = await chrome.storage.local.get('cacheSuivi');
    const connusS = Object.fromEntries(Object.entries(cacheSuivi).map(([k, v]) => [k, { detail: v.detail }]));
    try {
      const sv = await run(cobaSuivi, tab.id, [connusS]);
      if (sv?.statut === 'ok') {
        for (const it of sv.items) if (it.detail) cacheSuivi[it.cle] = { detail: it.detail, vu: Date.now() };
        await chrome.storage.local.set({ cacheSuivi });
        suivi = { entrees: sv.items, par_type: sv.parType, par_regroupement: sv.parRegr, sommaire_coba: sv.sommaire };
        await log(`Coba : ${sv.items.length} entrées de suivi, ${sv.details_ouverts} détails lus`);
      } else { suivi = { erreur: sv?.statut || 'résultat vide', detail_brut: sv, sommaire_coba: sv?.sommaire }; await log('Coba : suivi — ' + (sv?.statut || 'vide') + (sv?.diag ? ` (lignes : ${sv.diag.nb_grid3} grid3, ${sv.diag.nb_tr_table_liste} dans la table)` : ''), 'alerte'); }
    } catch (e) { suivi = { erreur: String(e) }; await log('Coba : suivi — ' + e, 'alerte'); }
  }
  // Agenda (horaire jour par jour + notes)
  let agenda, agendaDiag;
  if (s.agenda !== false) {
    await setStatus({ enCours: true, etape: 'Coba : agenda' });
    try { const ag = await run(cobaAgenda, tab.id, [s.agendaMois ?? 1]); if (ag?.statut === 'ok') { agenda = ag.jours; agendaDiag = ag.diag_navigation; await log(`Coba : agenda ${agenda.length} jours sur ${ag.mois_lus} mois${ag.diag_navigation ? ' (mois suivant : ' + ag.diag_navigation.fleche + ')' : ''}`); } else { agenda = { erreur: ag?.statut || 'résultat vide' }; await log('Coba : agenda — ' + (ag?.statut || 'vide'), 'alerte'); } }
    catch (e) { agenda = { erreur: String(e) }; await log('Coba : agenda — ' + e, 'alerte'); }
  }
  // Horaire : profs, locaux et foyer (groupe-classe)
  let horaire;
  if (s.horaire !== false) {
    await setStatus({ enCours: true, etape: 'Coba : horaire' });
    try { const ho = await run(cobaHoraire, tab.id); horaire = ho?.statut === 'ok' ? { cases: ho.cases, foyer: ho.foyer, titulaire: ho.titulaire } : { erreur: ho?.statut || 'vide' };
      await log(`Coba : horaire ${ho?.cases?.length || 0} cases${ho?.foyer ? ', foyer ' + ho.foyer : ''}`); }
    catch (e) { horaire = { erreur: String(e) }; await log('Coba : horaire — ' + e, 'alerte'); }
  }
  // Activités : dans le module CapNet. Coba l'ouvre dans un NOUVEL onglet (par son propre code).
  // On surveille cet onglet, on le range dans la fenêtre cachée, on le lit, puis on le ferme.
  let activites;
  if (s.activites !== false) {
    await setStatus({ enCours: true, etape: 'Coba : activités' });
    const org = origineCoba(s);
    const estCapnet = u => !!u && u.startsWith(org) && /\/capnet\//.test(u);
    let nouvel = null;
    const surCreation = t => { if (!nouvel && (t.openerTabId === tab.id || estCapnet(t.pendingUrl || t.url))) { nouvel = t.id;
      chrome.windows.get(t.windowId, { populate: true }).then(w => { if (w.tabs.length <= 1) chrome.windows.update(t.windowId, { state: 'minimized' }); }).catch(() => {}); } };
    const surMaj = (id, info, t) => { if (!nouvel && estCapnet(info.url || t.url) && id !== tab.id) nouvel = id; };
    chrome.tabs.onCreated.addListener(surCreation); chrome.tabs.onUpdated.addListener(surMaj);
    let capTab = null;
    try {
      // Coba ouvre CapNet par window.open (nouvel onglet). On remplace window.open, dans la page,
      // par une navigation de l'onglet courant : CapNet se charge dans l'onglet caché, aucun onglet visible.
      try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: () => {
        window.open = function (u) { if (u) location.href = new URL(u, location.href).href;
          return { focus() {}, close() {}, blur() {}, closed: false, location: {}, document: { write() {}, close() {} } }; };
      } }); } catch {}
      const [cl] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => {
        const plat = x => (x.textContent || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
        const a = [...document.querySelectorAll('a')].find(x => /(^|\s)Activités(\s|$)/i.test(plat(x)) && plat(x).length < 60);
        if (!a) return 'menu_introuvable';
        a.removeAttribute('target');
        setTimeout(() => a.click(), 50); return 'clic';
      } });
      if (cl?.result !== 'clic') activites = { erreur: cl?.result || 'clic impossible' };
      else {
        // attendre soit un nouvel onglet CapNet, soit la navigation de notre propre onglet
        for (let i = 0; i < 60 && capTab == null; i++) {
          await sleep(250);
          if (nouvel != null) capTab = nouvel;
          else { try { const t = await chrome.tabs.get(tab.id); if (estCapnet(t.url)) capTab = tab.id; } catch {} }
        }
        if (capTab == null) activites = { erreur: 'page CapNet non atteinte' };
        else {
          let lecture = capTab;
          if (capTab !== tab.id) {
            ongletsCollecte.add(capTab);
            // 1. relever l'adresse CapNet, fermer l'onglet visible, rouvrir l'adresse dans NOTRE onglet caché
            const t = await attendreOnglet(capTab, estCapnet, 20000);
            const url = t && estCapnet(t.url) ? t.url : null;
            let fen = null; try { fen = (await chrome.tabs.get(capTab)).windowId; } catch {}
            if (url) {
              await fermerOnglet(capTab);
              try { const w = await chrome.windows.get(fen, { populate: true }); if (w && w.tabs.length === 0) await chrome.windows.remove(fen); } catch {}
              await chrome.tabs.update(tab.id, { url });
              const t2 = await attendreOnglet(tab.id, () => true, 20000);
              if (t2 && estCapnet(t2.url)) { lecture = tab.id; capTab = null; }
              else lecture = null;   // l'adresse ne marche pas une 2e fois
            }
            // 2. secours : lire dans l'onglet ouvert par Coba, en réduisant sa fenêtre
            if (lecture == null || (capTab != null && lecture === capTab)) {
              if (capTab != null) { try { const w = (await chrome.tabs.get(capTab)).windowId; await chrome.windows.update(w, { state: 'minimized' }); } catch {} lecture = capTab; }
            }
          }
          if (lecture == null) activites = { erreur: 'adresse CapNet non réutilisable' };
          else {
            await injecterVisibilite(lecture);
            const ac = await run(capnetActivites, lecture);
            activites = ac?.statut === 'ok' ? ac.activites : { erreur: ac?.statut || 'vide', diag: ac?.diag };
          }
        }
      }
      await log(`Coba : activités ${Array.isArray(activites) ? activites.length : '— ' + activites.erreur}`, Array.isArray(activites) ? 'info' : 'alerte');
    } catch (e) { activites = { erreur: String(e) }; await log('Coba : activités — ' + e, 'alerte'); }
    finally {
      chrome.tabs.onCreated.removeListener(surCreation); chrome.tabs.onUpdated.removeListener(surMaj);
      if (capTab != null && capTab !== tab.id) { await fermerOnglet(capTab); }
    }
  }
  if (ouvert) { await fermerOnglet(tab.id); await fermerFenetreCacheeSiVide(); }
  await activerVisibilite(false);
  return fin('ok', { travaux, competences: r.competences, courriels, suivi, agenda, agenda_diag: agendaDiag || undefined, horaire, activites });
}

// ---------- Classroom ----------
async function attendreOnglet(tabId, until, timeout = 20000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    await sleep(250);
    let t; try { t = await chrome.tabs.get(tabId); } catch { return null; }
    if (t.status === 'complete' && t.url && !/^https:\/\/c\.gle\//.test(t.url) && until(t.url)) return t;
  }
  return chrome.tabs.get(tabId).catch(() => null);
}

// Origine du portail Coba (ex. https://portail.mon-ecole.qc.ca), tirée de l'adresse dans les Réglages
function origineCoba(s) { try { return new URL(s.cobaUrl).origin; } catch { return null; } }

async function activerVisibilite(on, cibles = ['classroom']) {
  const s = await settings();
  const CIBLES_VISIBILITE = {
    classroom: { id: 'moncap-vis-classroom', js: ['visible.js'], matches: ['https://classroom.google.com/*'] },
    coba: { id: 'moncap-vis-coba', js: ['visible.js'], matches: origineCoba(s) ? [origineCoba(s) + '/*'] : [] }
  };
  for (const c of Object.values(CIBLES_VISIBILITE)) { try { await chrome.scripting.unregisterContentScripts({ ids: [c.id] }); } catch {} }
  if (on) for (const nom of cibles) {
    const c = CIBLES_VISIBILITE[nom];
    if (!c.matches.length) continue;
    try { await chrome.scripting.registerContentScripts([{ id: c.id, js: c.js, matches: c.matches, runAt: 'document_start', world: 'MAIN', persistAcrossSessions: false }]); } catch {}
  }
}

async function collectClassroom(s) {
  const n = s.classroomLinks.length;
  if (!n) {   // aucun cours configuré : le dire clairement plutôt que renvoyer une liste vide « ok »
    await log('Classroom : aucun cours configuré (Réglages → Ajouter les cours de votre enfant)', 'alerte');
    return { statut: 'non_configure', collecte_le: new Date().toISOString(), publications: [] };
  }
  await setStatus({ enCours: true, etape: `Classroom (${n} cours en parallèle)` });
  const t0 = Date.now();
  const estClassroom = u => /classroom\.google\.com|accounts\.google\.com/.test(u);
  let win = null, publications = [];
  const { cacheDetailsV2: cacheDetails = {} } = await chrome.storage.local.get('cacheDetailsV2');
  const connus = Object.fromEntries(Object.entries(cacheDetails).map(([id, v]) => [id, { date_libelle: v.date_libelle, vu: v.vu, vide: !v.detail }]));
  await activerVisibilite(true);
  try {
    // Ouvrir les cours dans la fenêtre cachée ; chaque onglet est activé dans CETTE fenêtre pour
    // forcer son rendu (sans rien montrer à l'écran). On vérifie qu'au moins un cours a rendu ;
    // sinon on bascule tout dans la fenêtre active (furtif).
    const winId = await fenetreCachee();
    const tabs = [];
    for (const u of s.classroomLinks) {
      const t = await chrome.tabs.create({ windowId: winId, url: u, active: true });
      ongletsCollecte.add(t.id); tabs.push(t);
      await sleep(300);
    }
    try { await chrome.windows.update(winId, { state: 'minimized' }); } catch {}   // rester réduite
    // Vérifier le rendu (un cours au moins affiche du contenu) dans un délai court
    const aRendu = async () => {
      for (const t of tabs) {
        try { await injecterVisibilite(t.id);
          const [v] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => (document.body?.innerText || '').length > 200 });
          if (v?.result) return true; } catch {}
      }
      return false;
    };
    let rendu = false;
    for (let i = 0; i < 12 && !rendu; i++) { await sleep(400); rendu = await aRendu(); }
    if (!rendu) {   // fenêtre cachée noire : déplacer les onglets dans la fenêtre active
      const windowId = await fenetreActive();
      const retour = await ongletActifCourant(windowId);
      for (const t of tabs) { try { await chrome.tabs.move(t.id, { windowId, index: -1 }); } catch {} }
      try { await chrome.tabs.update(tabs[0].id, { active: true }); } catch {}
      await sleep(1500);
      if (retour != null) { try { await chrome.tabs.update(retour, { active: true }); } catch {} }
      await log('Classroom : fenêtre cachée non rendue, bascule en onglets visibles');
    }
    win = { tabs };
    publications = await Promise.all(tabs.map(async (tab, i) => {
      let r;
      try { await attendreOnglet(tab.id, estClassroom); r = await run(classroomCollect, tab.id, [false, 15000, connus, !!s.toutRouvrir, anneeScolaire().debut]); }
      catch (e) { r = { statut: 'erreur', message: String(e) }; }
      return { lien: s.classroomLinks[i], tabId: tab.id, collecte_le: new Date().toISOString(), ...r };
    }));

    // Un cours qui revient VIDE alors qu'il avait des éléments à la collecte précédente : page pas encore
    // affichée, presque sûrement (un cours ne perd pas toutes ses publications d'un coup). On le relit.
    const { derniere: precedenteCR } = await chrome.storage.local.get('derniere');
    const avantParCours = {};
    for (const p of precedenteCR?.classroom?.publications || []) if (p.cours && (p.elements || []).length) avantParCours[p.cours] = p;
    for (const p of publications) if (p.statut === 'ok' && !(p.elements || []).length && avantParCours[p.cours]) p.statut = 'vide_suspect';

    // Plan B : pour les cours restés « en chargement » ou vides suspects, recharger et relire
    const rates = publications.filter(p => p.statut === 'chargement_incomplet' || p.statut === 'page_vide' || p.statut === 'vide_suspect');
    if (rates.length) {
      await log(`Classroom : ${rates.length} cours à relire`);
      for (const p of rates) {
        try { await chrome.tabs.reload(p.tabId); await attendreOnglet(p.tabId, u => /classroom\.google\.com/.test(u), 15000);
          Object.assign(p, await run(classroomCollect, p.tabId, [false, 9000, connus, !!s.toutRouvrir, anneeScolaire().debut]), { collecte_le: new Date().toISOString() }); }
        catch (e) { p.statut = 'erreur'; p.message = String(e); }
      }
    }
    // Toujours vide (ou en erreur) après la relance : on garde les éléments de la collecte précédente,
    // signalés comme repris, plutôt que de faire disparaître les travaux et consignes de l'app.
    for (const p of publications) {
      const avant = avantParCours[p.cours] || (p.statut !== 'ok' && Object.values(avantParCours).find(x => x.lien === p.lien));
      if (avant && (p.statut !== 'ok' || !(p.elements || []).length)) {
        p.elements = avant.elements; p.cours = p.cours || avant.cours;
        p.repris_de = avant.collecte_le || precedenteCR?.collecte_le || null; p.statut_lecture = p.statut; p.statut = 'ok';
        await log(`Classroom : « ${p.cours} » illisible cette fois ; éléments de la collecte précédente conservés`, 'alerte');
      }
    }
  } finally {
    if (win?.tabs) for (const t of win.tabs) await fermerOnglet(t.id);
    await fermerFenetreCacheeSiVide();
    await activerVisibilite(false);
  }
  const ref = new Date();
  for (const [i, r] of publications.entries()) {
    delete r.tabId;
    for (const e of r.elements || []) {
      if (e.detail_en_cache && cacheDetails[e.id]) { e.detail = cacheDetails[e.id].detail; e.etapes = cacheDetails[e.id].etapes; e.pieces_jointes = cacheDetails[e.id].pieces_jointes; }
      else if (e.detail !== undefined) {
        const avant = cacheDetails[e.id];
        if (avant && avant.detail !== e.detail) e.contenu_modifie = true;     // même élément, contenu changé
        cacheDetails[e.id] = { date_libelle: e.date_libelle, detail: e.detail, etapes: e.etapes, pieces_jointes: e.pieces_jointes, vu: Date.now() };
      }
      Object.assign(e, dateClassroom(e.date_libelle, ref));
    }
    await log(`Classroom ${i + 1} : ${r.statut} — ${r.cours || ''} (${r.elements?.length || 0} éléments, ${r.details_ouverts || 0} ouverts, ${r.deplies ?? '?'} lus dont ${r.modales ?? 0} en modale, page ${r.visibilite || '?'})`, r.statut === 'ok' ? 'info' : 'alerte');
  }
  await chrome.storage.local.set({ cacheDetailsV2: cacheDetails });
  const finales = publications.map(p => (/^https:\/\/c\.gle\//.test(p.lien) && /classroom\.google\.com\/guar\//.test(p.url || '')) ? p.url.split('?')[0] : p.lien);
  if (finales.some((u, i) => u !== s.classroomLinks[i])) {
    const { reglages = {} } = await chrome.storage.local.get('reglages');
    await chrome.storage.local.set({ reglages: { ...reglages, classroomLinks: finales } });
    await log('Classroom : liens courts remplacés par les adresses des cours');
  }
  await log(`Classroom : ${publications.filter(p => p.statut === 'ok').length}/${n} cours lus en ${Math.round((Date.now() - t0) / 1000)} s`);
  if (publications.some(p => p.statut === 'connexion_requise'))
    notify('Classroom : connexion requise', 'Connectez Chrome au compte Google invité comme tuteur, puis relancez.');
  return { statut: 'ok', collecte_le: new Date().toISOString(), publications };
}

// Onglets ouverts par la collecte (servait au mode apprentissage, remplacé par l'import du résumé .eml)
const ongletsCollecte = new Set();

// ---------- Extraction IA (Gemini Nano ou Ollama) ----------
/* Corps d'un courriel : sans l'objet, la date de réception, « À : », « Cc : », « Ceci est une copie… » */
function corpsCourriel(c) {
  return (c.texte || c.apercu || '').split('\n').map(x => x.trim()).filter(x => x &&
    x !== c.objet && x !== c.date_libelle && x !== c.date_complete && !/^(À|A|Cc|Cci|De)\s*:/i.test(x) && !/^Ceci est une copie/i.test(x) &&
    !/^\d{1,2}\s+[a-zéû]+\.?\s+\d{4},\s*\d{1,2}:\d{2}$/i.test(x) && !/^(Boîte de réception|reply|reply_all|more_vert|forward|delete)$/i.test(x)).join('\n');
}
function texteCourriel(c) {
  return `Courriel du portail Coba — de : ${c.expediteur} — reçu : ${c.date_complete || c.date_libelle}\nObjet : ${c.objet}\n${corpsCourriel(c).slice(0, 2500)}`;
}

// L'IA ne sert qu'aux courriels écrits par un prof : c'est le seul texte libre où des rendez-vous
// et des échéances (récup, date d'examen déplacée, matériel) peuvent être annoncés sans figurer ailleurs.
// Classroom n'est pas analysé : ses données utiles (échéances, étapes, pièces jointes) sont lues
// directement, et le texte du prof est affiché tel quel.
// Les notifications de suivi n'en ont pas besoin non plus : le commentaire est affiché tel quel.
const estNotificationSuivi = c => /notification du portail/i.test(c.objet || '');

// Un courriel est-il UTILE À L'ÉLÈVE ? On écarte les communications aux parents, le soutien nominatif
// et les invitations à de nouvelles activités. Le reste va à l'IA, qui trie ensuite par ses garde-fous.
const RE_PARENTS = /à l'intention des parents|aux parents|chers parents|webinaire|conférence|paiement|frais d.inscription|facture|ouverture de dossier|rencontre de parents|portail parent|première communication|le bulletin sera/i;
const RE_INVITATION = /recrutement|inscris-toi|inscription à|viens essayer|cherche des joueurs|nouvelle équipe|^\s*sélection /i;
const RE_SOUTIEN = /plan d.intervention|aide personnalis|suivi personnalis|orthop[ée]dago|psycho[ée]duc|intervenant/i;
function profsClasse(data) {
  const s = new Set();
  for (const k of (data.coba && data.coba.horaire && data.coba.horaire.cases) || []) {
    const n = (k.prof || '').split(',')[0].trim().toLowerCase(); if (n) s.add(n);
  }
  return s;
}
function courrielPourEleve(c, corps, profs) {
  // objet fiable : c.objet (collectes récentes), sinon le texte avant « Ceci est une copie » (destinataire ou texte)
  let objet = c.objet;
  if (!objet) { const src = (c.destinataire || '') + ' ' + (c.texte || ''); const k = src.search(/Ceci est une copie/i);
    objet = (k > 0 ? src.slice(0, k) : src).replace(/^\d{1,2}\s+[a-zéû]+\.?\s+\d{4},.*$/im, '').replace(/^(Boîte de réception|reply|reply_all|more_vert|À\s*:.*)$/gim, '').trim().slice(0, 60); }
  const tete = objet + ' ' + (corps || '').slice(0, 350);
  if (RE_PARENTS.test(tete)) return { ok: false, raison: 'destiné aux parents' };
  if (RE_INVITATION.test(tete)) return { ok: false, raison: 'invitation à une nouvelle activité' };
  if (/[-\u2013]\s*cl[ée]ment|cl[ée]ment\s+gu[ée]guen/i.test(objet)) {
    const expNom = (c.expediteur || '').trim().split(/\s+/).pop().toLowerCase();
    if (!profs.has(expNom) || RE_SOUTIEN.test((corps || '').slice(0, 400))) return { ok: false, raison: 'suivi nominatif' };
  }
  return { ok: true };
}

// Date complète d'un courriel (« 9 oct 2026, 10:52 ») : en tête de son texte, même s'il était déjà en mémoire
const MOIS_C = { janv: 1, févr: 2, fevr: 2, mars: 3, avr: 4, mai: 5, juin: 6, juil: 7, août: 8, aout: 8, sept: 9, oct: 10, nov: 11, déc: 12, dec: 12 };
function dateISOCourriel(c) {
  const src = c.date_complete || (c.texte || '').match(/\b\d{1,2}\s+[a-zéû]+\.?\s+\d{4},\s*\d{1,2}:\d{2}\b/i)?.[0] || '';
  const m = src.match(/(\d{1,2})\s+([a-zéû]+)\.?\s+(\d{4})/i); const mo = m && MOIS_C[m[2].toLowerCase()];
  return mo ? `${m[3]}-${String(mo).padStart(2, '0')}-${m[1].padStart(2, '0')}` : null;
}
/* Garde-fous après l'IA, propres aux courriels :
   - une date citée pour un AUTRE groupe (« 102 : jeudi 22 octobre ») est rejetée ;
   - « demain », « ce soir », « aujourd'hui » sont datés à partir de la date du courriel. */
function ajusterFaits(r, cible, s, agenda = null) {
  const groupe = String(s.groupe || '').replace(/^0+/, '');
  const jour = dateISOCourriel(cible);
  const plus = (iso, n) => { const d = new Date(iso + 'T12:00'); d.setDate(d.getDate() + n); return dateLocale(d); };
  // jour de la semaine (français et anglais) -> numéro JS
  const JS = { dimanche: 0, lundi: 1, mardi: 2, mercredi: 3, jeudi: 4, vendredi: 5, samedi: 6,
    sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };
  const MOIS_EN = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
  const annee = mo => { let an = +jour.slice(0, 4); if (mo < +jour.slice(5, 7) - 6) an++; return an; };   // déc. -> janv.
  const garder = [], rejetes = [...(r.rejetes || [])];
  for (const f0 of r.elements || []) {
    const f = { ...f0 };
    const cit = (f.citation || '') + ' ' + (f.heure_ou_periode || '');
    const groupes = [...(f.citation || '').matchAll(/\b(1\d{2})\s*[:\-–]/g)].map(x => x[1]);
    if (groupe && groupes.length && !groupes.includes(groupe)) { rejetes.push({ ...f, raison: 'date d’un autre groupe' }); continue; }
    // La date écrite en clair dans la citation fait foi, même si l'IA en propose une autre.
    if (jour) {
      const ia = f.date || null;
      const fr = (f.citation || '').match(/\b(\d{1,2})(?:er)?\s+(janv|févr|fevr|mars|avr|mai|juin|juil|août|aout|sept|oct|nov|déc|dec)[a-zéû]*\b/i);
      const en = (f.citation || '').match(/\b(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{1,2})(?:st|nd|rd|th)?\b/i);
      const jsem = Object.keys(JS).find(n => new RegExp('\\b' + n + '\\b', 'i').test(f.citation || ''));
      const jcy = +((f.citation || '').match(/\bjour\s+(\d{1,2})\b/i) || [])[1] || null;   // « Thursday (jour 9) »
      let d = null, comment = '';
      if (/\bdemain\b|\btomorrow\b/i.test(cit)) { d = plus(jour, 1); comment = 'le lendemain du message'; }
      else if (/aujourd.hui|ce soir|ce matin|cet après-midi|\btoday\b|\btonight\b|this (morning|afternoon|evening)/i.test(cit)) { d = jour; comment = 'le jour du message'; }
      else if (fr) { const mo = MOIS_C[fr[2].toLowerCase()]; d = `${annee(mo)}-${String(mo).padStart(2, '0')}-${fr[1].padStart(2, '0')}`; comment = 'date écrite dans le message'; }
      else if (en) { const mo = MOIS_EN[en[1].toLowerCase()]; d = `${annee(mo)}-${String(mo).padStart(2, '0')}-${en[2].padStart(2, '0')}`; comment = 'date écrite dans le message'; }
      else if (jcy && agenda) {
        // premier jour, après le message, qui porte ce numéro de cycle (et ce jour de semaine, s'il est cité)
        const cand = Object.keys(agenda).sort().find(k => k > jour && agenda[k] === jcy && (!jsem || new Date(k + 'T12:00').getDay() === JS[jsem]));
        if (cand) { d = cand; comment = 'jour ' + jcy + ' du cycle, d’après l’agenda'; }
      }
      else if (jsem && (!ia || new Date(ia + 'T12:00').getDay() !== JS[jsem])) {
        // jour de semaine cité sans date : prochain jour cité après le message
        const x = new Date(jour + 'T12:00'); do x.setDate(x.getDate() + 1); while (x.getDay() !== JS[jsem]); d = dateLocale(x); comment = 'prochain ' + jsem + ' après le message';
      }
      if (d && d !== ia) { f.date_ia = ia; f.date = d; f.date_deduite = comment; }
      if (f.date && f.raisons) { f.raisons = f.raisons.filter(x => x !== 'date manquante'); f.a_valider = f.raisons.length > 0; }
    }
    garder.push(f);
  }
  return { ...r, elements: garder, rejetes };
}

async function phaseIA(data, s) {
  s = { ...s, groupe: s.groupe || data.coba?.horaire?.foyer || '' };   // groupe-classe : réglage, sinon foyer de l'Horaire
  const moteur = s.moteurIA;
  for (const c of data.coba?.courriels || []) if (!c.date_complete) { const m = (c.texte || '').match(/\b\d{1,2}\s+[a-zéû]+\.?\s+\d{4},\s*\d{1,2}:\d{2}\b/i); if (m) c.date_complete = m[0]; }
  for (const c of data.coba?.courriels || []) if (estNotificationSuivi(c)) c.suivi = true;
  if (!moteur || moteur === 'aucun') return;
  const refDate = dateLocale();
  const agendaCycle = {}; for (const j of data.coba?.agenda || []) if (j.jour_cycle) agendaCycle[j.date] = j.jour_cycle;
  const items = [];
  // Courriels des 30 derniers jours seulement (la date de la liste : « 9 oct 2026, 17:26 »)
  const MOISC = { janv: 1, févr: 2, fevr: 2, mars: 3, avr: 4, mai: 5, juin: 6, juil: 7, août: 8, aout: 8, sept: 9, oct: 10, nov: 11, déc: 12, dec: 12 };
  const dateCourriel = l => { const m = (l || '').match(/(\d{1,2})\s+([a-zéû]+)\.?\s+(\d{4})/i); const mo = m && MOISC[m[2].toLowerCase()];
    return mo ? `${m[3]}-${String(mo).padStart(2, '0')}-${m[1].padStart(2, '0')}` : null; };
  const limite = (() => { const d = new Date(refDate + 'T12:00'); d.setDate(d.getDate() - 30); return dateLocale(d); })();
  // Annonces Classroom (résumés des tuteurs) : récups, changements, rappels — en français ou en anglais
  for (const a of data.classroom?.annonces || []) {
    const dc = (a.publie_le || '').slice(0, 10);
    const aDate = RE_DATE_CITEE.test(a.texte || '') || /\b\d{1,2}\s*(h|am|pm|:\d{2})\b/i.test(a.texte || '') || /\bjour\s+\d{1,2}\b/i.test(a.texte || '');
    // Une annonce qui est surtout une liste datée (« October 22nd: … ») est déjà lue sans IA par le convertisseur
    const lignesDatees = (a.texte || '').split('\n').filter(l => /^\s*((january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}(st|nd|rd|th)?|\d{1,2}(er)?\s+(janv|févr|mars|avr|mai|juin|juil|août|sept|oct|nov|déc)[a-zéû]*\.?)\s*[:\-–]/i.test(l)).length;
    if (lignesDatees >= 2) { a.ia_ignore = 'liste datée, lue sans IA'; continue; }
    if (a.texte && aDate && (!dc || dc >= limite))
      items.push({ cible: a, entete: [a.cours], texte: `Annonce Classroom — cours : ${a.cours} — publiée le ${a.date_complete} par ${a.auteur}\n${(a.texte || '').slice(0, 2500)}` });
    else if (a.texte && !aDate) a.ia_ignore = 'aucune date ni heure dans le texte';
  }
  const profs = profsClasse(data);
  for (const c of data.coba?.courriels || []) {
    if (c.suivi) continue;
    const tx = corpsCourriel(c);                  // corps seul, sans en-tête
    const pe = courrielPourEleve(c, tx, profs);   // utile à l'élève ?
    if (!pe.ok) { c.ia_ignore = pe.raison; continue; }
    const dc = dateCourriel(c.date_complete || c.date_libelle);
    const aDate = RE_DATE_CITEE.test(tx) || /\b\d{1,2}\s*h\s*\d{0,2}\b/i.test(tx);
    if (tx && aDate && (!dc || dc >= limite)) items.push({ cible: c, entete: [c.objet], texte: texteCourriel(c) });
    else if (tx && !aDate) c.ia_ignore = 'aucune date ni heure dans le texte';
  }
  if (!items.length) return;

  const { cacheIA = {} } = await chrome.storage.local.get('cacheIA');
  const eveil = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);   // garde le service actif
  try {
  const moteurs = [moteur, ...(s.comparerOllama && moteur !== 'ollama' ? ['ollama'] : [])];
  let faits = 0, nouveaux = 0, erreurs = 0;
  for (const [i, it] of items.entries()) {
    if (annulerDemande) { await log('IA : analyse interrompue à la demande', 'alerte'); break; }
    await setStatus({ enCours: true, etape: `IA ${i + 1}/${items.length}`, depuis: Date.now() });
    if (i && i % 5 === 0) await chrome.storage.local.set({ cacheIA });   // sauvegarde régulière : rien n'est perdu
    for (const m of moteurs) {
      const k = m + ':' + (m === 'ollama' ? s.ollamaModel + ':' : '') + hashTexte(it.texte + (s.groupe || ''));
      let r = cacheIA[k];
      if (!r) {
        // le modèle est interrompu à 85 s ; le minuteur extérieur (95 s) ne sert que de filet
        const essai = async (texte) => {
          const limite = new Promise((_, rej) => setTimeout(() => rej(new Error('délai dépassé (95 s)')), 95000));
          return Promise.race([extraireIA(texte, s, m, refDate, it.entete, 85000), limite]);
        };
        try { r = await essai(it.texte); }
        catch (e) {
          // texte trop long pour le modèle local : seconde tentative avec le début seulement
          if (/délai dépassé/.test(String(e)) && it.texte.length > 1300 && !annulerDemande) {
            try { r = await essai(it.texte.slice(0, 1300)); r.texte_raccourci = true; } catch (e2) { r = { moteur: m, erreur: String(e2) }; }
          } else r = { moteur: m, erreur: String(e) };
        }
        if (r.erreur) { erreurs++; if (erreurs <= 2) await log(`IA (${m}) : ${r.erreur}`, 'alerte'); }
        else { r.le = Date.now(); cacheIA[k] = r; nouveaux++; }
        if (annulerDemande) break;
      }
      if (!r.erreur) r = ajusterFaits(r, it.cible, s, agendaCycle);
      it.cible[m === moteur ? 'extraction' : 'extraction_' + m] = r;
      if (m === moteur) faits += r.elements?.length || 0;
    }
  }
  // garder le cache raisonnable
  const cles = Object.keys(cacheIA);
  if (cles.length > 1500) cles.sort((a, b) => (cacheIA[a].le || 0) - (cacheIA[b].le || 0)).slice(0, cles.length - 1500).forEach(k => delete cacheIA[k]);
  await chrome.storage.local.set({ cacheIA });
  await log(`IA (${moteur}) : ${items.length} textes, ${nouveaux} analysés, ${faits} faits extraits${erreurs ? ', ' + erreurs + ' erreurs' : ''}`);
  } finally { clearInterval(eveil); }
}

// ---------- Collecte complète ----------
// Attend que l'utilisateur soit inactif avant une collecte automatique, pour ne pas faire surgir
// d'onglets pendant qu'il travaille. Repousse jusqu'à `limiteMin` minutes, puis se lance quand même.
// Une collecte automatique attend que l'ordinateur soit inutilisé ; une demande manuelle l'interrompt.
let attenteAuto = false, forcerMaintenant = false;
async function attendreMomentCreux(limiteMin = 30) {
  if (!chrome.idle) return;
  const fin = Date.now() + limiteMin * 60000;
  attenteAuto = true; forcerMaintenant = false;
  try {
    while (Date.now() < fin && !forcerMaintenant) {
      const etat = await new Promise(r => chrome.idle.queryState(60, r));   // "idle" après 60 s sans activité
      if (etat !== 'active') return;
      for (let i = 0; i < 30 && !forcerMaintenant; i++) await sleep(2000);
    }
  } finally { attenteAuto = false; }
}
let runningDepuis = 0, testDepuis = 0;

async function collect(quoi = 'tout', auto = false) {
  // Une collecte ou un test bloqué depuis trop longtemps ne doit pas tout empêcher jusqu'au redémarrage de Chrome
  if (running && Date.now() - runningDepuis > 45 * 60000) { running = false; await log('Collecte précédente bloquée : abandonnée', 'alerte'); }
  if (testEnCours && Date.now() - testDepuis > 3 * 60000) testEnCours = false;
  if (running && attenteAuto && !auto) {
    // la collecte automatique attendait un moment creux : elle démarre tout de suite, et l'appelant la suit
    forcerMaintenant = true; await setStatus({ enCours: true, etape: 'Préparation', depuis: Date.now() }); return 'reprise';
  }
  if (running || testEnCours) return false;   // déjà en cours : l'appelant suit la collecte existante
  running = true; runningDepuis = Date.now();
  if (!auto) await setStatus({ enCours: true, etape: 'Préparation', depuis: Date.now() });   // visible dès le clic
  annulerDemande = false;
  const eveilCollecte = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);   // Chrome n'arrête pas le service en pleine lecture
  try { if (auto) await attendreMomentCreux(); } catch {}
  try {
    const s = await settings();
    relaisActif = await lireRelais();
    // Plusieurs ordinateurs : une seule collecte à la fois (la réservation expire seule après 15 min)
    if (relaisActif) {
      await setStatus({ enCours: true, etape: 'Réservation de la collecte', depuis: Date.now() });
      try { const res = await appelRelais('reserver', { qui: await idMachine() }, relaisActif, 20000);
        if (res?.occupe) { await log(`Collecte déjà en cours sur un autre ordinateur (${res.par}) : rien à faire`, 'alerte'); await setStatus({ enCours: false }); return; }
      } catch (e) { await log('Relais : ' + e.message, 'alerte'); }
    }
    const { derniere, precedente } = await chrome.storage.local.get(['derniere', 'precedente']);
    let prev = derniere || {};
    // La référence est la dernière collecte déposée dans Drive (elle peut venir d'un autre ordinateur)
    if (relaisActif) {
      await setStatus({ enCours: true, etape: 'Lecture de la collecte précédente dans Drive', depuis: Date.now() });
      try { const l = await appelRelais('lire', { fichier: 'collecte' }, relaisActif, 20000);
        if (l?.ok) { versionsRelais.collecte = l.version; elevesDuDrive = elevesDe(l.contenu);
          if (l.contenu && memeEleve(elevesDe(l.contenu), elevesDe(prev))) {
            if (!prev.collecte_le || l.contenu.collecte_le > prev.collecte_le) prev = l.contenu;
            else if (prev.coba?.statut !== 'ok' && l.contenu.coba?.statut === 'ok') prev = { ...l.contenu, classroom: prev.classroom || l.contenu.classroom };
          } }
      } catch (e) { await log('Relais : lecture impossible — ' + e.message, 'alerte'); }
    }
    const data = { version: 1, collecte_le: new Date().toISOString(), eleve: { groupe: s.groupe }, coba: prev.coba || null, classroom: prev.classroom || null };

    if (quoi !== 'classroom') { await setStatus({ enCours: true, etape: 'Coba' });
      try {
        const coba = await collectCoba(s, auto);
        if (coba?.statut === 'ok') data.coba = coba;
        else {
          const secours = [prev.coba, precedente?.coba].find(c => c?.statut === 'ok' && (c.travaux || []).length);
          data.coba = secours
            ? { ...secours, statut: coba?.statut || 'erreur', echec: { statut: coba?.statut, detail: coba?.detail } }
            : coba;
        }
      } catch (e) { data.coba = { statut: 'erreur', message: String(e) }; await log('Coba : ' + e, 'alerte'); } }
    // Agenda plus court que d'habitude (navigation bloquée, page lente) : les jours à venir déjà connus sont
    // repris de la collecte précédente plutôt que de disparaître de l'app
    if (Array.isArray(data.coba?.agenda) && Array.isArray(prev.coba?.agenda) && data.coba.agenda.length < prev.coba.agenda.length) {
      const ag = data.coba.agenda, lus = new Set(ag.map(j => j.date)), dernier = ag.map(j => j.date).sort().pop() || '';
      const repris = prev.coba.agenda.filter(j => j.date > dernier && !lus.has(j.date) && j.date >= dateLocale());
      if (repris.length) {
        data.coba.agenda = ag.concat(repris.map(j => ({ ...j, repris: true }))).sort((a, b) => a.date.localeCompare(b.date));
        await log(`Coba : agenda incomplet ; ${repris.length} jour(s) à venir repris de la collecte précédente`, 'alerte');
      }
    }
    if (quoi !== 'coba') {
      try { data.classroom = await collectClassroom(s); } catch (e) { data.classroom = { statut: 'erreur', message: String(e) }; await log('Classroom : ' + e, 'alerte'); } }
    // Annonces Classroom : absentes de la vue tuteur, lues dans les résumés reçus par courriel (via le relais)
    if (relaisActif && data.classroom) {
      try {
        const r = await appelRelais('resumes', { jours: 30 }, relaisActif);
        if (r?.ok) {
          const cours = (data.classroom.publications || []).map(p => p.cours).filter(Boolean);
          const nouvelles = r.resumes.map(x => extraireAnnonces(x.texte, cours));
          // les annonces relues dans les résumés d'abord : elles l'emportent sur les versions déjà gardées
          data.classroom.annonces = fusionnerAnnonces([...nouvelles, prev.classroom?.annonces || []]);
          await log(`Classroom : ${data.classroom.annonces.length} annonce(s) tirée(s) de ${r.resumes.length} résumé(s)`);
        } else await log('Relais : résumés Classroom — ' + (r?.erreur || 'réponse vide'), 'alerte');
      } catch (e) { await log('Relais : résumés Classroom — ' + e.message, 'alerte'); }
    }

    if (data.coba?.statut === 'ok' && prev.coba?.statut === 'ok') {
      data.changements = comparer(prev.coba.travaux, data.coba.travaux);
      if (data.changements.length) await log(`${data.changements.length} changement(s) dans Coba depuis la dernière collecte`);
    } else data.changements = [];

    // Les données fiables (Coba, Classroom) sont disponibles tout de suite, sans attendre l'IA
    await chrome.storage.local.set({ derniere: data, precedente: prev });
    await log('Collecte enregistrée' + ((data.coba?.courriels || []).some(c => !estNotificationSuivi(c)) && s.moteurIA !== 'aucun' ? ' ; analyse IA des courriels en cours' : ''));

    // Dépôt immédiat dans Drive : les téléphones reçoivent les données fiables sans attendre l'IA
    if (relaisActif) await deposerDansDrive(data, s, { avantIA: true });

    // L'IA complète ensuite les faits extraits du texte libre, puis on réenregistre et on redépose
    await phaseIA(data, s);
    await chrome.storage.local.set({ derniere: data });
    if (relaisActif) await deposerDansDrive(data, s, { apresIA: true });
    if (s.autoSave && !auto && !relaisActif) await exporter(data);   // fichier téléchargé seulement sans Google Drive relié
    await setStatus({ enCours: false, fini: new Date().toISOString() });
  } catch (e) {
    await log('Erreur : ' + e, 'alerte');
    await setStatus({ enCours: false, erreur: String(e) });
  } finally {
    running = false; clearInterval(eveilCollecte);
    if (relaisActif) { try { await appelRelais('liberer', { qui: await idMachine() }, relaisActif); } catch {} }
  }
}

let relaisActif = null; const versionsRelais = {}; let elevesDuDrive = null;
/* Identité de l'élève : l'identifiant Classroom présent dans chaque lien tuteur (…/guar/<cours>/<élève>).
   Elle empêche de déposer les données d'un élève dans le Google Drive d'un autre foyer. */
function elevesDe(col) {
  const s = new Set();
  for (const p of col?.classroom?.publications || []) { const m = String(p.lien || p.url || '').match(/\/guar\/[\w-]+\/([\w-]+)/); if (m) s.add(m[1]); }
  return s;
}
const memeEleve = (a, b) => !a?.size || !b?.size || [...a].some(x => b.has(x));
/* Dépôt dans Drive : la collecte brute (référence commune), les données préparées pour l'app,
   et le journal des changements. Un conflit de version veut dire qu'un autre ordinateur a déposé entre-temps :
   on ne l'écrase pas. */
async function deposerDansDrive(data, s, quand = {}) {
  // Ce Google Drive contient les données d'un AUTRE élève : on ne dépose rien (mauvais code de liaison ?)
  if (elevesDuDrive && !memeEleve(elevesDe(data), elevesDuDrive)) {
    await log('Drive : ce Google Drive contient les données d’un autre élève ; rien n’est déposé. Vérifiez le code de liaison (Réglages → Google Drive).', 'alerte');
    await chrome.storage.local.set({ alerteFoyer: { le: new Date().toISOString(), relais: (relaisActif?.url || '').slice(-12) } });
    return;
  }
  // Une collecte ratée côté Coba (session expirée, page lente…) ne doit jamais remplacer de bonnes données
  if (data.coba?.statut !== 'ok' || !(data.coba?.travaux || []).length || !(data.coba?.agenda || []).length) {
    await log('Drive : collecte Coba incomplète (' + (data.coba?.statut || 'absente') + ') ; rien n’est déposé, les données précédentes restent en place', 'alerte');
    return;
  }
  try {
    const rc = await appelRelais('ecrire', { fichier: 'collecte', contenu: data, version_base: versionsRelais.collecte ?? null }, relaisActif);
    if (rc?.conflit) { await log('Drive : une collecte plus récente a été déposée par un autre ordinateur ; la mienne n’est pas envoyée', 'alerte'); return; }
    if (!rc?.ok) throw new Error(rc?.erreur || 'écriture refusée');
    versionsRelais.collecte = rc.version;
    const donnees = convertirCollecte(data);
    const rd = await appelRelais('ecrire', { fichier: 'donnees', contenu: donnees }, relaisActif);
    if (!rd?.ok) throw new Error(rd?.erreur || 'écriture refusée');
    // journal des changements : les nouveaux s'ajoutent aux anciens, 60 jours gardés
    if ((data.changements || []).length && !quand.apresIA) {   // une seule fois par collecte
      const lj = await appelRelais('lire', { fichier: 'changements' }, relaisActif);
      const limite = new Date(Date.now() - 60 * 864e5).toISOString();
      const journal = [...(Array.isArray(lj?.contenu) ? lj.contenu : []), ...data.changements.map(c => ({ ...c, le: data.collecte_le }))].filter(c => (c.le || '') >= limite);
      await appelRelais('ecrire', { fichier: 'changements', contenu: journal, version_base: lj?.version }, relaisActif);
    }
    await log(quand.avantIA ? `Drive : données déposées (version ${rc.version}) ; les compléments de l’IA suivront`
      : quand.apresIA ? `Drive : compléments de l’IA déposés (version ${rc.version})` : `Drive : collecte et données déposées (version ${rc.version})`);
  } catch (e) { await log('Drive : dépôt impossible — ' + e.message, 'alerte'); }
}

async function exporterSilencieux(data) { return exporter(data); }
async function exporter(data) {
  if (!data) ({ derniere: data } = await chrome.storage.local.get('derniere'));
  if (!data) return;
  const jour = data.collecte_le.slice(0, 10);
  const url = 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
  await chrome.downloads.download({ url, filename: `mon-cap/collecte-${jour}.json`, conflictAction: 'overwrite', saveAs: false });
  await log(`Fichier enregistré : Téléchargements/mon-cap/collecte-${jour}.json`);
}

// ---------- Planification ----------
async function planifier() {
  const s = await settings();
  await chrome.alarms.clear('collecte');
  if (s.autoHours > 0) chrome.alarms.create('collecte', { periodInMinutes: s.autoHours * 60, delayInMinutes: 1 });
}
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'collecte') collect('tout', true); if (a.name === 'maj') verifierMaj(); });

/* ---------- Mises à jour : une fois par jour, comparer avec la dernière version publiée sur le site ---------- */
const plusRecente = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function verifierMaj() {
  try {
    const r = await fetch(MON_CAP.majUrl, { cache: 'no-store' }); if (!r.ok) return { ok: false, erreur: 'site injoignable (' + r.status + ')' };
    const j = await r.json(), actuelle = chrome.runtime.getManifest().version;
    if (j?.version && plusRecente(j.version, actuelle)) {
      await chrome.storage.local.set({ majDispo: { version: j.version, telechargement: j.telechargement, nouveautes: j.nouveautes || [], vu: Date.now() } });
      chrome.action.setBadgeText({ text: 'MAJ' }); chrome.action.setBadgeBackgroundColor({ color: '#FFD43B' });
      chrome.action.setBadgeTextColor?.({ color: '#0D1130' });
      return { ok: true, nouvelle: j.version, actuelle };
    } else { await chrome.storage.local.remove('majDispo'); chrome.action.setBadgeText({ text: '' }); return { ok: true, nouvelle: null, actuelle }; }
  } catch (e) { return { ok: false, erreur: 'hors connexion ou site injoignable' }; }   // l'alarme réessaiera demain
}
function planifierMaj() { chrome.alarms.create('maj', { delayInMinutes: 1, periodInMinutes: 24 * 60 }); }
chrome.runtime.onStartup.addListener(() => { planifierMaj(); verifierMaj(); });
chrome.runtime.onInstalled.addListener(d => { planifier(); planifierMaj(); verifierMaj();
  if (d?.reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('assistant.html') });
});
chrome.runtime.onStartup.addListener(planifier);
chrome.storage.onChanged.addListener(ch => { if (ch.reglages) planifier(); });

chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m.action === 'collecter') { const deja = running || testEnCours; collect(m.quoi).catch(() => {}); reply({ ok: true, dejaEnCours: deja }); }
  if (m.action === 'exporter') { exporter().then(() => reply({ ok: true })); return true; }
  if (m.action === 'relaisDiagResumes') {
    (async () => {
      try {
        const r = await appelRelais('resumes', { jours: 45 });
        if (!r?.ok) return reply({ ok: false, erreur: r?.erreur || 'réponse vide' });
        const { derniere } = await chrome.storage.local.get('derniere');
        const cours = (derniere?.classroom?.publications || []).map(p => p.cours).filter(Boolean);
        reply({ ok: true, out: { nb_resumes: r.resumes.length, cours_connus: cours,
          resumes: r.resumes.map(x => ({ date: x.date, sujet: x.sujet, longueur: (x.texte || '').length,
            annonces_trouvees: extraireAnnonces(x.texte, cours).length, texte: (x.texte || '').slice(0, 12000) })) } });
      } catch (e) { reply({ ok: false, erreur: e.message }); }
    })();
    return true;
  }
  if (m.action === 'relaisAdresse') { lireRelais().then(r => reply({ url: r?.url || null })); return true; }   // adresse seule, jamais la clé
  // ----- Assistant d'installation -----
  if (m.action === 'assistantEtat') {
    (async () => {
      const s = await settings(); const rel = await lireRelais(); const id = await lireIdentifiants().catch(() => null);
      const { derniere, assistant = {} } = await chrome.storage.local.get(['derniere', 'assistant']);
      const alarme = await chrome.alarms.get('collecte').catch(() => null);
      reply({ cobaUrl: s.cobaUrl, identifiants: !!id, relais: !!rel, cleTel: !!rel?.cleTel, cours: s.classroomLinks.length,
        relaisCourt: rel ? '…' + ((rel.url.match(/\/s\/([\w-]+)\/exec/) || [])[1] || '').slice(-6) : '',
        coursListe: s.classroomLinks.map(u => ({ url: u, nom: s.coursNoms?.[u]?.nom || (derniere?.classroom?.publications || []).find(p => p.lien === u || p.url === u)?.cours || '' })),
        autoHours: s.autoHours, ouvrirCourriels: s.ouvrirCourriels, prochaine: alarme?.scheduledTime || null,
        moteurIA: s.moteurIA, groupe: s.groupe, assistant,
        derniere: derniere ? { le: derniere.collecte_le, travaux: (derniere.coba?.travaux || []).length, coba: derniere.coba?.statut,
          cours: (derniere.classroom?.publications || []).filter(p => p.statut === 'ok').length, courriels: (derniere.coba?.courriels || []).length,
          annonces: (derniere.classroom?.annonces || []).length } : null });
    })();
    return true;
  }
  if (m.action === 'assistantReglages') {
    (async () => {
      const { reglages = {} } = await chrome.storage.local.get('reglages');
      const n = { ...reglages, ...m.reglages, reglagesV2: true };
      if (n.cobaUrl) n.cobaUrl = adresseConnexionCoba(n.cobaUrl);
      await chrome.storage.local.set({ reglages: n }); await planifier(); reply({ ok: true });
    })();
    return true;
  }
  if (m.action === 'assistantProgres') { chrome.storage.local.set({ assistant: m.assistant }).then(() => reply({ ok: true })); return true; }
  if (m.action === 'relaisCode') {
    (async () => {
      const r = lireCodeLiaison(m.code);
      if (!r) return reply({ ok: false, erreur: 'Ce code n’est pas reconnu. Copiez-le en entier depuis la feuille (menu Mon Cap → 2. Obtenir mon code de liaison) : il commence par MONCAP1.' });
      try {
        const p = await appelRelais('ping', {}, r);
        if (!p?.ok) return reply({ ok: false, erreur: p?.erreur === 'clé refusée' ? 'Le relais a refusé la clé : générez un nouveau code dans la feuille.' : 'Le relais ne répond pas comme prévu. Vérifiez que le déploiement est en « Application Web », accès « Tout le monde ».' });
        await enregistrerRelais(r.url, r.cle, r.cleTel); reply({ ok: true });
      } catch (e) { reply({ ok: false, erreur: 'Le relais est injoignable : ' + e.message + '. Vérifiez l’URL de l’application Web utilisée pour le code.' }); }
    })();
    return true;
  }
  if (m.action === 'coursDepuisResumes') {
    (async () => {
      try {
        const r = await appelRelais('resumes', { jours: 60 });
        if (!r?.ok) return reply({ ok: false, erreur: r?.erreur || 'réponse vide du relais' });
        reply({ ok: true, nbResumes: r.resumes.length, enfants: coursDesResumes(r.resumes) });
      } catch (e) { reply({ ok: false, erreur: e.message }); }
    })();
    return true;
  }
  if (m.action === 'relaisCleTel') {   // relais installé à la main : la clé des téléphones est saisie une fois
    (async () => { const r = await lireRelais(); if (!r) return reply({ ok: false });
      await enregistrerRelais(r.url, r.cle, String(m.cle || '').trim()); reply({ ok: true }); })();
    return true;
  }
  if (m.action === 'lienTelephone') {
    (async () => { const rel = await lireRelais(); reply({ lien: lienTelephone(m.appUrl || MON_CAP.appUrl, rel) }); })();
    return true;
  }
  if (m.action === 'verifierMaj') { verifierMaj().then(reply); return true; }
  if (m.action === 'relaisEtat') { lireRelais().then(r => reply({ configure: !!r })); return true; }
  if (m.action === 'relaisEffacer') { effacerRelais().then(() => reply({ ok: true })); return true; }
  if (m.action === 'relaisEnregistrer') {
    (async () => {
      try {
        const r = await appelRelais('ping', {}, { url: m.url, cle: m.cle });
        if (!r?.ok) return reply({ ok: false, erreur: r?.erreur === 'clé refusée' ? 'clé refusée par le relais' : (r?.erreur || 'réponse inattendue') });
        if (r.role !== 'extension') return reply({ ok: false, erreur: 'c’est la clé des TÉLÉPHONES : il faut celle de l’extension' });
        // la clé des téléphones n'est gardée que pour le MÊME relais : un autre relais a la sienne
        const avant = await lireRelais();
        await enregistrerRelais(m.url, m.cle, avant?.url === m.url ? (avant.cleTel || null) : null);
        reply({ ok: true, role: r.role });
      } catch (e) { reply({ ok: false, erreur: e.message }); }
    })();
    return true;
  }
  if (m.action === 'identifiants') { enregistrerIdentifiants(m.u, m.p).then(() => reply({ ok: true }), e => reply({ ok: false, erreur: String(e) })); return true; }
  if (m.action === 'diagCoba') {
    (async () => {
      const s = await settings();
      await activerVisibilite(true, ['coba']);
      let tabId;
      try {
        const res = await ouvrirEtRendre(s.cobaUrl, async tid => { await injecterVisibilite(tid);
          try { const [v] = await chrome.scripting.executeScript({ target: { tabId: tid }, func: sondeCobaDansPage }); return !!(v?.result?.travaux || v?.result?.login); } catch { return false; } });
        tabId = res.tab.id;
        // se connecter si la page de connexion s'affiche
        const [p] = await chrome.scripting.executeScript({ target: { tabId }, func: sondeCobaDansPage });
        if (p?.result?.login) { const id = await lireIdentifiants(); if (!id) throw new Error('aucun identifiant enregistré'); await soumettreConnexion(tabId, id); await attendreConnexionCoba(tabId, 25000); }
        const out = { version: chrome.runtime.getManifest().version };
        await chrome.scripting.executeScript({ target: { tabId }, files: ['collectors.js'] });
        const [menu] = await chrome.scripting.executeScript({ target: { tabId }, func: () => ({
          travaux: typeof lienMenuCoba === 'function' && !!lienMenuCoba('Travaux'),
          liens: typeof liensMenuCoba === 'function' ? liensMenuCoba() : []
        }) });
        out.Menu = menu?.result;
        // Pages du menu : Travaux d'abord (c'est lui qui bloque la collecte), puis Courriels.
        for (const nom of ['Travaux', 'Courriels']) {
          try {
            const urlAvant = (await chrome.tabs.get(tabId)).url;
            const clic = await run(cobaCliquerMenu, tabId, [nom]);
            if (clic?.statut !== 'clic') { out[nom] = clic; continue; }
            await sleep(1500);
            const t = await attendreOnglet(tabId, () => true, 20000);   // attend la fin d'une éventuelle redirection
            await injecterVisibilite(tabId);
            out[nom] = await run(cobaAnalyserPage, tabId, [nom]);
            out[nom].redirige = t && t.url !== urlAvant && !/index\.coba/.test(new URL(t.url).pathname.split('/').pop()) ? 'oui' : (t ? new URL(t.url).pathname : '?');
          } catch (e) { out[nom] = { erreur: String(e) }; }
        }
        reply({ ok: true, out });
      } catch (e) { reply({ ok: false, erreur: String(e) }); }
      finally { if (tabId != null) { await fermerOnglet(tabId); await fermerFenetreCacheeSiVide(); } await activerVisibilite(false); }
    })();
    return true;
  }
  if (m.action === 'arreter') { annulerDemande = true; reply({ ok: true }); return; }
  if (m.action === 'testerCoba') { testerConnexionCoba(m.u, m.p).then(reply, e => reply({ ok: false, raison: String(e) })); return true; }
  if (m.action === 'effacerIdentifiants') { effacerIdentifiants().then(() => reply({ ok: true })); return true; }
});
