const $ = id => document.getElementById(id);
(async () => {
  const { reglages } = await chrome.storage.local.get('reglages');
  const s = { ...DEFAULTS, ...(reglages || {}) };
  $('cobaUrl').value = s.cobaUrl; $('groupe').value = s.groupe;
  $('links').value = s.classroomLinks.join('\n'); $('autoHours').value = s.autoHours;
  $('autoSave').checked = s.autoSave; $('toutRouvrir').checked = s.toutRouvrir; $('ollamaModel').value = s.ollamaModel; $('moteurIA').value = s.moteurIA; $('comparerOllama').checked = s.comparerOllama; $('courriels').checked = s.courriels; $('ouvrirCourriels').checked = s.ouvrirCourriels;
})();
// Demande à Chrome l'accès au portail Coba indiqué. Doit être appelée directement dans un clic.
function demanderAccesCoba() {
  let org; try { org = new URL($('cobaUrl').value.trim()).origin; } catch { return Promise.resolve(false); }
  return chrome.permissions.request({ origins: [org + '/*'] }).catch(() => false);
}
$('save').onclick = async () => {
  $('cobaUrl').value = adresseConnexionCoba($('cobaUrl').value);
  const acces = demanderAccesCoba();
  const reglages = {
    cobaUrl: $('cobaUrl').value.trim(), groupe: $('groupe').value.trim(),
    classroomLinks: $('links').value.split(/\s+/).map(x => x.trim()).filter(x => /^https:\/\//.test(x)),
    reglagesV2: true,
    autoHours: Math.max(0, parseInt($('autoHours').value, 10) || 0),
    autoSave: $('autoSave').checked, toutRouvrir: $('toutRouvrir').checked, moteurIA: $('moteurIA').value, comparerOllama: $('comparerOllama').checked, courriels: $('courriels').checked, ouvrirCourriels: $('ouvrirCourriels').checked, ollamaModel: $('ollamaModel').value.trim() || 'qwen3:8b'
  };
  const { reglages: avant = {} } = await chrome.storage.local.get('reglages');
  await chrome.storage.local.set({ reglages: { ...avant, ...reglages } });   // garde coursNoms et autres champs
  $('ok').textContent = (await acces) || !$('cobaUrl').value.trim() ? 'Réglages enregistrés' : 'Réglages enregistrés — accès au portail Coba refusé : la collecte Coba ne fonctionnera pas.';
  setTimeout(() => $('ok').textContent = '', 2500);
};

async function statutId() {
  const { identifiantsCoba: c, echecConnexion: e } = await chrome.storage.local.get(['identifiantsCoba', 'echecConnexion']);
  $('idStatut').innerHTML = (c ? `Identifiants enregistrés le ${new Date(c.le).toLocaleString('fr-CA')}.` : 'Aucun identifiant enregistré : la collecte automatique ne pourra pas se reconnecter.')
    + (e ? ` <span class="warn">Dernier échec de connexion : ${new Date(e.t).toLocaleString('fr-CA')} — ${e.raison}</span>` : '');
}
statutId();
$('saveId').onclick = async () => {
  const u = $('cobaUser').value.trim(), p = $('cobaPass').value;
  if (!u || !p) { $('idOk').textContent = 'Les deux champs sont requis'; return; }
  const r = await chrome.runtime.sendMessage({ action: 'identifiants', u, p });
  $('cobaPass').value = ''; $('cobaUser').value = '';
  $('idOk').className = r?.ok ? 'ok' : 'warn';
  $('idOk').textContent = r?.ok ? 'Identifiants chiffrés et enregistrés.' : 'Erreur : ' + (r?.erreur || '?');
  statutId();
};
$('cobaUrl').addEventListener('change', () => { const c = adresseConnexionCoba($('cobaUrl').value); if (c && c !== $('cobaUrl').value.trim()) $('cobaUrl').value = c; });
$('testId').onclick = async () => {
  $('cobaUrl').value = adresseConnexionCoba($('cobaUrl').value);
  const acces = demanderAccesCoba();
  const u = $('cobaUser').value.trim(), p = $('cobaPass').value;
  if (!$('cobaUrl').value.trim()) { $('idOk').className = 'warn'; $('idOk').textContent = 'Indiquez d’abord l’adresse du portail Coba de l’école.'; return; }
  if (!(await acces)) { $('idOk').className = 'warn'; $('idOk').textContent = 'Accès au portail refusé : Chrome doit autoriser l’extension à ouvrir cette adresse.'; return; }
  // enregistrer l'adresse avant le test, pour que le service l'utilise
  { const { reglages = {} } = await chrome.storage.local.get('reglages'); await chrome.storage.local.set({ reglages: { ...reglages, cobaUrl: $('cobaUrl').value.trim() } }); }
  $('testId').disabled = true; $('idOk').className = 'hint'; $('idOk').textContent = 'Test en cours… (une dizaine de secondes)';
  const r = await chrome.runtime.sendMessage({ action: 'testerCoba', u: u && p ? u : undefined, p: u && p ? p : undefined });
  $('testId').disabled = false;
  if (r?.ok) {
    $('idOk').className = 'ok';
    const modeTxt = r.jalons?.mode === 'cache' ? ' (collecte invisible)' : r.jalons?.mode === 'furtif' ? ' (onglet bref)' : '';
    $('idOk').textContent = `Connexion réussie en ${r.duree} s${r.responsable ? ' — portail ouvert pour ' + r.responsable : ''}.`
      + (r.enregistre ? ' Identifiants enregistrés.' : '') + modeTxt + (r.version ? ` (v${r.version})` : '');
    if (r.enregistre) { $('cobaPass').value = ''; $('cobaUser').value = ''; }
    if (r.jalons) { const d = document.createElement('span'); d.className = 'hint'; d.style.display = 'block';
      d.textContent = 'Détail : ' + Object.entries(r.jalons).map(([k, v]) => `${k.replace(/_/g, ' ')} ${v}s`).join(', '); $('idOk').appendChild(d); }
  } else {
    $('idOk').className = 'warn';
    $('idOk').textContent = 'Échec : ' + (r?.raison || 'erreur inconnue') + (r?.version ? ` (v${r.version})` : ' (version inconnue)');
    const info = document.createElement('span'); info.className = 'hint'; info.style.display = 'block';
    let txt = '';
    if (r?.jalons) txt += 'Chemin : ' + Object.entries(r.jalons).map(([k, v]) => `${k.replace(/_/g, ' ')}=${v}`).join(', ') + '\n';
    if (r?.vu) txt += 'Vu : ouvert=' + r.vu.ouvert + ', liens=' + (r.vu.nbLiens ?? '?') + ', titre=' + (r.vu.titre || '?') + (r.vu.err ? ', err=' + r.vu.err : '') + '\n';
    info.style.whiteSpace = 'pre-wrap'; info.textContent = txt; $('idOk').appendChild(info);
    if (r?.diag?.length) {
      const pre = document.createElement('pre');
      pre.style.cssText = 'white-space:pre-wrap;font-size:11.5px;background:var(--card);border:1px solid var(--line);border-radius:8px;padding:8px;margin-top:6px;color:var(--ink)';
      pre.textContent = 'Diagnostic (sans aucun mot de passe) :\n' + r.diag.map(d => d.erreur ? 'Erreur : ' + d.erreur :
        `${d.cadre ? 'Cadre' : 'Page'} : ${d.url}\nTitre : ${d.titre}\nCadres : ${d.iframes.join(', ') || 'aucun'}\nChamps : ${d.champs.join(', ') || 'aucun'}\nBoutons/liens : ${d.boutons.join(' | ') || 'aucun'}\nTexte : ${d.extrait.replace(/\s+/g, ' ')}`).join('\n\n');
      $('idOk').appendChild(pre);
    }
  }
  statutId();
};

$('delId').onclick = async () => { await chrome.runtime.sendMessage({ action: 'effacerIdentifiants' }); statutId(); };
$('exp').onclick = async () => {
  const { reglages } = await chrome.storage.local.get('reglages');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify({ ...DEFAULTS, ...(reglages || {}) }, null, 2)], { type: 'application/json' }));
  a.download = 'mon-cap-reglages.json'; a.click();
};
$('imp').onclick = () => $('fic').click();
$('fic').onchange = async () => {
  try {
    const r = JSON.parse(await $('fic').files[0].text());
    const propres = Object.fromEntries(Object.entries(r).filter(([k]) => k in DEFAULTS));
    await chrome.storage.local.set({ reglages: propres }); location.reload();
  } catch { alert('Fichier de réglages invalide'); }
};

// ----- Import des cours depuis un résumé Classroom (.eml) -----
async function importerEml(file) {
  $('decListe').innerHTML = '';
  if (!file) return;
  let r;
  try { r = lireResumeClassroom(await emlDepuisFichier(file)); }
  catch (e) { $('decStatut').textContent = 'Fichier illisible : ' + e.message; return; }
  if (!r.cours.length) { $('decStatut').textContent = 'Aucun cours trouvé dans ce fichier. Vérifiez qu’il s’agit bien d’un résumé envoyé par Google Classroom.'; return; }
  const suivis = new Set($('links').value.split(/\s+/).map(u => u.split('?')[0]));
  const enfants = [...new Set(r.cours.map(c => c.enfant || ''))];
  $('decStatut').textContent = `${r.cours.length} cours trouvés${r.enfant ? ' pour ' + r.enfant : ''}.`;
  const esc = x => (x || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  $('decListe').innerHTML = r.cours.map(c => `<label class="check"><input type="checkbox" data-url="${c.url}" data-nom="${esc(c.nom)}" data-enfant="${esc(c.enfant)}" ${suivis.has(c.url) ? 'checked disabled' : 'checked'}> ${esc(c.nom) || 'Cours sans nom'}${suivis.has(c.url) ? ' <span class="hint">déjà suivi</span>' : ''}</label>`).join('')
    + (r.cours.some(c => !suivis.has(c.url)) ? '<p><button id="ajouter" class="primary">Ajouter la sélection</button></p>' : '');
  // Suggérer le groupe-classe s'il n'est pas rempli : numéro à 3 chiffres le plus fréquent dans les noms de cours
  if (!$('groupe').value.trim()) {
    const n = {}; r.cours.forEach(c => (c.nom.match(/\b\d{3}\b/g) || []).forEach(x => n[x] = (n[x] || 0) + 1));
    const g = Object.entries(n).sort((a, b) => b[1] - a[1])[0];
    if (g && g[1] >= 3) { $('groupe').value = g[0]; $('decStatut').textContent += ` Groupe-classe probable : ${g[0]} (à vérifier).`; }
  }
  const b = document.getElementById('ajouter');
  if (b) b.onclick = async () => {
    const choix = [...document.querySelectorAll('#decListe input:checked:not(:disabled)')];
    $('links').value = [...$('links').value.split(/\s+/).filter(Boolean), ...choix.map(x => x.dataset.url)].join('\n');
    const { reglages = {} } = await chrome.storage.local.get('reglages');
    const coursNoms = { ...(reglages.coursNoms || {}) };
    choix.forEach(x => coursNoms[x.dataset.url] = { nom: x.dataset.nom, enfant: x.dataset.enfant });
    await chrome.storage.local.set({ reglages: { ...reglages, coursNoms } });
    $('save').click();
    importerEml(file);
  };
}
$('depot').onclick = () => $('emlFic').click();
$('emlFic').onchange = () => importerEml($('emlFic').files[0]);
$('depot').ondragover = e => { e.preventDefault(); $('depot').style.borderColor = 'var(--accent)'; };
$('depot').ondragleave = () => { $('depot').style.borderColor = 'var(--line)'; };
$('depot').ondrop = e => { e.preventDefault(); $('depot').style.borderColor = 'var(--line)'; importerEml(e.dataTransfer.files[0]); };

// ----- Gemini Nano : état et téléchargement -----
const NANO_OPTS = { expectedInputs: [{ type: 'text', languages: ['fr'] }], expectedOutputs: [{ type: 'text', languages: ['fr'] }] };
const ETATS = {
  available: 'Prêt : le modèle est installé.',
  downloadable: 'Le modèle doit être téléchargé une fois (plusieurs Go). Cliquez sur « Préparer le modèle ».',
  downloading: 'Téléchargement en cours…',
  unavailable: 'Indisponible sur cet ordinateur (matériel insuffisant ou version de Chrome trop ancienne). Choisissez Ollama ou Aucun.',
  absent: 'Cette version de Chrome n’offre pas l’IA intégrée. Mettez Chrome à jour, ou choisissez Ollama.'
};
async function nanoEtat() {
  let e = 'absent';
  if (typeof LanguageModel !== 'undefined') { try { e = await LanguageModel.availability(NANO_OPTS); } catch (x) { e = 'unavailable'; } }
  $('nanoEtat').textContent = ETATS[e] || e;
  $('nanoPrep').style.display = (e === 'downloadable' || e === 'downloading') ? '' : 'none';
  $('nanoBloc').style.display = $('moteurIA').value === 'nano' ? '' : 'none';
  return e;
}
$('moteurIA').onchange = nanoEtat;
nanoEtat();
$('nanoPrep').onclick = async () => {
  $('nanoPrep').disabled = true;
  try {
    const s = await LanguageModel.create({ ...NANO_OPTS, monitor(m) {
      m.addEventListener('downloadprogress', ev => { $('nanoProg').textContent = Math.round(ev.loaded * 100) + ' %'; });
    } });
    s.destroy?.(); $('nanoProg').textContent = '';
  } catch (x) { $('nanoProg').textContent = 'Erreur : ' + x.message; }
  $('nanoPrep').disabled = false; nanoEtat();
};

const _diag=document.getElementById('diagCoba');
if(_diag) _diag.onclick=async()=>{ document.getElementById('diagEtat').textContent='Analyse en cours…';
  const r=await chrome.runtime.sendMessage({action:'diagCoba'});
  if(!r?.ok){document.getElementById('diagEtat').textContent='Erreur : '+(r?.erreur||'?');return;}
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([JSON.stringify(r.out,null,2)],{type:'application/json'})); a.download='coba-diag.json'; a.click();
  document.getElementById('diagEtat').textContent='Fichier coba-diag.json téléchargé.'; };

// ----- Stockage partagé (relais Google) -----
(async () => {
  const etat = document.getElementById('relaisEtat'); if (!etat) return;
  const r = await chrome.runtime.sendMessage({ action: 'relaisEtat' });
  etat.textContent = r?.configure ? 'Configuré.' : 'Non configuré.';
  document.getElementById('relaisTester').onclick = async () => {
    const url = document.getElementById('relaisUrl').value.trim(), cle = document.getElementById('relaisCle').value.trim();
    if (!/^https:\/\/script\.google\.com\/macros\/s\/.+\/exec$/.test(url)) { etat.textContent = 'Adresse invalide : elle doit commencer par https://script.google.com/macros/s/ et finir par /exec.'; return; }
    if (cle.length < 32) { etat.textContent = 'Clé trop courte : copiez celle affichée par initialiser().'; return; }
    // autorisation d'accès au relais (demandée une seule fois, au clic)
    const ok = await chrome.permissions.request({ origins: ['https://script.google.com/*', 'https://script.googleusercontent.com/*'] }).catch(() => false);
    if (!ok) { etat.textContent = 'Autorisation refusée : l’extension ne peut pas joindre le relais.'; return; }
    etat.textContent = 'Test en cours…';
    const t = await chrome.runtime.sendMessage({ action: 'relaisEnregistrer', url, cle });
    etat.textContent = t?.ok ? '✓ Relais joint (rôle : ' + t.role + '). Il sera utilisé à la prochaine collecte.' : '✗ ' + (t?.erreur || 'échec');
    if (t?.ok) { document.getElementById('relaisCle').value = ''; }
  };
  document.getElementById('relaisEffacer').onclick = async () => { await chrome.runtime.sendMessage({ action: 'relaisEffacer' }); etat.textContent = 'Relais effacé.'; };
})();

// Diagnostic : ce que le relais renvoie des résumés Classroom, et combien d'annonces en sont tirées
(() => {
  const b = document.getElementById('relaisResumes'), e = document.getElementById('relaisResumesEtat'); if (!b) return;
  b.onclick = async () => {
    e.textContent = 'Interrogation du relais…';
    const r = await chrome.runtime.sendMessage({ action: 'relaisDiagResumes' });
    if (!r?.ok) { e.textContent = '✗ ' + (r?.erreur || 'échec'); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(r.out, null, 2)], { type: 'application/json' }));
    a.download = 'resumes-diag.json'; a.click();
    e.textContent = r.out.nb_resumes + ' résumé(s) reçu(s), ' + r.out.resumes.reduce((s, x) => s + x.annonces_trouvees, 0) + ' annonce(s) trouvée(s). Fichier resumes-diag.json téléchargé.';
  };
})();

// Lien d'installation des téléphones : <adresse de l'app>#relais=<adresse du relais>&cle=<clé TÉLÉPHONE>
(() => {
  const b = document.getElementById('creerLien'); if (!b) return;
  chrome.storage.local.get('appUrl').then(o => { if (o.appUrl) document.getElementById('appUrl').value = o.appUrl; });
  b.onclick = async () => {
    const app = document.getElementById('appUrl').value.trim(), cle = document.getElementById('cleTel').value.trim(), zone = document.getElementById('lienTel');
    const r = await chrome.runtime.sendMessage({ action: 'relaisAdresse' });
    if (!r?.url) { zone.hidden = false; zone.value = 'Configurez d’abord le relais ci-dessus.'; return; }
    if (!/^https:\/\/.+/.test(app)) { zone.hidden = false; zone.value = 'Adresse de l’app invalide.'; return; }
    if (cle.length < 32) { zone.hidden = false; zone.value = 'Clé TÉLÉPHONE trop courte.'; return; }
    await chrome.storage.local.set({ appUrl: app });
    zone.value = app.replace(/#.*$/, '') + '#relais=' + encodeURIComponent(r.url) + '&cle=' + encodeURIComponent(cle);
    zone.hidden = false; document.getElementById('copierLien').hidden = false;
  };
  document.getElementById('copierLien').onclick = async () => { await navigator.clipboard.writeText(document.getElementById('lienTel').value); document.getElementById('copierLien').textContent = 'Copié ✓'; };
})();
