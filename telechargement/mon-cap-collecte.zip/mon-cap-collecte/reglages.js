// numéro de version et liens vers l'aide et les nouveautés, dans l'en-tête
{ const a = document.getElementById('lienAide'), n = document.getElementById('lienNouv'); if (a) a.href = MON_CAP.aideUrl; if (n) n.href = MON_CAP.nouveautesUrl + '#v' + chrome.runtime.getManifest().version; }
{ const v = document.getElementById('versionExt'); if (v) v.textContent = 'version ' + chrome.runtime.getManifest().version; }
/* Mon Cap — Réglages : chaque section montre l'état réel en une ligne, et ne s'ouvre que pour modifier. */
const $ = s => document.querySelector(s);
const msg = m => chrome.runtime.sendMessage(m);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const NANO_OPTS = { expectedInputs: [{ type: 'text', languages: ['fr'] }], expectedOutputs: [{ type: 'text', languages: ['fr'] }] };
const ORIGINES_RELAIS = ['https://script.google.com/*', 'https://script.googleusercontent.com/*'];
const etat = (type, texte) => `<div class="etat ${type}" role="status"><span class="ic">${{ ok: '✓', ko: '!', attente: '…' }[type]}</span><span>${texte}</span></div>`;
const ilya = iso => { const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  return m < 1 ? 'à l’instant' : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`; };
const heureDe = t => new Date(t).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' });
const telecharger = (obj, nom) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' })); a.download = nom; a.click(); };
let E = {};

async function charger() {
  E = await msg({ action: 'assistantEtat' });
  bilan(); ecole(); drive(); cours(); telephones(); collectes(); ia(); journal();
}

/* ---------- Bilan : dernière collecte, prochaine, et le bouton pour en lancer une ---------- */
async function bilan() {
  const { etat: s = {}, majDispo: m } = await chrome.storage.local.get(['etat', 'majDispo']);
  const d = E.derniere;
  let h = '';
  if (s.enCours) h = etat('attente', 'Collecte en cours : ' + esc(s.etape || '…'));
  else if (!d) h = '<p style="margin:0">Aucune collecte pour l’instant.</p>';
  else h = `<p style="margin:0">Dernière collecte ${ilya(d.le)}${d.coba === 'ok' ? '' : ' : <b style="color:var(--alerte)">Coba n’a pas été lu</b>'}.${E.prochaine && E.autoHours ? ' Prochaine vers ' + heureDe(E.prochaine) + '.' : ''}</p>
    <div class="chiffres"><div><b>${d.travaux}</b><span>travaux</span></div><div><b>${d.cours}</b><span>cours Classroom</span></div>
    <div><b>${d.courriels}</b><span>courriels</span></div><div><b>${d.annonces}</b><span>annonces</span></div></div>`;
  if (m) h = `<div class="bloc" style="border-color:var(--surligneur)"><b>Nouvelle version ${esc(m.version)} disponible.</b> Vous avez la ${esc(chrome.runtime.getManifest().version)}.
    <div class="actions" style="margin-top:10px"><a class="btn" href="${esc(m.telechargement || MON_CAP.installUrl)}">Télécharger</a><a class="lien" href="${esc(MON_CAP.nouveautesUrl)}#v${esc(m.version)}" target="_blank" rel="noopener">Quoi de neuf ?</a><a class="lien" href="${esc(MON_CAP.installUrl)}#mise-a-jour" target="_blank" rel="noopener">Comment l’installer</a></div></div>` + h;
  $('#bilan').innerHTML = h + `<div class="actions" style="margin-top:16px"><button class="btn" id="lancer" ${s.enCours ? 'disabled' : ''}>Lancer une collecte</button>
    <a class="lien" href="${esc(MON_CAP.appUrl)}" target="_blank" rel="noopener">Ouvrir l’app</a>
    <button class="lien" id="verifMaj">Vérifier les mises à jour</button></div><div id="majRes"></div>`;
  $('#lancer').onclick = () => msg({ action: 'collecter', quoi: 'tout' });
  $('#verifMaj').onclick = async () => {
    $('#majRes').innerHTML = etat('attente', 'Vérification…');
    const v = await msg({ action: 'verifierMaj' });
    if (!v?.ok) { $('#majRes').innerHTML = etat('ko', 'Vérification impossible : ' + esc(v?.erreur || '?') + '.'); return; }
    if (!v.nouvelle) { $('#majRes').innerHTML = etat('ok', 'Mon Cap est à jour (version ' + esc(v.actuelle) + ').'); return; }
    bilan();   // la nouvelle version s'affiche en tête, avec le bouton Télécharger
  };
}

/* ---------- L'école ---------- */
function ecole() {
  const connue = MON_CAP.ecoles.find(e => e.url === E.cobaUrl);
  $('#ecoleEtat').innerHTML = E.cobaUrl
    ? `<span class="${E.identifiants ? 'ok' : 'ko'}">${E.identifiants ? '✓' : '!'}</span>${esc(connue ? connue.nom : E.cobaUrl)}${E.identifiants ? ', identifiants enregistrés' : ' : identifiants à saisir'}`
    : '<span class="ko">!</span>Pas encore configurée';
  const autre = E.cobaUrl && !connue;
  $('#ecoles').innerHTML = MON_CAP.ecoles.map((e, i) => `<label><input type="radio" name="ecole" value="${i}" ${connue === e || (!E.cobaUrl && i === 0) ? 'checked' : ''}> ${esc(e.nom)}</label>`).join('')
    + `<label><input type="radio" name="ecole" value="autre" ${autre ? 'checked' : ''}> Une autre école</label>`;
  $('#autreUrl').hidden = !autre; if (autre) $('#url').value = E.cobaUrl;
  document.querySelectorAll('[name=ecole]').forEach(r => r.onchange = () => { $('#autreUrl').hidden = r.value !== 'autre' || !r.checked; });
}
$('#verifier').onclick = async () => {
  const choix = document.querySelector('[name=ecole]:checked')?.value;
  const url = adresseConnexionCoba(choix === 'autre' ? $('#url').value : MON_CAP.ecoles[+choix]?.url);
  let org; try { org = new URL(url).origin; } catch { $('#ecoleRes').innerHTML = etat('ko', 'Indiquez l’adresse du portail Coba de l’école.'); return; }
  const u = $('#u').value.trim(), p = $('#p').value;
  if ((!u || !p) && !E.identifiants) { $('#ecoleRes').innerHTML = etat('ko', 'Saisissez votre identifiant et votre mot de passe Coba.'); return; }
  if (!(await chrome.permissions.request({ origins: [org + '/*'] }).catch(() => false))) { $('#ecoleRes').innerHTML = etat('ko', 'Chrome doit autoriser Mon Cap à ouvrir le portail de l’école.'); return; }
  $('#verifier').disabled = true; $('#ecoleRes').innerHTML = etat('attente', 'Connexion en cours, une dizaine de secondes…');
  await msg({ action: 'assistantReglages', reglages: { cobaUrl: url } });
  if (u && p) await msg({ action: 'identifiants', u, p });
  const r = await msg({ action: 'testerCoba' });
  $('#verifier').disabled = false; $('#p').value = '';
  $('#ecoleRes').innerHTML = r?.ok ? etat('ok', 'Connexion réussie, réglages enregistrés.') : etat('ko', esc(r?.raison || 'La connexion a échoué.'));
  E = await msg({ action: 'assistantEtat' }); ecole();
};
$('#oublier').onclick = async () => {
  if (!confirm('Oublier les identifiants Coba ? Les collectes automatiques ne pourront plus se connecter.')) return;
  await msg({ action: 'effacerIdentifiants' }); E = await msg({ action: 'assistantEtat' }); ecole();
};

/* ---------- Google Drive ---------- */
function drive() {
  $('#driveEtat').innerHTML = E.relais ? '<span class="ok">✓</span>Relié au relais <b>' + esc(E.relaisCourt || '') + '</b>. Les données vont dans votre Google Drive, dossier « Mon Cap ».<span class="note">Les téléphones affichent le même nom de relais en bas de l’onglet Jour.</span>'
    : '<span class="ko">!</span>Pas relié : les téléphones ne reçoivent rien. <a href="assistant.html">Relier avec l’assistant</a>';
}
$('#relier').onclick = async () => {
  const code = $('#code').value.trim(); if (!code) { $('#driveRes').innerHTML = etat('ko', 'Collez d’abord le code de liaison.'); return; }
  if (!(await chrome.permissions.request({ origins: ORIGINES_RELAIS }).catch(() => false))) { $('#driveRes').innerHTML = etat('ko', 'Chrome doit autoriser Mon Cap à joindre votre relais Google.'); return; }
  $('#driveRes').innerHTML = etat('attente', 'Vérification du relais…');
  const r = await msg({ action: 'relaisCode', code });
  $('#driveRes').innerHTML = r?.ok ? etat('ok', 'Google Drive relié.') : etat('ko', esc(r?.erreur || 'Le code n’a pas fonctionné.'));
  if (r?.ok) { $('#code').value = ''; E = await msg({ action: 'assistantEtat' }); drive(); telephones(); }
};
$('#delier').onclick = async () => {
  if (!confirm('Délier Google Drive ? Les collectes ne seront plus envoyées aux téléphones.')) return;
  await msg({ action: 'relaisEffacer' }); E = await msg({ action: 'assistantEtat' }); drive(); telephones();
};

/* ---------- Les cours ---------- */
function cours() {
  const l = E.coursListe || [];
  $('#coursListe').innerHTML = l.length ? l.map(c => `<li><span>${esc(c.nom || 'Cours sans nom')}</span><button class="retirer" data-url="${esc(c.url)}">Retirer</button></li>`).join('')
    : '<li>Aucun cours suivi.</li>';
  document.querySelectorAll('.retirer').forEach(b => b.onclick = async () => {
    await msg({ action: 'assistantReglages', reglages: { classroomLinks: l.map(c => c.url).filter(u => u !== b.dataset.url) } });
    E = await msg({ action: 'assistantEtat' }); cours();
  });
}
function choisirCours(enfants, zone, fusionner) {
  const plusieurs = enfants.length > 1;
  zone.innerHTML = enfants.map((e, i) => `<div class="bloc" style="margin-top:14px">
    ${plusieurs ? `<label style="margin:0 0 8px"><input type="radio" name="enfant" value="${i}" ${i === 0 ? 'checked' : ''}> Cours de ${esc(e.nom || 'votre enfant')}</label>` : `<b>Cours de ${esc(e.nom || 'votre enfant')}</b>`}
    <ul class="liste">${e.cours.map(c => `<li><label style="display:flex;gap:10px;align-items:center;margin:0;font-weight:500"><input type="checkbox" data-e="${i}" value="${esc(c.url)}" checked> ${esc(c.nom || 'Cours sans nom')}</label></li>`).join('')}</ul></div>`).join('')
    + '<div class="actions" style="margin-top:4px"><button class="btn" data-garder>Enregistrer ces cours</button></div>';
  zone.querySelector('[data-garder]').onclick = async () => {
    const i = plusieurs ? +(zone.querySelector('[name=enfant]:checked')?.value || 0) : 0;
    const liens = [...zone.querySelectorAll(`input[type=checkbox][data-e="${i}"]:checked`)].map(x => x.value);
    if (!liens.length) return;
    const coursNoms = {}; enfants[i].cours.forEach(c => { if (liens.includes(c.url)) coursNoms[c.url] = { nom: c.nom, enfant: enfants[i].nom || '' }; });
    const finaux = fusionner ? [...new Set([...(E.coursListe || []).map(c => c.url), ...liens])] : liens;
    await msg({ action: 'assistantReglages', reglages: { classroomLinks: finaux, coursNoms } });
    zone.innerHTML = etat('ok', finaux.length + ' cours suivis.'); E = await msg({ action: 'assistantEtat' }); cours();
  };
}
$('#trouver').onclick = async () => {
  if (!E.relais) { $('#coursRes').innerHTML = etat('ko', 'Reliez d’abord Google Drive : c’est le relais qui lit les résumés dans Gmail.'); return; }
  $('#trouver').disabled = true; $('#coursRes').innerHTML = etat('attente', 'Lecture de vos résumés Classroom…');
  const r = await msg({ action: 'coursDepuisResumes' }); $('#trouver').disabled = false;
  if (!r?.ok) { $('#coursRes').innerHTML = etat('ko', 'Le relais n’a pas pu lire Gmail : ' + esc(r?.erreur || '?')); return; }
  if (!r.enfants.length) { $('#coursRes').innerHTML = etat('ko', 'Aucun résumé Classroom dans ce compte Gmail depuis deux mois.'); return; }
  choisirCours(r.enfants, $('#coursRes'), false);
};

/* ---------- Les téléphones ---------- */
async function telephones() {
  const z = $('#telZone');
  if (!E.relais) { z.innerHTML = '<p class="aide" style="margin:0">Reliez d’abord Google Drive.</p>'; return; }
  if (!E.cleTel) {
    z.innerHTML = `<p class="aide" style="margin-top:0">Ce relais a été relié sans sa clé des téléphones. Collez-la ici, ou reliez-le avec son code de liaison.</p>
      <label for="cleTel">Clé des téléphones</label><input id="cleTel" type="password" autocomplete="off">
      <div class="actions"><button class="btn" id="cleTelOk">Enregistrer</button></div>`;
    $('#cleTelOk').onclick = async () => { const v = $('#cleTel').value.trim(); if (v.length < 32) return;
      await msg({ action: 'relaisCleTel', cle: v }); E = await msg({ action: 'assistantEtat' }); telephones(); };
    return;
  }
  const r = await msg({ action: 'lienTelephone', appUrl: MON_CAP.appUrl });
  if (!r?.lien) { z.innerHTML = etat('ko', 'Lien indisponible.'); return; }
  const q = qrcode(0, 'M'); q.addData(r.lien); q.make();
  z.innerHTML = `<div class="qr"><div class="code" role="img" aria-label="QR code du lien d’installation">${q.createSvgTag({ cellSize: 4, margin: 2, scalable: true })}</div>
    <div><p style="margin-top:0">Visez ce code avec l’appareil photo du téléphone. Sur iPhone, l’app guide l’installation en trois gestes.</p>
    <p><button class="btn second" id="copier">Copier le lien</button></p>
    <p class="aide">Téléphone perdu ? Dans votre feuille Mon Cap : menu Mon Cap → Changer la clé des téléphones, puis reliez ici le nouveau code. Les anciens liens cessent de fonctionner.</p></div></div>`;
  $('#copier').onclick = async () => { await navigator.clipboard.writeText(r.lien); $('#copier').textContent = 'Lien copié'; };
}

/* ---------- Les collectes ---------- */
function collectes() {
  const f = $('#frequence'), v = String(E.autoHours ?? 3);
  if (![...f.options].some(o => o.value === v)) f.insertAdjacentHTML('beforeend', `<option value="${esc(v)}">Toutes les ${esc(v)} heures</option>`);
  f.value = v; $('#ouvrirCourriels').checked = E.ouvrirCourriels !== false;
}
const enregistre = async (reglages) => { await msg({ action: 'assistantReglages', reglages }); $('#autoRes').innerHTML = etat('ok', 'Enregistré.'); setTimeout(() => { $('#autoRes').innerHTML = ''; }, 2500); E = await msg({ action: 'assistantEtat' }); bilan(); };
$('#frequence').onchange = () => enregistre({ autoHours: +$('#frequence').value });
$('#ouvrirCourriels').onchange = () => enregistre({ ouvrirCourriels: $('#ouvrirCourriels').checked });

/* ---------- L'aide à la lecture ---------- */
async function ia() {
  const actif = E.moteurIA && E.moteurIA !== 'aucun';
  $('#iaActive').checked = actif;
  let e = 'absent';
  if (typeof LanguageModel !== 'undefined') { try { e = await LanguageModel.availability(NANO_OPTS); } catch { e = 'unavailable'; } }
  const z = $('#iaRes');
  if (!actif) { z.innerHTML = ''; return; }
  if (e === 'available') z.innerHTML = etat('ok', 'Prête sur cet ordinateur.');
  else if (e === 'downloadable' || e === 'downloading') {
    z.innerHTML = '<p class="aide">Chrome doit télécharger le modèle une fois (quelques gigaoctets).</p><div class="actions" style="margin-top:6px"><button class="btn second" id="dl">Télécharger le modèle</button></div><div id="prog"></div>';
    $('#dl').onclick = async () => { $('#dl').disabled = true;
      try { const s = await LanguageModel.create({ ...NANO_OPTS, monitor(m) { m.addEventListener('downloadprogress', ev => { $('#prog').innerHTML = etat('attente', 'Téléchargement : ' + Math.round(ev.loaded * 100) + ' %'); }); } });
        s.destroy?.(); $('#prog').innerHTML = etat('ok', 'Prête sur cet ordinateur.'); } catch (x) { $('#prog').innerHTML = etat('ko', 'Échec : ' + esc(x.message)); } };
  } else z.innerHTML = etat('ko', 'Cet ordinateur ne peut pas faire tourner l’IA de Chrome. Mon Cap fonctionne sans elle.');
}
$('#iaActive').onchange = async () => { await msg({ action: 'assistantReglages', reglages: { moteurIA: $('#iaActive').checked ? 'nano' : 'aucun' } }); E = await msg({ action: 'assistantEtat' }); ia(); };

/* ---------- Dépannage ---------- */
$('#exporter').onclick = () => msg({ action: 'exporter' });
$('#diagCoba').onclick = async () => { $('#diagEtat').textContent = ' Analyse en cours…';
  const r = await msg({ action: 'diagCoba' });
  if (!r?.ok) { $('#diagEtat').textContent = ' Erreur : ' + (r?.erreur || '?'); return; }
  telecharger(r.out, 'coba-diag.json'); $('#diagEtat').textContent = ' Fichier coba-diag.json téléchargé.'; };
$('#diagResumes').onclick = async () => { $('#diagResEtat').textContent = ' Interrogation du relais…';
  const r = await msg({ action: 'relaisDiagResumes' });
  if (!r?.ok) { $('#diagResEtat').textContent = ' ' + (r?.erreur || 'échec'); return; }
  telecharger(r.out, 'resumes-diag.json');
  $('#diagResEtat').textContent = ` ${r.out.nb_resumes} résumé(s), ${r.out.resumes.reduce((s, x) => s + x.annonces_trouvees, 0)} annonce(s). Fichier téléchargé.`; };
$('#emlBtn').onclick = () => $('#emlFic').click();
$('#emlFic').onchange = async () => {
  const f = $('#emlFic').files[0]; if (!f) return;
  let r; try { r = lireResumeClassroom(await emlDepuisFichier(f)); } catch (e) { $('#emlRes').innerHTML = etat('ko', 'Fichier illisible.'); return; }
  if (!r.cours.length) { $('#emlRes').innerHTML = etat('ko', 'Aucun cours dans ce fichier : est-ce bien un résumé Classroom ?'); return; }
  choisirCours([{ nom: r.enfant, cours: r.cours.map(c => ({ url: c.url, nom: c.nom })) }], $('#emlRes'), true);
};
$('#rEnr').onclick = async () => {
  const url = $('#rUrl').value.trim(), cle = $('#rCle').value.trim(), tel = $('#rTel').value.trim();
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(url) || cle.length < 32) { $('#rRes').innerHTML = etat('ko', 'Vérifiez l’adresse (…/exec) et la clé.'); return; }
  if (!(await chrome.permissions.request({ origins: ORIGINES_RELAIS }).catch(() => false))) { $('#rRes').innerHTML = etat('ko', 'Autorisation refusée.'); return; }
  const r = await msg({ action: 'relaisEnregistrer', url, cle });
  if (r?.ok && tel) await msg({ action: 'relaisCleTel', cle: tel });
  $('#rRes').innerHTML = r?.ok ? etat('ok', 'Relais enregistré.') : etat('ko', esc(r?.erreur || 'échec'));
  if (r?.ok) { ['#rUrl', '#rCle', '#rTel'].forEach(s => $(s).value = ''); E = await msg({ action: 'assistantEtat' }); drive(); telephones(); }
};
async function journal() {
  const { journal: j = [] } = await chrome.storage.local.get('journal');
  $('#journal').innerHTML = j.slice(0, 40).map(l => `<li class="${l.niveau === 'alerte' ? 'alerte' : ''}"><span class="h">${new Date(l.t).toLocaleString('fr-CA', { dateStyle: 'short', timeStyle: 'short' })}</span>${esc(l.msg)}</li>`).join('') || '<li>Vide.</li>';
}
chrome.storage.onChanged.addListener(ch => {
  if (ch.etat || ch.derniere) msg({ action: 'assistantEtat' }).then(x => { E = x; bilan(); });
  // la liaison a changé (ici, dans l'assistant ou un autre onglet) : Google Drive et le QR code se mettent à jour
  if (ch.relais) msg({ action: 'assistantEtat' }).then(x => { E = x; drive(); telephones(); });
  if (ch.journal) journal();
});
charger();
