/* Mon Cap — annonces Classroom tirées des résumés envoyés aux tuteurs (via le relais).
   La vue tuteur de Classroom ne montre pas les annonces : seul le résumé par courriel les contient. */

const MOIS_FR = { 'janv': 1, 'févr': 2, 'fevr': 2, 'mars': 3, 'avr': 4, 'mai': 5, 'juin': 6, 'juil': 7, 'août': 8, 'aout': 8, 'sept': 9, 'oct': 10, 'nov': 11, 'déc': 12, 'dec': 12 };
const SECTIONS = /^(NOUVELLES ANNONCES|NOUVELLE ANNONCE|NOUVEAU MATÉRIEL|NOUVEAUX MATÉRIELS|NOUVEAUX DEVOIRS|NOUVEAU DEVOIR|NOUVELLES QUESTIONS|NOUVELLE QUESTION|TRAVAUX MANQUANTS|À RENDRE BIENTÔT|NEW ANNOUNCEMENTS?|NEW MATERIALS?|NEW ASSIGNMENTS?)\s*$/i;
const PUBLICATION = /^Publication ajoutée le\s+(\d{1,2})\s+([a-zéû]+)\.?\s+(\d{4}),\s*(\d{1,2})\s*h\s*(\d{1,2})(?:\s*min[^p]*)?\s*par\s+(.+?)\s*$/i;

// coursConnus : noms des classes Classroom (ex. « English 106-107 »), pour reconnaître les en-têtes de cours
function extraireAnnonces(texteResume, coursConnus = []) {
  // Gmail coupe les longues lignes : une ligne coupée se termine par deux espaces -> on la recolle.
  // « Afficher dans Classroom » et les liens <https://…> ne font pas partie du texte.
  const lignes = (texteResume || '').replace(/\r/g, '').replace(/ {2,}\n/g, ' ').split('\n').map(l => l.trim())
    .filter(l => !/^Afficher dans Classroom\s*:?$/i.test(l) && !/^<https?:\/\/[^>]+>$/.test(l));
  const connu = l => coursConnus.find(c => c && l.toLowerCase() === c.toLowerCase());
  const out = [];
  let cours = null, section = null, bloc = [];
  for (let i = 0; i < lignes.length; i++) {
    const l = lignes[i];
    if (!l) { if (bloc.length) bloc.push(''); continue; }
    if (connu(l)) { cours = connu(l); section = null; bloc = []; continue; }
    if (SECTIONS.test(l)) {
      // un en-tête de section : le cours est la dernière ligne non vide avant lui, si ce n'est pas un texte d'annonce
      if (!section && !bloc.length) { for (let k = i - 1; k >= 0; k--) if (lignes[k]) { if (!PUBLICATION.test(lignes[k])) cours = connu(lignes[k]) || lignes[k]; break; } }
      section = /ANNONCE|ANNOUNCEMENT/i.test(l) ? 'annonce' : 'autre'; bloc = []; continue;
    }
    const p = l.match(PUBLICATION);
    if (p) {
      if (section === 'annonce' && bloc.length) {
        const mo = MOIS_FR[p[2].toLowerCase().slice(0, 4)] || MOIS_FR[p[2].toLowerCase().slice(0, 3)];
        const texte = bloc.join('\n').replace(/\n{3,}/g, '\n\n').trim();
        out.push({ cours, auteur: p[6], texte,
          publie_le: mo ? `${p[3]}-${String(mo).padStart(2, '0')}-${p[1].padStart(2, '0')}T${p[4].padStart(2, '0')}:${p[5].padStart(2, '0')}` : null,
          date_complete: `${+p[1]} ${p[2]} ${p[3]}, ${p[4].padStart(2, '0')}:${p[5].padStart(2, '0')}` });
      }
      bloc = []; continue;
    }
    if (section) bloc.push(l);
  }
  return out;
}

// Plusieurs résumés répètent les mêmes annonces : une seule fois chacune
function fusionnerAnnonces(listes) {
  const vus = new Map();
  for (const a of listes.flat()) {
    const cle = (a.cours || '') + '|' + (a.publie_le || '') + '|' + (a.texte || '').slice(0, 80);
    if (!vus.has(cle)) vus.set(cle, { ...a, cle });
  }
  return [...vus.values()].sort((x, y) => (y.publie_le || '').localeCompare(x.publie_le || ''));
}
if (typeof module !== 'undefined') module.exports = { extraireAnnonces, fusionnerAnnonces };
