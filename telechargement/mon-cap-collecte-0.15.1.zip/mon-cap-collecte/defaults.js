// Réglages par défaut (modifiables dans la page Réglages)
const DEFAULTS = {
  cobaUrl: '',       // page de connexion du portail Coba de l'école, ex. https://portail.mon-ecole.qc.ca/pednet/login.coba
  groupe: '',        // groupe-classe de l'enfant, ex. 106
  classroomLinks: [],   // pages tuteur des cours de l'enfant (remplies par « Découvrir mes cours »)
  moteurIA: 'nano',       // 'nano' (Gemini Nano, intégré à Chrome), 'ollama' ou 'aucun'
  comparerOllama: false,  // diagnostic : extraire aussi avec Ollama pour comparer
  descriptions: true,     // ouvrir chaque travail pour lire sa description détaillée
  suivi: true,            // lire la page Suivi (commentaires des profs)
  agenda: true,           // lire l'agenda (horaire jour par jour + notes)
  agendaMois: 3,          // nombre de mois à avancer dans l'agenda (4 mois lus au total)
  courriels: true,        // lire la liste des courriels Coba
  ouvrirCourriels: true,  // ouvrir les nouveaux courriels (Coba les marque comme lus)
  ollamaModel: 'qwen3:8b',
  autoSave: true,
  toutRouvrir: false, // true = ouvrir tous les éléments Classroom à chaque collecte
  autoHours: 3   // 0 = pas de collecte automatique
};

// Adresse de connexion Coba : la page d'accueil (index.coba, avec ou sans paramètres) devient login.coba
function adresseConnexionCoba(u) {
  try { const x = new URL((u || '').trim()); if (/\/pednet\/index\.coba$/i.test(x.pathname)) { x.pathname = x.pathname.replace(/index\.coba$/i, 'login.coba'); x.search = ''; x.hash = ''; } return x.href; }
  catch { return (u || '').trim(); }
}

// Préréglages de l'assistant (hébergement maintenu par l'auteur de Mon Cap)
const MON_CAP = {
  appUrl: 'https://nkz82-dev.github.io/mon-cap/',   // l'app des téléphones (une seule adresse pour tous)
  installUrl: 'https://nkz82-dev.github.io/mon-cap/installer/',   // page d'installation et de mise à jour
  majUrl: 'https://nkz82-dev.github.io/mon-cap/telechargement/derniere.json',   // dernière version publiée
  modeleRelais: 'https://docs.google.com/spreadsheets/d/1zQXAkZudl0efkiBtJRVCUQhMEX5LU9s_Jv80X6IjJ8g/copy',   // feuille modèle « Mon Cap — relais »
  ecoles: [
    { nom: 'Collège de Montréal', url: 'https://portail.college-montreal.qc.ca/pednet/login.coba' }
  ]
};
