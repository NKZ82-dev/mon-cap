{ const v = document.getElementById('versionExt'); if (v) v.textContent = 'Mon Cap, version ' + chrome.runtime.getManifest().version; }
/* Mon Cap — fenêtre de l'icône : l'état en une phrase, quatre chiffres, un bouton. */
const $ = s => document.querySelector(s);
const msg = m => chrome.runtime.sendMessage(m);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ilya = iso => { const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  return m < 1 ? 'à l’instant' : m < 60 ? `il y a ${m} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`; };
const heureDe = t => new Date(t).toLocaleTimeString('fr-CA', { hour: '2-digit', minute: '2-digit' });
// étapes d'une collecte, pour placer le bateau (même ordre que dans l'assistant)
const REPERES = [/connexion automatique réussie|connecté/, /\d+ travaux/, /\d+ courriels/, /entrées de suivi/, /agenda \d+/, /horaire/, /activités/, /cours lus/, /annonce\(s\)/, /^Drive :/, /^IA \(/];

async function afficher() {
  const [E, st] = await Promise.all([msg({ action: 'assistantEtat' }), chrome.storage.local.get(['etat', 'journal', 'majDispo'])]);
  const s = st.etat || {}, j = st.journal || [], d = E.derniere;
  const z = $('#corps');
  const m = st.majDispo, bandeau = $('#maj');
  if (m) {
    bandeau.hidden = false;
    bandeau.innerHTML = `<p><b>Nouvelle version ${esc(m.version)} disponible</b>${m.nouveautes.length ? ' : ' + esc(m.nouveautes[0]) : ''}</p>
      <div class="rangee"><button class="btn petit" id="majTelecharger">Télécharger</button><button class="btn second petit" id="majComment">Comment l’installer</button></div>`;
    $('#majTelecharger').onclick = () => { chrome.tabs.create({ url: m.telechargement || MON_CAP.installUrl }); };
    $('#majComment').onclick = () => { chrome.tabs.create({ url: MON_CAP.installUrl + '#mise-a-jour' }); window.close(); };
  } else bandeau.hidden = true;
  if (!E.cobaUrl || !E.relais) {
    z.innerHTML = `<div class="installer"><p><b>Mon Cap n’est pas encore installé.</b> L’assistant guide chaque étape, en une quinzaine de minutes.</p>
      <button class="btn grand" id="installer">Installer Mon Cap</button></div>`;
    $('#installer').onclick = ouvrirAssistant; return;
  }
  if (s.enCours) {
    const depuis = s.depuis || Date.now();
    const recents = j.filter(l => Date.parse(l.t) >= depuis - 5000);
    const faits = REPERES.filter(r => recents.some(l => r.test(l.msg || ''))).length;
    const ia = (s.etape || '').match(/^IA (\d+)\/(\d+)/);
    let prog = faits / REPERES.length; if (ia) prog += (+ia[1] / +ia[2]) / REPERES.length;
    const pct = Math.round(Math.min(prog, 1) * 100);
    z.innerHTML = `<div class="mini" aria-hidden="true"><span class="bateau" style="left:calc(${pct}% - ${pct * 0.26}px)">⛵</span><span class="arrivee">🏁</span></div>
      <p class="etape-en-cours">Collecte en cours : <span>${esc(ia ? 'lecture par l’IA' : (s.etape || '…'))}</span></p>
      ${ia ? `<div class="barre-ia"><span style="width:${Math.round(+ia[1] / +ia[2] * 100)}%"></span></div><p class="aide" style="margin:0 0 10px">${ia[1]} sur ${ia[2]} messages</p>` : ''}
      ${ia ? '<button class="btn second grand" id="arreter">Arrêter la lecture par l’IA</button>' : ''}
      <ul class="dernieres">${recents.slice(0, 3).map(l => `<li class="${l.niveau === 'alerte' ? 'alerte' : ''}">${esc(l.msg)}</li>`).join('')}</ul>`;
    const a = $('#arreter'); if (a) a.onclick = () => msg({ action: 'arreter' });
    return;
  }
  const alerte = j.find(l => l.niveau === 'alerte' && d && Date.parse(l.t) >= Date.parse(d.le) - 600000);
  z.innerHTML = (d ? `<p class="phrase">Dernière collecte ${ilya(d.le)}${d.coba === 'ok' ? '' : ' : <span class="ko">Coba n’a pas été lu</span>'}.${E.prochaine && E.autoHours ? '<br><span class="aide">Prochaine vers ' + heureDe(E.prochaine) + '</span>' : ''}</p>
      <div class="chiffres"><div><b>${d.travaux}</b><span>travaux</span></div><div><b>${d.cours}</b><span>cours</span></div>
      <div><b>${d.courriels}</b><span>courriels</span></div><div><b>${d.annonces}</b><span>annonces</span></div></div>`
    : '<p class="phrase">Aucune collecte pour l’instant.</p>')
    + (alerte ? `<p class="aide" style="color:var(--alerte);margin:0 0 12px">! ${esc(alerte.msg)}</p>` : '')
    + '<button class="btn grand" id="lancer">Lancer une collecte</button>';
  $('#lancer').onclick = () => { $('#lancer').disabled = true; msg({ action: 'collecter', quoi: 'tout' }); };
}
function ouvrirAssistant(e) { e?.preventDefault?.(); chrome.tabs.create({ url: chrome.runtime.getURL('assistant.html') }); window.close(); }
$('#reglages').onclick = () => { chrome.runtime.openOptionsPage(); window.close(); };
$('#app').onclick = () => { chrome.tabs.create({ url: MON_CAP.appUrl }); window.close(); };
$('#plusBtn').onclick = () => { const m = $('#menuPlus'), ouvrir = m.hidden; m.hidden = !ouvrir; $('#plusBtn').setAttribute('aria-expanded', String(ouvrir)); };
$('#assistant').onclick = ouvrirAssistant;
document.querySelectorAll('[data-quoi]').forEach(b => b.onclick = () => { msg({ action: 'collecter', quoi: b.dataset.quoi }); $('#menuPlus').hidden = true; $('#plusBtn').setAttribute('aria-expanded', 'false'); });
chrome.storage.onChanged.addListener(ch => { if (ch.etat || ch.derniere || ch.journal) afficher(); });
afficher();
