// Document hors écran : sert seulement à appeler Gemini Nano quand le service worker n'y a pas accès.
chrome.runtime.onMessage.addListener((m, _s, reply) => {
  if (m.cible !== 'offscreen') return;
  if (m.action === 'nano') {
    if (typeof LanguageModel === 'undefined') { reply({ ok: false, erreur: 'Prompt API absente de ce Chrome' }); return; }
    nanoPrompt(m.texte, m.systeme, m.ms).then(r => reply({ ok: true, resultat: r }), e => reply({ ok: false, erreur: String(e) }));
    return true;
  }
});
