// Fuseau de l'utilisateur (celui du navigateur) et année scolaire déduite de la date :
// d'août à décembre, l'année scolaire commence cette année ; de janvier à juillet, l'année précédente.
const FUSEAU = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } })();
function anneeScolaire(ref = new Date()) {
  const debut = ref.getMonth() >= 7 ? ref.getFullYear() : ref.getFullYear() - 1;   // getMonth : 7 = août
  return { debut, fin: debut + 1, libelle: `${debut}-${debut + 1}` };
}
function dateLocale(d = new Date()) { return d.toLocaleDateString('en-CA', { timeZone: FUSEAU }); }

// Normalise une ligne du tableau Travaux de Coba
function normTravail(t) {
  const due = (t.date_due || '').match(/^(\d{4}-\d{2}-\d{2})(?:\s*à\s*(\d{1,2}:\d{2}))?/);
  return {
    ...t,
    date_due: due ? due[1] : (t.date_due || null),
    heure_due: due?.[2] || null,
    date_assignee: (t.date_assignee || '').match(/\d{4}-\d{2}-\d{2}/)?.[0] || null,
    date_completee: (t.date_completee || '').match(/\d{4}-\d{2}-\d{2}/)?.[0] || null,
    resultat: parseResultat(t.resultat_brut),
    cle: [t.cours, t.travail, t.date_assignee].join('|'),
    source: 'coba'
  };
}

// "24,0 / 27 (88,9 %)", "6,0 / 10", "C+", "C", vide
function parseResultat(r) {
  if (!r) return null;
  const s = r.replace(/\u00a0/g, ' ').trim();
  const num = x => parseFloat(x.replace(',', '.'));
  let m = s.match(/^([\d.,]+)\s*\/\s*([\d.,]+)(?:\s*\(([\d.,]+)\s*%\))?/);
  if (m) {
    const obtenu = num(m[1]), sur = num(m[2]);
    return { type: 'points', obtenu, sur, pct: m[3] ? num(m[3]) : Math.round(obtenu / sur * 1000) / 10 };
  }
  m = s.match(/^([\d.,]+)\s*%$/);
  if (m) return { type: 'pourcentage', pct: num(m[1]) };
  m = s.match(/^([A-E][+-]?)$/i);
  if (m) return { type: 'cote', cote: m[1].toUpperCase() };
  return { type: 'autre', brut: s };
}

// Compare deux collectes Coba : nouveaux travaux, résultats ou dates qui changent, travaux disparus
function comparer(avant = [], apres = []) {
  const A = new Map(avant.map(t => [t.cle, t]));
  const B = new Map(apres.map(t => [t.cle, t]));
  const ch = [];
  for (const [k, t] of B) {
    const p = A.get(k);
    if (!p) { ch.push({ type: 'nouveau', cours: t.cours, travail: t.travail, date_due: t.date_due }); continue; }
    if ((p.resultat_brut || '') !== (t.resultat_brut || ''))
      ch.push({ type: 'resultat', cours: t.cours, travail: t.travail, avant: p.resultat_brut, apres: t.resultat_brut });
    if (p.date_due !== t.date_due || p.heure_due !== t.heure_due)
      ch.push({ type: 'date', cours: t.cours, travail: t.travail, avant: [p.date_due, p.heure_due].filter(Boolean).join(' '), apres: [t.date_due, t.heure_due].filter(Boolean).join(' ') });
    if ((p.date_completee || '') !== (t.date_completee || ''))
      ch.push({ type: 'completee', cours: t.cours, travail: t.travail, apres: t.date_completee });
  }
  for (const [k, t] of A) if (!B.has(k)) ch.push({ type: 'disparu', cours: t.cours, travail: t.travail });
  return ch;
}

// Garde-fous sur les faits extraits par l'IA :
//  - la citation doit apparaître mot pour mot dans le texte ;
//  - un fait dont la citation n'est que le titre ou la date de l'élément est rejeté (simple répétition) ;
//  - une date est retirée si la citation ne mentionne ni jour, ni mois, ni date ;
//  - un examen ou un travail sans date reste « à valider ».
const RE_DATE_CITEE = new RegExp([
  '\\b\\d{1,2}\\s*(er)?\\s*(janv|févr|fevr|mars|avr|mai|juin|juil|août|aout|sept|oct|nov|déc|dec)',   // 15 octobre, 1er nov.
  '\\b(lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)\\b',
  '\\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b',
  '\\b(january|february|march|april|may|june|july|august|september|october|november|december)\\s+\\d{1,2}',
  '\\b(tomorrow|today|tonight|this (morning|afternoon|evening))\\b',
  '\\b(aujourd.hui|demain|après-demain|hier|cette semaine|semaine prochaine)\\b',
  '\\b\\d{4}-\\d{2}-\\d{2}\\b', '\\b\\d{1,2}/\\d{1,2}(/\\d{2,4})?\\b',
  '\\bjour\\s+\\d{1,2}\\b'                                                                             // jour 13 (cycle)
].join('|'), 'i');

function verifierExtraction(out, texte, entete = []) {
  const norm = s => (s || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
  const T = norm(texte);
  const E = entete.map(norm).filter(Boolean);
  const ok = d => !d || (/^\d{4}-\d{2}-\d{2}$/.test(d) && !isNaN(new Date(d + 'T12:00')));
  const rejetes = [];
  const garder = [];
  for (const e0 of out.elements || []) {
    const e = { ...e0 };
    const c = norm(e.citation);
    const raisons = [];
    // répétition du titre ou de la date de l'élément
    const cSansBruit = c.replace(/—|\(sujet :.*?\)|aucune échéance|publié :|modifié :|échéance le/g, ' ').replace(/\s+/g, ' ').trim();
    if (c && E.length && (!cSansBruit || E.some(h => h && (h.includes(cSansBruit) || cSansBruit.includes(h) && cSansBruit.length - h.length < 25)))) {
      rejetes.push({ ...e, raison: 'répète le titre ou la date de l’élément' }); continue;
    }
    // titre du fait qui recopie la ligne de la liste (titre + « — Aucune échéance », « Publié : … »)
    const t = norm(e.titre);
    if (E.length && /—|aucune échéance|publié :|modifié :|échéance le|\(sujet :/.test(t) && E.some(h => h.length > 5 && t.includes(h))) {
      rejetes.push({ ...e, raison: 'recopie la ligne de la liste' }); continue;
    }
    if (!c || !T.includes(c)) raisons.push('citation absente du texte');
    const dateEssentielle = ['examen', 'travail', 'recuperation', 'evenement'].includes(e.type);
    if (e.date && !RE_DATE_CITEE.test(e.citation || '')) { e.date_retiree = e.date; e.date = ''; }   // date inventée : retirée
    if (!ok(e.date)) raisons.push('date invalide');
    if (dateEssentielle && !e.date) raisons.push('date manquante');
    garder.push({ ...e, a_valider: raisons.length > 0, raisons });
  }
  return { elements: garder, dates_ecartees: out.dates_ecartees || [], rejetes };
}

// « Publié : 8 oct. », « Échéance le 14 oct. 12 h 15 », « Échéance le 09 h 20 » (= aujourd'hui),
// « Publié : Hier », « Aucune échéance ». L'année découle de l'année scolaire en cours.
function dateClassroom(lib, ref = new Date()) {
  if (!lib) return {};
  const MOIS = { 'janv': 1, 'févr': 2, 'mars': 3, 'avr': 4, 'mai': 5, 'juin': 6, 'juil': 7, 'août': 8, 'sept': 9, 'oct': 10, 'nov': 11, 'déc': 12 };
  const nature = /^(Échéance|Due)/i.test(lib) ? 'echeance' : /^Aucune échéance|^No due/i.test(lib) ? 'aucune_echeance' : /^Modifié|^Edited/i.test(lib) ? 'modifie' : 'publie';
  if (nature === 'aucune_echeance') return { nature_date: nature, date: null, heure: null };
  const iso = d => dateLocale(d);
  const as = anneeScolaire(ref);
  let date = null;
  const h = lib.match(/(\d{1,2})\s*h\s*(\d{2})/);
  const heure = h ? `${h[1].padStart(2, '0')}:${h[2]}` : null;
  const m = lib.match(/(\d{1,2})\s+(janv|févr|mars|avr|mai|juin|juil|août|sept|oct|nov|déc)\.?/i);
  if (m) {
    const mois = MOIS[m[2].toLowerCase()];
    const annee = mois >= 8 ? as.debut : as.fin;   // mois d'août à décembre : début de l'année scolaire
    date = `${annee}-${String(mois).padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  } else if (/Hier|Yesterday/i.test(lib)) {
    const d = new Date(ref); d.setDate(d.getDate() - 1); date = iso(d);
  } else if (/Demain|Tomorrow/i.test(lib)) {
    const d = new Date(ref); d.setDate(d.getDate() + 1); date = iso(d);
  } else if (heure) date = iso(ref);               // seulement une heure = aujourd'hui
  return { nature_date: nature, date, heure };
}
