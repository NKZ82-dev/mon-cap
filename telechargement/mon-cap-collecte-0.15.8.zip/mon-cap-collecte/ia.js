// Extraction de faits (examens, travaux, matériel, récups) dans du texte libre :
// détails Classroom et courriels Coba. Deux moteurs : Gemini Nano (intégré à Chrome) ou Ollama (local).

const SCHEMA = {
  type: 'object',
  properties: {
    elements: { type: 'array', items: { type: 'object', properties: {
      type: { type: 'string', enum: ['examen', 'travail', 'materiel', 'recuperation', 'consigne', 'evenement', 'autre'] },
      cours: { type: 'string' }, titre: { type: 'string' },
      date: { type: 'string' }, heure_ou_periode: { type: 'string' },
      details: { type: 'string' }, citation: { type: 'string' }
    }, required: ['type', 'titre', 'citation'] } },
    dates_ecartees: { type: 'array', items: { type: 'object', properties: {
      groupe: { type: 'string' }, date: { type: 'string' }, citation: { type: 'string' }
    }, required: ['date', 'citation'] } }
  },
  required: ['elements', 'dates_ecartees']
};

function consigneIA(s, refDate) {
  const AS = anneeScolaire(new Date(refDate + 'T12:00'));
  return `Tu extrais des faits d'un texte scolaire (publication Google Classroom ou courriel du portail Coba) pour un élève${s.groupe ? ' du groupe ' + s.groupe : ''}.
Année scolaire ${AS.libelle}. Date de la collecte : ${refDate}.
Règles :
- Uniquement ce qui est écrit. N'invente rien, ne propose rien, ne conseille rien.
- Types : examen, travail (à remettre), materiel (à apporter), recuperation, consigne, evenement (sortie, activité, journée spéciale), autre.
- ${s.groupe ? `Si le texte donne des dates différentes selon les groupes, garde seulement celle du groupe ${s.groupe} et mets les autres dans "dates_ecartees".` : 'Si le texte donne des dates différentes selon les groupes, crée un élément par groupe et indique le groupe dans "details".'}
- "date" au format AAAA-MM-JJ, ou chaîne vide si aucune date n'est écrite. Les mois d'août à décembre sont en ${AS.debut}, ceux de janvier à juillet en ${AS.fin}.
- "citation" : la phrase exacte du texte qui justifie l'élément, copiée mot pour mot.
- Si le texte ne contient aucun fait de ce genre (simple information générale), renvoie des listes vides.
- Réponds en français, uniquement en JSON.`;
}

function hashTexte(t) { let h = 5381; for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }

// ---------- Ollama ----------
async function extraireOllama(texte, s, refDate) {
  const body = {
    model: s.ollamaModel, stream: false, format: SCHEMA, options: { temperature: 0 },
    messages: [{ role: 'system', content: consigneIA(s, refDate) }, { role: 'user', content: texte.slice(0, 16000) }]
  };
  if (/^qwen3/i.test(s.ollamaModel)) body.think = false;
  const res = await fetch('http://localhost:11434/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!res.ok) throw new Error(`Ollama ${res.status} — ${(await res.text()).slice(0, 200)}`);
  return JSON.parse((await res.json()).message.content);
}

// ---------- Gemini Nano (Prompt API de Chrome) ----------
const NANO_LANGUES = { expectedInputs: [{ type: 'text', languages: ['fr'] }], expectedOutputs: [{ type: 'text', languages: ['fr'] }] };

async function nanoDisponibilite() {
  if (typeof LanguageModel === 'undefined') return 'absent';
  try { return await LanguageModel.availability(NANO_LANGUES); } catch (e) { return 'erreur: ' + e.message; }
}

// Exécutée là où LanguageModel existe (service worker ou document hors écran).
// Une session de base (avec la consigne) est créée une seule fois, puis clonée pour chaque texte :
// bien plus rapide que de recréer une session à chaque fois.
let nanoBase = null, nanoBaseConsigne = null;
// ms : délai au-delà duquel le calcul est réellement interrompu (sinon le modèle continue de tourner
// en arrière-plan et la tentative suivante attend derrière lui).
async function nanoPrompt(texte, systeme, ms = 85000) {
  if (!nanoBase || nanoBaseConsigne !== systeme) {
    try { nanoBase?.destroy?.(); } catch {}
    nanoBase = await LanguageModel.create({ ...NANO_LANGUES, temperature: 0.1, topK: 1, initialPrompts: [{ role: 'system', content: systeme }] });
    nanoBaseConsigne = systeme;
  }
  const session = nanoBase.clone ? await nanoBase.clone() : nanoBase;
  const ac = new AbortController();
  const minuteur = setTimeout(() => { ac.abort(); try { if (session !== nanoBase) session.destroy?.(); } catch {} }, ms);
  try {
    const r = await session.prompt(texte.slice(0, 6000), { responseConstraint: SCHEMA, signal: ac.signal });
    return JSON.parse(r);
  } catch (e) {
    if (ac.signal.aborted) {
      // sans clone, la session de base est occupée : la recréer pour la tentative suivante
      if (session === nanoBase) { try { nanoBase.destroy?.(); } catch {} nanoBase = null; }
      throw new Error('délai dépassé (' + Math.round(ms / 1000) + ' s)');
    }
    throw e;
  } finally { clearTimeout(minuteur); if (session !== nanoBase) { try { session.destroy?.(); } catch {} } }
}

async function extraireNano(texte, s, refDate, ms) {
  const systeme = consigneIA(s, refDate);
  if (typeof LanguageModel !== 'undefined') return nanoPrompt(texte, systeme, ms);
  // Sinon, passer par un document hors écran de l'extension
  if (!(await chrome.offscreen.hasDocument?.())) {
    await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['DOM_PARSER'], justification: 'Appeler le modèle IA intégré à Chrome (Prompt API).' });
  }
  const r = await chrome.runtime.sendMessage({ cible: 'offscreen', action: 'nano', texte, systeme, ms });
  if (!r?.ok) throw new Error(r?.erreur || 'Gemini Nano indisponible');
  return r.resultat;
}

// ---------- Point d'entrée ----------
async function extraireIA(texte, s, moteur, refDate, entete = [], ms) {
  const brut = moteur === 'ollama' ? await extraireOllama(texte, s, refDate) : await extraireNano(texte, s, refDate, ms);
  return { moteur, ...verifierExtraction(brut, texte, entete) };
}
