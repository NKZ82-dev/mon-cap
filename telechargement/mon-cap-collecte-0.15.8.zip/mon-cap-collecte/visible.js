// Injecté dans Classroom (monde de la page, au tout début) PENDANT la collecte seulement.
// Classroom n'affiche son contenu que si l'onglet est visible : on lui fait croire qu'il l'est.
(() => {
  try {
    Object.defineProperty(Document.prototype, 'visibilityState', { get: () => 'visible', configurable: true });
    Object.defineProperty(Document.prototype, 'hidden', { get: () => false, configurable: true });
    Object.defineProperty(Document.prototype, 'webkitVisibilityState', { get: () => 'visible', configurable: true });
    Document.prototype.hasFocus = () => true;
    window.addEventListener('visibilitychange', e => e.stopImmediatePropagation(), true);
    window.addEventListener('blur', e => e.stopImmediatePropagation(), true);

    // Dans un onglet caché, requestAnimationFrame ne se déclenche jamais : on ajoute un relais par minuterie
    const raf = window.requestAnimationFrame.bind(window), caf = window.cancelAnimationFrame.bind(window);
    const annules = new Set();
    window.requestAnimationFrame = cb => {
      let fait = false;
      const id = raf(t => { if (!fait) { fait = true; cb(t); } });
      setTimeout(() => { if (!fait && !annules.has(id)) { fait = true; cb(performance.now()); } }, 32);
      return id;
    };
    window.cancelAnimationFrame = id => { annules.add(id); caf(id); };
  } catch (e) { /* sans effet si le navigateur refuse */ }
})();
