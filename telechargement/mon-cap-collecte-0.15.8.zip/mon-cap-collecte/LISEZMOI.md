# Mon Cap — collecte (version de test 0.2)

Extension Chrome pour les parents. Elle lit :
- **Coba** : le tableau Travaux complet de votre enfant (dates, résultats, notes provisoires par compétence) ;
- **Classroom** : les travaux et le matériel de chaque cours, en vue tuteur.

Elle produit un fichier JSON (`Téléchargements/mon-cap/collecte-AAAA-MM-JJ.json`). Rien n'est envoyé ailleurs.

## Installer
1. Dézipper le dossier.
2. Chrome → `chrome://extensions` → activer **Mode développeur** (en haut à droite).
3. **Charger l'extension non empaquetée** → choisir le dossier `mon-cap-collecte`.
4. Épingler l'icône (pièce de puzzle → punaise).

## Configurer (une fois)
Ouvrir les **Réglages** (lien en bas de la fenêtre de l'extension).
1. **Portail Coba** : indiquer l'adresse de la page de connexion du portail de l'école (ex. `https://portail.mon-ecole.qc.ca/pednet/login.coba`), puis accepter la demande d'accès de Chrome.
   **Connexion Coba** : saisir votre identifiant et votre mot de passe, puis **Tester la connexion** (les identifiants sont enregistrés si le test réussit). Ils sont chiffrés (AES-256) avec une clé que seule l'extension peut utiliser.
2. **Groupe-classe** de votre enfant (proposé automatiquement à l'import du résumé Classroom). Il sert à garder la bonne date quand un enseignant en donne une par groupe.
3. **Cours Classroom** : enregistrez un *résumé Classroom* reçu par courriel en fichier .eml (Gmail : menu ⋮ du message → Télécharger le message ; Outlook : Enregistrer sous). Déposez-le dans les Réglages → **Ajouter la sélection**. Le groupe-classe est proposé d'après les noms des cours. Chrome doit ensuite être connecté au compte Google qui reçoit ces résumés.

## Fonctionnement
- Collecte automatique toutes les 3 h (modifiable), tant que Chrome est ouvert.
- Si la session Coba a expiré, l'extension se reconnecte seule. Après un échec, elle ne réessaie pas d'elle-même pendant 6 h (pour ne pas bloquer le compte) et envoie une notification.
- La collecte ouvre les pages dans des onglets d'arrière-plan de votre fenêtre Chrome (ils peuvent apparaître brièvement, puis se ferment). La collecte automatique attend un moment d'inactivité pour ne pas vous déranger.
- Chaque collecte est comparée à la précédente : nouveaux travaux, résultats ajoutés, dates modifiées (`changements`).
- Aucun courriel Coba n'est ouvert ; rien n'est modifié.

## Courriels Coba
L'extension lit la liste des courriels. Par défaut, elle ouvre aussi les **nouveaux** pour en lire le contenu : Coba les marque alors comme lus. Un courriel déjà lu par l'extension n'est jamais rouvert. Désactivable dans les Réglages.

## Intelligence artificielle
Elle lit les courriels écrits par les enseignants dans Coba pour y repérer les rendez-vous et échéances annoncés (récupération, examen déplacé, matériel à apporter). Classroom n'est pas analysé : ses échéances, étapes et pièces jointes sont lues directement. Tout reste sur l'ordinateur.

- **Gemini Nano** (par défaut) : intégré à Chrome, rien à installer. Réglages → **Préparer le modèle** pour le télécharger une fois. Demande un ordinateur récent.
- **Ollama** (plus précis) : installer Ollama, puis `ollama pull qwen3:8b`, et autoriser l'extension :
  - macOS : `launchctl setenv OLLAMA_ORIGINS "chrome-extension://*"`, puis relancer Ollama ;
  - Windows : variable d'environnement `OLLAMA_ORIGINS` = `chrome-extension://*`, puis relancer Ollama.
- Option diagnostic : extraire avec les deux modèles pour les comparer.

Chaque fait extrait garde sa citation exacte. S'il cite une phrase absente du texte, ou s'il manque une date, il est marqué `a_valider`. Un texte déjà analysé n'est pas réanalysé.
