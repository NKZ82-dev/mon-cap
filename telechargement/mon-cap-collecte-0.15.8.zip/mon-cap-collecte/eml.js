// Lit un résumé Classroom pour tuteurs enregistré en .eml et en tire les cours
// (nom + adresse tuteur /guar/<cours>/<enfant>) et le nom de l'enfant.
// Le fichier est lu en « chaîne binaire » (un caractère = un octet) : voir emlDepuisFichier().

const emlOctets = s => Uint8Array.from(s, c => c.charCodeAt(0) & 255);
async function emlDepuisFichier(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  let s = ''; for (let i = 0; i < buf.length; i += 8192) s += String.fromCharCode(...buf.subarray(i, i + 8192));
  return s;
}

function emlBytesToStr(bytes, charset = 'utf-8') {
  try { return new TextDecoder(charset.toLowerCase()).decode(bytes); } catch { return new TextDecoder('utf-8').decode(bytes); }
}
function emlDecodeQP(s) {
  const clean = s.replace(/=\r?\n/g, '');
  const out = [];
  for (let i = 0; i < clean.length; i++) {
    if (clean[i] === '=' && /^[0-9A-F]{2}$/i.test(clean.substr(i + 1, 2))) { out.push(parseInt(clean.substr(i + 1, 2), 16)); i += 2; }
    else out.push(clean.charCodeAt(i) & 255);
  }
  return new Uint8Array(out);
}
function emlDecodeB64(s) { const b = atob(s.replace(/[^A-Za-z0-9+/=]/g, '')); return Uint8Array.from(b, c => c.charCodeAt(0)); }

// Mots encodés des en-têtes : =?UTF-8?B?...?= ou =?UTF-8?Q?...?=
function emlDecodeHeader(v) {
  return emlBytesToStr(emlOctets(v || '')).replace(/\?=\s+=\?/g, '?==?').replace(/=\?([^?]+)\?([BQ])\?([^?]*)\?=/gi, (_, cs, enc, txt) =>
    emlBytesToStr(enc.toUpperCase() === 'B' ? emlDecodeB64(txt) : emlDecodeQP(txt.replace(/_/g, ' ')), cs));
}

function emlParse(raw) {
  const sep = raw.search(/\r?\n\r?\n/);
  const head = raw.slice(0, sep).replace(/\r?\n[ \t]+/g, ' ');
  const body = raw.slice(sep).replace(/^\r?\n\r?\n/, '');
  const headers = {};
  for (const l of head.split(/\r?\n/)) { const m = l.match(/^([\w-]+):\s*(.*)$/); if (m) headers[m[1].toLowerCase()] = m[2]; }
  return { headers, body };
}

// Renvoie toutes les parties texte décodées : [{ type, texte }]
function emlTextParts(raw) {
  const { headers, body } = emlParse(raw);
  const ct = headers['content-type'] || 'text/plain';
  const b = ct.match(/boundary="?([^";]+)"?/i);
  if (/^multipart\//i.test(ct) && b) {
    return body.split('--' + b[1]).slice(1).filter(p => !/^--/.test(p)).flatMap(p => emlTextParts(p.replace(/^\r?\n/, '')));
  }
  if (!/^text\//i.test(ct)) return [];
  const cs = (ct.match(/charset="?([^";]+)"?/i) || [])[1] || 'utf-8';
  const enc = (headers['content-transfer-encoding'] || '').toLowerCase();
  const bytes = enc === 'base64' ? emlDecodeB64(body) : enc === 'quoted-printable' ? emlDecodeQP(body) : new TextEncoder().encode(body);
  return [{ type: ct.split(';')[0].trim().toLowerCase(), texte: emlBytesToStr(bytes, cs) }];
}

function lireResumeClassroom(raw) {
  const { headers } = emlParse(raw);
  const sujet = emlDecodeHeader(headers['subject'] || '');
  const de = emlDecodeHeader(headers['from'] || '');
  const parts = emlTextParts(raw);
  const texte = (parts.find(p => p.type === 'text/plain') || parts[0] || { texte: '' }).texte;
  const html = (parts.find(p => p.type === 'text/html') || { texte: '' }).texte;

  const cours = new Map();
  // Partie texte : « Nom du cours » puis, à la ligne, <https://classroom.google.com/guar/X/Y>
  const re = /([^\r\n<>]+?)\s*\r?\n\s*<?(https:\/\/classroom\.google\.com\/(?:u\/\d+\/)?guar\/([A-Za-z0-9_-]+)\/([A-Za-z0-9_-]+))>?/g;
  for (const m of texte.matchAll(re)) {
    const nom = m[1].trim();
    const k = m[3] + '/' + m[4];
    if (/^(Afficher dans Classroom|View in Classroom)\s*:?$/i.test(nom)) { if (!cours.has(k)) cours.set(k, { cours: m[3], eleve: m[4], nom: '' }); continue; }
    if (!cours.get(k)?.nom) cours.set(k, { cours: m[3], eleve: m[4], nom });
  }
  // Secours : toute adresse tuteur présente ailleurs (HTML)
  for (const m of (texte + html).matchAll(/classroom\.google\.com\/(?:u\/\d+\/)?guar\/([A-Za-z0-9_-]{6,})\/([A-Za-z0-9_-]{6,})/g)) {
    const k = m[1] + '/' + m[2]; if (!cours.has(k)) cours.set(k, { cours: m[1], eleve: m[2], nom: '' });
  }
  const enfant = (sujet.match(/(?:pour|for)\s+(.+)$/i) || [])[1]?.trim() || '';
  return {
    valide: /classroom\.google\.com/i.test(de) || cours.size > 0,
    sujet, enfant,
    cours: [...cours.values()].map(c => ({ ...c, enfant, url: `https://classroom.google.com/guar/${c.cours}/${c.eleve}` }))
  };
}
