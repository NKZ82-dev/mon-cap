/* Mon Cap — liaison avec le relais Apps Script (dans le compte Google du parent).
   L'adresse et la clé de l'extension sont chiffrées (même méthode que les identifiants Coba). */

const ORIGINES_RELAIS = ['https://script.google.com/*', 'https://script.googleusercontent.com/*'];

async function enregistrerRelais(url, cle, cleTel = null) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await cleSecrete(), new TextEncoder().encode(JSON.stringify({ url, cle, cleTel })));
  await chrome.storage.local.set({ relais: { iv: b64(iv), data: b64(data), le: new Date().toISOString() } });
}
async function lireRelais() {
  const { relais: r } = await chrome.storage.local.get('relais');
  if (!r) return null;
  try { return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: deb64(r.iv) }, await cleSecrete(), deb64(r.data)))); }
  catch { return null; }
}
async function effacerRelais() { await chrome.storage.local.remove('relais'); }

// Appel au relais. En POST text/plain : pas de requête préalable (CORS), Google suit la redirection.
async function appelRelais(action, params = {}, relais = null, delai = 60000) {
  const r = relais || await lireRelais();
  if (!r) throw new Error('relais non configuré');
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), delai);
  try {
    const rep = await fetch(r.url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ cle: r.cle, action, ...params }), redirect: 'follow', signal: ctrl.signal });
    const txt = await rep.text();
    try { return JSON.parse(txt); } catch { throw new Error('réponse inattendue du relais (déploiement ou autorisation ?)'); }
  } catch (e) { if (e.name === 'AbortError') throw new Error('le relais n’a pas répondu en ' + Math.round(delai / 1000) + ' s'); throw e; }
  finally { clearTimeout(t); }
}

// Identifiant de cet ordinateur, pour la réservation d'une collecte
async function idMachine() {
  let { idMachine: id } = await chrome.storage.local.get('idMachine');
  if (!id) { id = 'ordi-' + crypto.getRandomValues(new Uint32Array(1))[0].toString(36); await chrome.storage.local.set({ idMachine: id }); }
  return id;
}

// Code de liaison produit par la feuille du relais : « MONCAP1. » + base64url({ v, u, e, t })
function lireCodeLiaison(code) {
  const m = String(code || '').trim().match(/^MONCAP1\.([A-Za-z0-9_-]+)$/);
  if (!m) return null;
  try {
    let s = m[1].replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
    const o = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(s), c => c.charCodeAt(0))));
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(o.u) || !o.e || !o.t) return null;
    return { url: o.u, cle: o.e, cleTel: o.t };
  } catch { return null; }
}
// Lien court des téléphones : <app>#c=<identifiant du script>.<clé téléphone en base64url> (QR code plus lisible)
function lienTelephone(appUrl, relais) {
  const id = (relais?.url || '').match(/\/macros\/s\/([\w-]+)\/exec$/)?.[1];
  if (!id || !relais?.cleTel) return null;
  const hex = relais.cleTel; let bin = '';
  if (/^[0-9a-f]+$/i.test(hex) && hex.length % 2 === 0) { for (let i = 0; i < hex.length; i += 2) bin += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16)); }
  const k = bin ? 'h' + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') : 't' + encodeURIComponent(hex);
  return appUrl.replace(/#.*$/, '') + '#c=' + id + '.' + k;
}
// Cours Classroom trouvés dans les résumés : en tête de chaque résumé, « Nom du cours » puis <lien tuteur>
function coursDesResumes(resumes) {
  const enfants = {};
  for (const r of resumes || []) {
    const nom = ((r.sujet || '').match(/(?:pour|concernant)\s+(.+?)\s*$/i) || [])[1] || null;   // hebdomadaire « pour », quotidien « concernant »
    const t = (r.texte || '').replace(/\r/g, '');
    const re = /^([^\n<]{2,80}?)\s*\n<(https:\/\/classroom\.google\.com\/guar\/[\w-]+\/([\w-]+))>/gm;
    let m;
    while ((m = re.exec(t))) {
      const cours = m[1].trim(), url = m[2], eleve = m[3];
      if (/^Afficher dans Classroom/i.test(cours)) continue;
      const e = enfants[eleve] || (enfants[eleve] = { id: eleve, nom, cours: {} });
      if (nom && !e.nom) e.nom = nom;
      e.cours[url] = e.cours[url] || cours;
    }
  }
  return Object.values(enfants).map(e => ({ id: e.id, nom: e.nom, cours: Object.entries(e.cours).map(([url, nom]) => ({ url, nom })) }));
}
