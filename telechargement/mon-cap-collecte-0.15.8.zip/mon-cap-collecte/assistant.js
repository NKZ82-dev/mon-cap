// numéro de version et lien vers l'aide, dans l'en-tête
{ const a = document.getElementById('lienAide'); if (a) a.href = MON_CAP.aideUrl; }
{ const v = document.getElementById('versionExt'); if (v) v.textContent = 'version ' + chrome.runtime.getManifest().version; }
/* Mon Cap — assistant d'installation pour un parent.
   Sept étapes ; la progression est gardée (chrome.storage) et chaque étape vérifie l'état réel. */
const $ = s => document.querySelector(s);
const msg = m => chrome.runtime.sendMessage(m);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const NANO_OPTS = { expectedInputs: [{ type: 'text', languages: ['fr'] }], expectedOutputs: [{ type: 'text', languages: ['fr'] }] };
const ORIGINES_RELAIS = ['https://script.google.com/*', 'https://script.googleusercontent.com/*'];

const ETAPES = [
  { id: 'bienvenue', titre: 'Bienvenue' },
  { id: 'coba', titre: 'Le portail Coba' },
  { id: 'relais', titre: 'Votre Google Drive' },
  { id: 'cours', titre: 'Les cours Classroom' },
  { id: 'ia', titre: 'L’aide à la lecture' },
  { id: 'collecte', titre: 'La première collecte' },
  { id: 'telephones', titre: 'Les téléphones' }
];
let A = { etape: 0, faits: {} }, E = {};   // progression, et état réel lu dans le service
let collecteEnCours = false;   // pendant une collecte, son étape s'affiche « en cours », même si une précédente a réussi

async function charger() {
  E = await msg({ action: 'assistantEtat' });
  A = { etape: 0, faits: {}, ...(E.assistant || {}) };
  // ce qui est déjà configuré compte comme fait (ordinateur déjà installé, ou reprise de l'assistant)
  if (E.cobaUrl && E.identifiants) A.faits.coba = true;
  if (E.relais) A.faits.relais = true;
  if (E.cours) A.faits.cours = true;
  if (E.derniere?.coba === 'ok') A.faits.collecte = true;
  collecteEnCours = !!(await chrome.storage.local.get('etat')).etat?.enCours;
  afficher();
}
const sauver = () => msg({ action: 'assistantProgres', assistant: A });
function aller(i) { A.etape = Math.max(0, Math.min(ETAPES.length, i)); sauver(); afficher(true); }
function fait(id) { A.faits[id] = true; sauver(); dessinerRoute(); }

function dessinerRoute() {
  $('#route').innerHTML = ETAPES.map((e, i) => {
    const enCours = e.id === 'collecte' && collecteEnCours;
    const cls = enCours ? 'travail' : A.faits[e.id] ? 'fait' : (i === A.etape ? 'encours' : '');
    const cl = A.etape === i ? ' encours' : '';
    return `<li class="${cls}${cl}"><button data-aller="${i}" ${i > 0 && !A.faits.bienvenue ? 'disabled' : ''} ${i === A.etape ? 'aria-current="step"' : ''}>
      <span class="point">${enCours ? '' : A.faits[e.id] ? '✓' : i + 1}</span><span class="libelle">${esc(e.titre)}</span></button></li>`;
  }).join('');
}
function afficher(focus) {
  dessinerRoute();
  const z = $('#etape');
  z.classList.remove('entree'); void z.offsetWidth; z.classList.add('entree');
  const id = A.etape >= ETAPES.length ? 'fin' : ETAPES[A.etape].id;
  VUES[id](z);
  if (focus) { z.focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: 'instant' }); }
}
const barre = (suivantTxt = 'Continuer', actif = true, retour = true) =>
  `<div class="actions">${retour ? '<button class="btn second" data-nav="-1">Retour</button>' : ''}
   <button class="btn suivant" data-nav="1" ${actif ? '' : 'disabled'}>${suivantTxt}</button></div>`;
const etat = (type, texte) => `<div class="etat ${type}" role="status"><span class="ic">${{ ok: '✓', ko: '!', attente: '…' }[type]}</span><span>${texte}</span></div>`;
const activerSuivant = () => { const b = document.querySelector('[data-nav="1"]'); if (b) b.disabled = false; };

// Les écrans d'autorisation de Google, tels qu'ils s'affichent (français, et anglais entre parenthèses)
const AUTORISATIONS = `<ol class="sousgestes">
  <li>Choisissez votre compte Google.</li>
  <li>Écran « Google n’a pas vérifié cette application » : c’est normal pour un programme personnel. Cliquez sur <span class="menu">Options avancées</span> (<i>Advanced</i>), puis sur <span class="menu">Accéder à Mon Cap — relais (non recommandé)</span>.</li>
  <li>Écran « Sélectionnez les données… » : cochez <span class="menu">Tout sélectionner</span> (<i>Select all</i>), puis <span class="menu">Continuer</span>. Le relais a besoin de tout : lire les résumés Classroom et écrire ses fichiers dans Drive.</li>
</ol>`;

/* ---------------------------------------------------------------- les étapes */
const VUES = {
  bienvenue(z) {
    z.innerHTML = `<h1>Installons Mon Cap</h1>
      <p class="chapeau">Chaque jour, Mon Cap rassemble les travaux, l’horaire, les évaluations et les messages des profs de votre enfant, et les met sur son téléphone, dans une app faite pour lui.</p>
      <div class="bloc"><h2 style="margin-top:0">Ce qu’il vous faut, une quinzaine de minutes</h2>
      <ul class="liste">
        <li>Cet ordinateur, avec Chrome. Les collectes se font quand Chrome est ouvert.</li>
        <li>Votre identifiant et votre mot de passe du portail Coba de l’école.</li>
        <li>Le compte Gmail qui reçoit les résumés Classroom de votre enfant.</li>
        <li>Le téléphone de votre enfant, et le vôtre si vous voulez suivre aussi.</li>
      </ul></div>
      <div class="bloc calme"><b>Vos données restent chez vous.</b> Elles sont gardées dans votre Google Drive et sur vos appareils. Mon Cap n’a pas de serveur et personne d’autre n’y a accès.</div>
      ${barre('Commencer', true, false)}`;
    z.querySelector('[data-nav="1"]').onclick = () => { fait('bienvenue'); aller(1); };
  },

  coba(z) {
    const ecoles = MON_CAP.ecoles;
    const connue = ecoles.find(e => e.url === E.cobaUrl);
    const autre = E.cobaUrl && !connue;
    z.innerHTML = `<h1>Le portail Coba de l’école</h1>
      <p class="chapeau">C’est là que l’école publie les travaux, l’agenda, l’horaire et les commentaires des profs. Mon Cap s’y connecte avec vos identifiants, dans une fenêtre invisible.</p>
      <h2>L’école</h2>
      <div class="choix" role="radiogroup">
        ${ecoles.map((e, i) => `<label><input type="radio" name="ecole" value="${i}" ${connue === e || (!E.cobaUrl && i === 0) ? 'checked' : ''}> ${esc(e.nom)}</label>`).join('')}
        <label><input type="radio" name="ecole" value="autre" ${autre ? 'checked' : ''}> Une autre école</label>
      </div>
      <div id="autreUrl" ${autre ? '' : 'hidden'}>
        <label for="url">Adresse du portail Coba</label>
        <input id="url" type="url" placeholder="https://portail.mon-ecole.qc.ca/pednet/login.coba" value="${autre ? esc(E.cobaUrl) : ''}">
        <div class="aide">Ouvrez le portail de l’école, et copiez l’adresse de la page où l’on saisit l’identifiant.</div>
      </div>
      <h2>Vos identifiants Coba</h2>
      ${E.identifiants ? '<p class="aide">Des identifiants sont déjà enregistrés. Saisissez-en d’autres seulement pour les remplacer.</p>' : ''}
      <label for="u">Identifiant</label><input id="u" type="text" autocomplete="username">
      <label for="p">Mot de passe</label><input id="p" type="password" autocomplete="current-password">
      <div class="aide">Ils sont chiffrés sur cet ordinateur, et ne quittent jamais l’extension.</div>
      <div class="actions"><button class="btn" id="verifier">Vérifier la connexion</button></div>
      <div id="res">${A.faits.coba ? etat('ok', 'Connexion à Coba vérifiée.') : ''}</div>
      ${barre('Continuer', !!A.faits.coba)}`;
    z.querySelectorAll('[name=ecole]').forEach(r => r.onchange = () => { $('#autreUrl').hidden = r.value !== 'autre' || !r.checked; });
    $('#verifier').onclick = async () => {
      const choix = z.querySelector('[name=ecole]:checked')?.value;
      const url = adresseConnexionCoba(choix === 'autre' ? $('#url').value : ecoles[+choix]?.url);
      let org; try { org = new URL(url).origin; } catch { $('#res').innerHTML = etat('ko', 'Indiquez l’adresse du portail Coba de l’école.'); return; }
      const u = $('#u').value.trim(), p = $('#p').value;
      if ((!u || !p) && !E.identifiants) { $('#res').innerHTML = etat('ko', 'Saisissez votre identifiant et votre mot de passe Coba.'); return; }
      // l'autorisation doit être demandée directement dans le clic
      const ok = await chrome.permissions.request({ origins: [org + '/*'] }).catch(() => false);
      if (!ok) { $('#res').innerHTML = etat('ko', 'Chrome doit autoriser Mon Cap à ouvrir le portail de l’école. Cliquez de nouveau et choisissez « Autoriser ».'); return; }
      $('#verifier').disabled = true; $('#res').innerHTML = etat('attente', 'Connexion en cours, une dizaine de secondes…');
      await msg({ action: 'assistantReglages', reglages: { cobaUrl: url } });
      if (u && p) await msg({ action: 'identifiants', u, p });
      const r = await msg({ action: 'testerCoba' });
      $('#verifier').disabled = false;
      if (r?.ok) { E.cobaUrl = url; E.identifiants = true; fait('coba'); $('#res').innerHTML = etat('ok', 'Connexion réussie : Mon Cap a bien ouvert le portail de l’école.'); activerSuivant(); $('#p').value = ''; }
      else $('#res').innerHTML = etat('ko', esc(r?.raison || 'La connexion a échoué.') + ' Vérifiez l’identifiant et le mot de passe en vous connectant au portail dans un onglet.');
    };
    z.querySelector('[data-nav="1"]').onclick = () => aller(2);
    z.querySelector('[data-nav="-1"]').onclick = () => aller(0);
  },

  relais(z) {
    const modele = MON_CAP.modeleRelais;
    z.innerHTML = `<h1>Votre espace dans Google Drive</h1>
      <p class="chapeau">Mon Cap garde les données dans votre Google Drive, pour que les téléphones les reçoivent, et lit les résumés Classroom dans votre Gmail. Pour cela, vous allez copier dans votre compte une feuille Google qui contient un petit programme.</p>
      <div class="bloc calme"><b>Mon Cap est déjà installé sur un autre ordinateur ?</b> Ne recopiez pas la feuille : ouvrez votre feuille Mon Cap existante, menu <span class="menu">Mon Cap → 2. Obtenir mon code de liaison</span> avec l’URL de son déploiement actuel, puis passez directement au dernier geste ci-dessous.</div>
      <div class="bloc calme"><b>Utilisez le compte Google qui reçoit les résumés Classroom de votre enfant.</b>
        Le programme ne voit que les fichiers qu’il crée lui-même dans votre Drive, et ne fait que lire les courriels envoyés par Classroom.</div>
      <div class="bloc"><ol class="gestes">
        <li><b>Copiez la feuille Mon Cap.</b>
          <div class="actions" style="margin-top:10px">${modele ? `<a class="btn" href="${esc(modele)}" target="_blank" rel="noopener">Ouvrir la feuille à copier</a>` : '<span class="etat ko"><span class="ic">!</span><span>Le lien du modèle n’est pas encore configuré dans cette version.</span></span>'}</div>
          <span class="voir">Google affiche « Copier le document » : cliquez sur <span class="menu">Créer une copie</span>.</span></li>
        <li><b>Préparez le relais.</b> Dans votre copie, ouvrez le menu <span class="menu">Mon Cap → 1. Préparer le relais</span>.
          <span class="voir">Le menu apparaît quelques secondes après l’ouverture de la feuille, à droite de « Aide ». Google demande alors des autorisations : suivez les gestes ci-dessous. Ensuite, un dossier <b>Mon Cap</b> apparaît dans votre Google Drive : glissez-y votre copie de la feuille pour tout garder au même endroit.</span>
          ${AUTORISATIONS}</li>
        <li><b>Publiez le relais.</b> Menu <span class="menu">Extensions → Apps Script</span>, puis en haut à droite <span class="menu">Déployer → Nouveau déploiement</span>.
          <span class="voir">Roue dentée → <span class="menu">Application Web</span>. Exécuter en tant que : <span class="menu">Moi</span>. Qui a accès : <span class="menu">Tout le monde</span>. Puis <span class="menu">Déployer</span>. Google redemande les mêmes autorisations : refaites les gestes ci-dessus. Copiez enfin l’URL de l’application Web.</span></li>
        <li><b>Obtenez votre code.</b> Revenez à la feuille : menu <span class="menu">Mon Cap → 2. Obtenir mon code de liaison</span>, collez l’URL, puis <span class="menu">Copier le code</span>.</li>
        <li><b>Collez le code ici.</b>
          <label for="code" style="margin-top:10px">Code de liaison</label>
          <textarea id="code" placeholder="MONCAP1.…" spellcheck="false"></textarea>
          <div class="actions" style="margin-top:12px"><button class="btn" id="relier">Relier</button></div>
          <div id="res">${A.faits.relais ? etat('ok', 'Votre Google Drive est relié.') : ''}</div></li>
      </ol></div>
      ${barre('Continuer', !!A.faits.relais)}`;
    $('#relier').onclick = async () => {
      const code = $('#code').value.trim();
      if (!code) { $('#res').innerHTML = etat('ko', 'Collez d’abord le code obtenu dans la feuille.'); return; }
      const ok = await chrome.permissions.request({ origins: ORIGINES_RELAIS }).catch(() => false);
      if (!ok) { $('#res').innerHTML = etat('ko', 'Chrome doit autoriser Mon Cap à joindre votre relais Google. Cliquez de nouveau et choisissez « Autoriser ».'); return; }
      $('#relier').disabled = true; $('#res').innerHTML = etat('attente', 'Vérification du relais…');
      const r = await msg({ action: 'relaisCode', code });
      $('#relier').disabled = false;
      if (r?.ok) { E.relais = E.cleTel = true; fait('relais'); $('#res').innerHTML = etat('ok', 'Votre Google Drive est relié.'); activerSuivant(); $('#code').value = ''; }
      else $('#res').innerHTML = etat('ko', esc(r?.erreur || 'Le code n’a pas fonctionné.'));
    };
    z.querySelector('[data-nav="1"]').onclick = () => aller(3);
    z.querySelector('[data-nav="-1"]').onclick = () => aller(1);
  },

  cours(z) {
    z.innerHTML = `<h1>Les cours Classroom</h1>
      <p class="chapeau">Mon Cap trouve les cours de votre enfant dans les résumés que Classroom vous envoie par courriel. Rien à recopier.</p>
      <div class="actions" style="margin-top:0"><button class="btn" id="trouver">Trouver les cours</button></div>
      <div id="res">${A.faits.cours ? etat('ok', E.cours + ' cours enregistrés.') : ''}</div>
      <div class="bloc calme" style="margin-top:22px"><b>Réglez les résumés en « quotidien ».</b> Les annonces des profs n’arrivent que par ces résumés. Ouvrez un résumé Classroom dans Gmail, cliquez tout en bas sur le lien des paramètres, et choisissez une fréquence quotidienne.</div>
      ${barre('Continuer', !!A.faits.cours)}`;
    $('#trouver').onclick = async () => {
      if (!E.relais) { $('#res').innerHTML = etat('ko', 'Reliez d’abord votre Google Drive, à l’étape précédente.'); return; }
      $('#trouver').disabled = true; $('#res').innerHTML = etat('attente', 'Lecture de vos résumés Classroom…');
      const r = await msg({ action: 'coursDepuisResumes' });
      $('#trouver').disabled = false;
      if (!r?.ok) { $('#res').innerHTML = etat('ko', 'Le relais n’a pas pu lire Gmail : ' + esc(r?.erreur || 'erreur inconnue')); return; }
      if (!r.enfants.length) {
        $('#res').innerHTML = etat('ko', r.nbResumes ? 'Des courriels Classroom ont été trouvés, mais aucun résumé de cours.' : 'Aucun résumé Classroom dans ce compte Gmail depuis deux mois.')
          + '<p class="aide">Les résumés pour les tuteurs s’activent depuis l’invitation reçue de l’école (« Invitation à recevoir des résumés »). S’ils arrivent dans un autre compte Gmail, refaites l’étape précédente avec ce compte-là.</p>';
        return;
      }
      const plusieurs = r.enfants.length > 1;
      $('#res').innerHTML = r.enfants.map((e, i) => `<div class="bloc" style="margin-top:14px">
        ${plusieurs ? `<label style="margin:0 0 8px"><input type="radio" name="enfant" value="${i}" ${i === 0 ? 'checked' : ''}> Cours de ${esc(e.nom || 'votre enfant')}</label>` : `<h2 style="margin-top:0">Cours de ${esc(e.nom || 'votre enfant')}</h2>`}
        <ul class="liste">${e.cours.map(c => `<li><label style="display:flex;gap:10px;align-items:center;margin:0;font-weight:500"><input type="checkbox" data-e="${i}" value="${esc(c.url)}" checked> ${esc(c.nom)}</label></li>`).join('')}</ul></div>`).join('')
        + `<div class="actions" style="margin-top:4px"><button class="btn" id="garder">Enregistrer ces cours</button></div><div id="res2"></div>`;
      $('#garder').onclick = async () => {
        const i = plusieurs ? +(z.querySelector('[name=enfant]:checked')?.value || 0) : 0;
        const liens = [...z.querySelectorAll(`input[type=checkbox][data-e="${i}"]:checked`)].map(x => x.value);
        if (!liens.length) { $('#res2').innerHTML = etat('ko', 'Cochez au moins un cours.'); return; }
        const e = r.enfants[i], coursNoms = {};
        e.cours.filter(c => liens.includes(c.url)).forEach(c => { coursNoms[c.url] = { nom: c.nom, enfant: e.nom || '' }; });
        await msg({ action: 'assistantReglages', reglages: { classroomLinks: liens, coursNoms } });
        E.cours = liens.length; fait('cours'); $('#res2').innerHTML = etat('ok', liens.length + ' cours enregistrés.'); activerSuivant();
      };
    };
    z.querySelector('[data-nav="1"]').onclick = () => aller(4);
    z.querySelector('[data-nav="-1"]').onclick = () => aller(2);
  },

  async ia(z) {
    z.innerHTML = `<h1>L’aide à la lecture des messages</h1>
      <p class="chapeau">Une intelligence artificielle intégrée à Chrome lit les courriels et les annonces des profs pour y repérer les récupérations, les sorties et les changements d’horaire. Elle tourne sur cet ordinateur : rien n’est envoyé en ligne.</p>
      <div id="res">${etat('attente', 'Vérification de cet ordinateur…')}</div>
      ${barre('Continuer', false)}`;
    z.querySelector('[data-nav="1"]').onclick = () => { fait('ia'); aller(5); };
    z.querySelector('[data-nav="-1"]').onclick = () => aller(3);
    let e = 'absent';
    if (typeof LanguageModel !== 'undefined') { try { e = await LanguageModel.availability(NANO_OPTS); } catch { e = 'unavailable'; } }
    const sans = async () => { await msg({ action: 'assistantReglages', reglages: { moteurIA: 'aucun' } }); };
    if (e === 'available') {
      await msg({ action: 'assistantReglages', reglages: { moteurIA: 'nano' } });
      $('#res').innerHTML = etat('ok', 'L’IA est prête sur cet ordinateur.'); activerSuivant();
    } else if (e === 'downloadable' || e === 'downloading') {
      $('#res').innerHTML = `<p>Chrome doit télécharger le modèle une fois (quelques gigaoctets). Le téléchargement continue même si vous passez à l’étape suivante.</p>
        <div class="actions" style="margin-top:8px"><button class="btn" id="dl">Télécharger le modèle</button><button class="lien" id="sansIA">Continuer sans l’IA</button></div><div id="prog"></div>`;
      $('#dl').onclick = async () => {
        $('#dl').disabled = true; $('#prog').innerHTML = etat('attente', 'Téléchargement : 0 %');
        await msg({ action: 'assistantReglages', reglages: { moteurIA: 'nano' } }); activerSuivant();
        try {
          const s = await LanguageModel.create({ ...NANO_OPTS, monitor(m) { m.addEventListener('downloadprogress', ev => { $('#prog').innerHTML = etat('attente', 'Téléchargement : ' + Math.round(ev.loaded * 100) + ' %'); }); } });
          s.destroy?.(); $('#prog').innerHTML = etat('ok', 'L’IA est prête sur cet ordinateur.');
        } catch (x) { $('#prog').innerHTML = etat('ko', 'Le téléchargement a échoué : ' + esc(x.message) + '. Mon Cap fonctionnera sans l’IA.'); await sans(); }
      };
      $('#sansIA').onclick = async () => { await sans(); fait('ia'); aller(5); };
    } else {
      await sans();
      $('#res').innerHTML = etat('ko', 'Cet ordinateur ne peut pas faire tourner l’IA de Chrome.')
        + '<p>Ce n’est pas bloquant : Mon Cap lira quand même les travaux, l’horaire, l’agenda, et les dates écrites clairement dans les messages.</p>';
      activerSuivant();
    }
  },

  collecte(z) {
    const d = E.derniere;
    z.innerHTML = `<h1>La première collecte</h1>
      <p class="chapeau">Mon Cap va lire le portail Coba et Classroom, puis déposer le résultat dans votre Google Drive. La première fois, comptez quelques minutes.</p>
      <div class="actions" style="margin-top:0"><button class="btn" id="lancer">${d?.coba === 'ok' ? 'Relancer une collecte' : 'Lancer la première collecte'}</button></div>
      <div id="res">${d?.coba === 'ok' ? resume(d) : ''}</div>
      <div class="bloc calme" style="margin-top:22px">Ensuite, Mon Cap recommence tout seul toutes les 3 heures, tant que Chrome est ouvert sur cet ordinateur.</div>
      ${barre('Continuer', !!A.faits.collecte)}`;
    $('#lancer').onclick = async () => {
      $('#lancer').disabled = true;
      A.collecteT0 = Date.now(); A.collecteAvant = E.derniere?.le || ''; sauver();
      $('#res').innerHTML = suiviCollecte([], {}, false);
      const rep = await msg({ action: 'collecter', quoi: 'tout' });
      suivreCollecte(A.collecteT0, A.collecteAvant, !!rep?.dejaEnCours);
    };
    // Retour sur l'étape pendant ou après une collecte : on reprend le suivi, avec le détail déjà affiché
    if (A.collecteT0 && Date.now() - A.collecteT0 < 3 * 3600e3) { $('#lancer').disabled = true; suivreCollecte(A.collecteT0, A.collecteAvant || '', true); }
    z.querySelector('[data-nav="1"]').onclick = () => aller(6);
    z.querySelector('[data-nav="-1"]').onclick = () => aller(4);
  },

  async telephones(z) {
    const r = await msg({ action: 'lienTelephone', appUrl: MON_CAP.appUrl });
    if (!r?.lien) {
      z.innerHTML = `<h1>Les téléphones</h1>${etat('ko', 'Reliez d’abord votre Google Drive avec le code de liaison, à l’étape « Votre Google Drive ».')}${barre('Terminer', false)}`;
      z.querySelector('[data-nav="-1"]').onclick = () => aller(5); return;
    }
    const q = qrcode(0, 'M'); q.addData(r.lien); q.make();
    z.innerHTML = `<h1>Le téléphone de votre enfant</h1>
      <p class="chapeau">Ouvrez l’appareil photo du téléphone et visez ce code. Faites de même avec le vôtre si vous voulez suivre aussi : les coches sont partagées.</p>
      <div class="qr"><div class="code" role="img" aria-label="QR code du lien d’installation">${q.createSvgTag({ cellSize: 4, margin: 2, scalable: true })}</div>
        <div><p style="margin-top:0"><button class="btn second" id="copier">Copier le lien</button></p>
        <p class="aide">Pour l’envoyer à un téléphone par message. Ce lien donne accès aux données de votre enfant : envoyez-le seulement à votre famille.</p></div></div>
      <div class="deux" style="margin-top:24px">
        <div class="bloc"><h2 style="margin-top:0">iPhone</h2><p style="margin:0">Le lien s’ouvre dans Safari, qui affiche trois gestes. Rien à taper : <b>Copier mon code</b> garde le lien en mémoire, puis <b>Partager → Sur l’écran d’accueil</b>, puis <b>Coller mon code</b> dans l’app installée.</p>
          <p class="aide" style="margin-bottom:0">Ce « code », c’est simplement ce lien. Le code de liaison de l’étape « Votre Google Drive » reste sur cet ordinateur : il ne va jamais sur un téléphone.</p></div>
        <div class="bloc"><h2 style="margin-top:0">Android</h2><p style="margin:0">Le lien s’ouvre dans Chrome. Touchez <b>Installer l’app</b> en haut de l’écran, ou le menu ⋮ puis <b>Installer l’application</b>.</p></div>
      </div>
      ${barre('Terminer', true)}`;
    $('#copier').onclick = async () => { await navigator.clipboard.writeText(r.lien); $('#copier').textContent = 'Lien copié'; };
    z.querySelector('[data-nav="1"]').onclick = () => { fait('telephones'); aller(7); };
    z.querySelector('[data-nav="-1"]').onclick = () => aller(5);
  },

  fin(z) {
    z.innerHTML = `<h1>C’est prêt</h1>
      <p class="chapeau">Mon Cap fait maintenant le travail tout seul. Voici ce qui se passe désormais.</p>
      <ul class="liste">
        <li>Toutes les 3 heures, tant que Chrome est ouvert, Mon Cap relève Coba et Classroom.</li>
        <li>Les téléphones reçoivent les nouveautés à l’ouverture de l’app, ou en tirant l’écran vers le bas.</li>
        <li>L’icône Mon Cap, en haut à droite de Chrome, montre la dernière collecte et permet d’en lancer une.</li>
      </ul>
      <div class="actions"><button class="btn second" data-nav="-1">Retour</button><a class="lien" href="reglages.html">Réglages</a></div>`;
    z.querySelector('[data-nav="-1"]').onclick = () => aller(6);
  }
};
/* Suivi de la collecte : les étapes, cochées au fil du journal de l'extension, avec leurs chiffres,
   et un bateau en papier qui avance sur le cap selon la vraie progression. */
const PHASES = [
  { id: 'connexion', nom: 'Connexion au portail Coba', re: /^Coba : (connexion automatique réussie|connecté)/, quand: /Coba|Connexion/ },
  { id: 'travaux', nom: 'Travaux et évaluations', re: /^Coba : \d+ travaux/ },
  { id: 'courriels', nom: 'Courriels de l’école', re: /^Coba : \d+ courriels/ },
  { id: 'suivi', nom: 'Commentaires des profs', re: /entrées de suivi/ },
  { id: 'agenda', nom: 'Agenda', re: /^Coba : agenda \d+/ },
  { id: 'horaire', nom: 'Horaire', re: /^Coba : horaire/ },
  { id: 'activites', nom: 'Activités', re: /^Coba : activités/ },
  { id: 'classroom', nom: 'Cours Classroom', re: /^Classroom : \d+\/\d+ cours lus/, enCours: /^Classroom \d+ :/ },
  { id: 'annonces', nom: 'Annonces des profs', re: /annonce\(s\) tirée/ },
  { id: 'drive', nom: 'Dépôt dans votre Google Drive', re: /^Drive : / },
  { id: 'ia', nom: 'Lecture des messages par l’IA', re: /^IA \(/ }
];
const detail = (id, m) => {
  m = m.replace(/^(Coba|Classroom|Drive) : /, '');
  if (id === 'travaux') return m.replace(/, \d+ compétences/, '');
  if (id === 'courriels') return m.replace(/ sur \d+ page\(s\)/, '');
  if (id === 'ia') return m.replace(/^IA \([^)]*\) : /, '').replace(/(\d+) textes, (\d+) analysés, (\d+) faits extraits/, '$1 messages lus, $3 informations trouvées');
  if (id === 'drive') return /compléments de l’IA déposés/.test(m) ? 'fait, compléments de l’IA compris' : /déposées/.test(m) ? 'fait, les téléphones les reçoivent' : m;
  if (id === 'connexion') return 'connecté';
  if (id === 'suivi') return m.replace(/, 0 détails lus/, '').replace(/entrées de suivi/, 'commentaires');
  if (id === 'agenda') return m.replace(/^agenda /, '').replace(/ \(mois suivant.*$/, '');
  if (id === 'horaire') return m.replace(/^horaire /, '').replace(/foyer/, 'groupe');
  if (id === 'activites') return m.replace(/^activités (\d+)/, (x, n) => n + (+n > 1 ? ' inscriptions' : ' inscription'));
  if (id === 'annonces') return m.replace(/^(\d+) annonce\(s\) tirée\(s\) de (\d+) résumé\(s\)/, '$1 annonces dans $2 résumés');
  if (id === 'classroom') return m.replace(/ en \d+ s$/, '');
  return m;
};
function suiviCollecte(lignes, s, termine) {
  const faits = {}, alertes = [];
  for (const l of lignes) for (const p of PHASES) if (p.re.test(l.msg || '')) faits[p.id] = detail(p.id, l.msg);
  for (const l of lignes) if (l.niveau === 'alerte') alertes.push(l.msg);
  const ia = (s.etape || '').match(/^IA (\d+)\/(\d+)/);
  const coursEnCours = [...lignes].reverse().find(l => /^Classroom \d+ :/.test(l.msg || ''));
  const nFaits = PHASES.filter(p => faits[p.id]).length;
  let actuelle = termine ? null : PHASES.find(p => !faits[p.id]);
  // progression : étapes faites, plus la part de l'IA déjà lue
  let prog = nFaits / PHASES.length;
  if (ia && !faits.ia) prog += (+ia[1] / +ia[2]) / PHASES.length;
  if (termine) prog = 1;
  const pct = Math.round(Math.min(prog, 1) * 100);
  const enCoursTxt = p => {
    if (p.id === 'ia' && ia) return `${ia[1]} sur ${ia[2]} messages`;
    if (p.id === 'classroom' && coursEnCours) return 'cours ' + (coursEnCours.msg.match(/^Classroom (\d+)/) || [])[1] + ' en lecture';
    if (p.id === 'connexion' && s.etape && !/^Coba/.test(s.etape)) return s.etape.toLowerCase() + '…';
    return 'en cours…';
  };
  return `<div class="voyage" aria-hidden="true"><div class="mer"><span class="bateau" style="left:calc(${pct}% - ${pct * 0.36}px)">⛵</span><span class="arrivee">🏁</span></div></div>
    <p class="sr" role="status">Collecte ${termine ? 'terminée' : 'en cours, ' + pct + ' %'}</p>
    <ol class="phases">${PHASES.map(p => {
      const ok = !!faits[p.id], ici = actuelle === p;
      return `<li class="${ok ? 'ok' : ici ? 'ici' : ''}"><span class="mq">${ok ? '✓' : ici ? '' : ''}</span>
        <span class="nm">${esc(p.nom)}</span><span class="dt">${ok ? esc(faits[p.id]) : ici ? esc(enCoursTxt(p)) : ''}</span>
        ${ici && p.id === 'ia' && ia ? `<span class="barre"><span style="width:${Math.round(+ia[1] / +ia[2] * 100)}%"></span></span>` : ''}</li>`;
    }).join('')}</ol>`;
}
// Les alertes du journal depuis le lancement : la vraie raison d'un échec, dite par l'extension
function derniersMessages(journal, t0) {
  const depuis = (journal || []).filter(l => Date.parse(l.le || l.t || 0) >= t0 - 2000);
  const alertes = depuis.filter(l => l.niveau === 'alerte' || l.niveau === 'erreur');
  const recents = (alertes.length ? alertes : depuis).slice(0, 4).reverse();   // le journal est du plus récent au plus ancien
  return recents.length ? '<ul class="liste">' + recents.map(l => '<li>' + esc(l.texte || l.msg || '') + '</li>').join('') + '</ul>'
    : '<p class="aide">Vérifiez la connexion à l’étape « Le portail Coba », puis relancez.</p>';
}
// Suivi d'une collecte lancée à t0 : étapes cochées au fil du journal, jusqu'au résultat
function suivreCollecte(t0, avant, dejaEnCours) {
  let vueEnCours = dejaEnCours, attente = 0;
  const suivre = async () => {
    if (!document.getElementById('lancer')) return;   // on a quitté l'étape : le suivi reprendra au retour
    const { etat: s = {}, journal = [] } = await chrome.storage.local.get(['etat', 'journal']);
    const lignes = journal.filter(l => Date.parse(l.t || 0) >= t0 - 2000).reverse();
    if (s.enCours) { vueEnCours = true; attente = -1; if (!collecteEnCours) { collecteEnCours = true; dessinerRoute(); } }
    else if (dejaEnCours && attente >= 0 && attente < 8 && !lignes.length) { attente++; setTimeout(suivre, 1500); return; }
    if (!(vueEnCours && !s.enCours)) {
      if (!vueEnCours && Date.now() - t0 > 45000) {
        $('#lancer').disabled = false; $('#res').innerHTML = etat('ko', 'La collecte n’a pas démarré.') + derniersMessages(journal, t0); return;
      }
      $('#res').innerHTML = suiviCollecte(lignes, s, false) +
        (Date.now() - t0 > 60000 ? '<p class="aide">Vous pouvez passer à l’étape suivante : la collecte continue sans vous.</p>' : '');
      if (Date.now() - t0 > 60000 && vueEnCours) activerSuivant();
      setTimeout(suivre, 1200); return;
    }
    E = await msg({ action: 'assistantEtat' });
    $('#lancer').disabled = false; collecteEnCours = false; dessinerRoute();
    if (E.derniere?.coba === 'ok' && (E.derniere.le || '') > avant) { fait('collecte'); $('#res').innerHTML = suiviCollecte(lignes, {}, true) + resume(E.derniere); activerSuivant(); }
    else $('#res').innerHTML = suiviCollecte(lignes, {}, false) + etat('ko', 'La collecte n’a pas abouti.') + derniersMessages(journal, t0);
  };
  setTimeout(suivre, 800);
}
function resume(d) {
  return etat('ok', 'Collecte réussie.') + `<div class="chiffres">
    <div><b>${d.travaux}</b><span>travaux</span></div><div><b>${d.cours}</b><span>cours Classroom</span></div>
    <div><b>${d.courriels}</b><span>courriels</span></div><div><b>${d.annonces}</b><span>annonces</span></div></div>`;
}

chrome.storage.onChanged?.addListener(async ch => {
  if (ch.etat) { const v = !!ch.etat.newValue?.enCours; if (v !== collecteEnCours) { collecteEnCours = v; dessinerRoute(); } }
  if (!ch.derniere || !A.collecteT0) return;
  const d = ch.derniere.newValue;
  if (d?.coba?.statut === 'ok' && (d.collecte_le || '') > (A.collecteAvant || '') && !A.faits.collecte) {
    E = await msg({ action: 'assistantEtat' }); fait('collecte');
  }
});
document.addEventListener('click', e => {
  const b = e.target.closest('[data-aller]'); if (b && !b.disabled) aller(+b.dataset.aller);
});
charger();
