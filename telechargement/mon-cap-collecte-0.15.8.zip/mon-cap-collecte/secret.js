// Chiffrement des identifiants Coba (AES-GCM 256 bits).
// La clé est créée « non exportable » et rangée dans IndexedDB : aucun script ne peut la lire,
// seule l'extension peut s'en servir pour chiffrer et déchiffrer.
const SECRET_DB = 'moncap', SECRET_STORE = 'cles';

function idb() {
  return new Promise((ok, ko) => {
    const r = indexedDB.open(SECRET_DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(SECRET_STORE);
    r.onsuccess = () => ok(r.result); r.onerror = () => ko(r.error);
  });
}
async function idbGet(k) { const db = await idb(); return new Promise((ok, ko) => { const q = db.transaction(SECRET_STORE).objectStore(SECRET_STORE).get(k); q.onsuccess = () => ok(q.result); q.onerror = () => ko(q.error); }); }
async function idbPut(k, v) { const db = await idb(); return new Promise((ok, ko) => { const t = db.transaction(SECRET_STORE, 'readwrite'); t.objectStore(SECRET_STORE).put(v, k); t.oncomplete = () => ok(); t.onerror = () => ko(t.error); }); }

async function cleSecrete() {
  let k = await idbGet('aes');
  if (!k) { k = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); await idbPut('aes', k); }
  return k;
}
const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
const deb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));

async function enregistrerIdentifiants(u, p) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await cleSecrete(), new TextEncoder().encode(JSON.stringify({ u, p })));
  await chrome.storage.local.set({ identifiantsCoba: { iv: b64(iv), data: b64(data), le: new Date().toISOString() } });
  await chrome.storage.local.remove('echecConnexion');
}
async function lireIdentifiants() {
  const { identifiantsCoba: c } = await chrome.storage.local.get('identifiantsCoba');
  if (!c) return null;
  try {
    const clair = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: deb64(c.iv) }, await cleSecrete(), deb64(c.data));
    return JSON.parse(new TextDecoder().decode(clair));
  } catch { return null; }   // clé perdue ou données abîmées : il faudra les ressaisir
}
async function effacerIdentifiants() { await chrome.storage.local.remove(['identifiantsCoba', 'echecConnexion']); }
